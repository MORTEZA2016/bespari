<?php
/**
 * پنل مستقل بسپاری — خارج از قالب wp-admin.
 *
 * مسیر: admin-post.php?action=bespari_panel&view=...
 * لاگین: admin-post.php?action=bespari_panel_login (فرم به wp-login.php پست می‌شود).
 *
 * @package Bespari\Admin\Panel
 */

namespace Bespari\Admin\Panel;

use Bespari\Support\Helpers;

// جلوگیری از دسترسی مستقیم.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class PanelPage {

	/**
	 * تعریف منوها: view => [label, cap, icon].
	 */
	private function menu(): array {
		return array(
			'dashboard'   => array( __( 'داشبورد', 'bespari-core' ), 'bespari_read_dashboard', 'dashicons-dashboard' ),
			'pos'         => array( __( 'ثبت سفارش (POS)', 'bespari-core' ), 'bespari_manage_orders|bespari_seller_view', 'dashicons-cart' ),
			'orders'      => array( __( 'سفارشات', 'bespari-core' ), 'bespari_manage_orders|bespari_seller_view', 'dashicons-list-view' ),
			'products'    => array( __( 'محصولات', 'bespari-core' ), 'bespari_manage_products|bespari_seller_view', 'dashicons-products' ),
			'channels'    => array( __( 'کانال‌های فروش', 'bespari-core' ), 'bespari_manage_settings', 'dashicons-networking' ),
			'sellers'     => array( __( 'بازاریاب‌ها', 'bespari-core' ), 'bespari_manage_sellers', 'dashicons-groups' ),
			'commissions' => array( __( 'پورسانت‌ها', 'bespari-core' ), 'bespari_manage_commission|bespari_seller_view', 'dashicons-money-alt' ),
			'warehouse'   => array( __( 'انبار', 'bespari-core' ), 'bespari_manage_warehouse', 'dashicons-portfolio' ),
			'reports'     => array( __( 'گزارشات', 'bespari-core' ), 'bespari_view_reports', 'dashicons-chart-bar' ),
			'logout'      => array( __( 'خروج', 'bespari-core' ), '', 'dashicons-exit' ),
		);
	}

	public function register(): void {
		add_action( 'admin_post_bespari_panel', array( $this, 'render' ) );
		add_action( 'admin_post_bespari_panel_login', array( $this, 'render_login' ) );
		add_action( 'login_redirect', array( $this, 'login_redirect_to_panel' ), 10, 3 );
	}

	/**
	 * پس از لاگین موفق به پنل مستقل برگردد.
	 */
	public function login_redirect_to_panel( $redirect_to, $requested_redirect_to, $user ) {
		if ( $user instanceof \WP_User
			&& ( $user->has_cap( 'bespari_read_dashboard' ) || $user->has_cap( 'bespari_seller_view' ) )
			&& false === strpos( (string) $redirect_to, 'admin.php' )
		) {
			return admin_url( 'admin-post.php?action=bespari_panel' );
		}
		return $redirect_to;
	}

	/**
	 * URL پنل مستقل.
	 */
	public static function url( array $args = array() ): string {
		return add_query_arg( array_merge( array( 'action' => 'bespari_panel' ), $args ), admin_url( 'admin-post.php' ) );
	}

	/**
	 * کاربر دسترسی به یک view دارد؟ (cap ممکن است با | چند مقدار باشد).
	 */
	private function can_view( string $caps ): bool {
		if ( '' === $caps ) {
			return true;
		}
		foreach ( explode( '|', $caps ) as $cap ) {
			if ( current_user_can( trim( $cap ) ) ) {
				return true;
			}
		}
		return false;
	}

	/* ---------- لاگین ---------- */

	public function render_login(): void {
		if ( is_user_logged_in() ) {
			wp_safe_redirect( self::url() );
			exit;
		}

		$redirect = esc_url_raw( self::url() );
		header( 'Content-Type: text/html; charset=utf-8' );
		?>
<!DOCTYPE html>
<html dir="rtl" lang="fa">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title><?php esc_html_e( 'ورود به پنل بسپاری', 'bespari-core' ); ?></title>
<link rel="stylesheet" href="<?php echo esc_url( BESPARI_URL . 'assets/css/panel.css' ); ?>?ver=<?php echo rawurlencode( BESPARI_VERSION ); ?>" />
</head>
<body class="bpanel-body bpanel-login-body">
	<div class="bpanel-login">
		<div class="bpanel-login__logo">بسپاری <span>ERP</span></div>
		<p class="bpanel-login__desc">پنل مدیریت فروش چندکاناله</p>

		<?php if ( isset( $_GET['login'] ) && 'failed' === $_GET['login'] ) : // phpcs:ignore ?>
		<div class="bpanel-notice bpanel-notice--error">نام کاربری یا گذرواژه اشتباه است.</div>
		<?php endif; ?>

		<form name="loginform" action="<?php echo esc_url( site_url( 'wp-login.php', 'login_post' ) ); ?>" method="post">
			<input type="hidden" name="log" value="" /><?php /* placeholder — فیلدهای واقعی زیر */ ?>
			<label class="bpanel-field">
				<span>نام کاربری یا ایمیل</span>
				<input type="text" name="log" required autocomplete="username" />
			</label>
			<label class="bpanel-field">
				<span>گذرواژه</span>
				<input type="password" name="pwd" required autocomplete="current-password" />
			</label>
			<label class="bpanel-field bpanel-field--check">
				<input type="checkbox" name="rememberme" value="forever" /> <span>مرا به خاطر بسپار</span>
			</label>
			<input type="hidden" name="redirect_to" value="<?php echo esc_attr( $redirect ); ?>" />
			<button type="submit" class="bpanel-btn bpanel-btn--primary bpanel-btn--block">ورود به پنل</button>
		</form>
	</div>
</body>
</html>
		<?php
		exit;
	}

	/* ---------- پنل ---------- */

	public function render(): void {
		if ( ! is_user_logged_in() ) {
			wp_safe_redirect( admin_url( 'admin-post.php?action=bespari_panel_login' ) );
			exit;
		}

		$view = isset( $_GET['view'] ) ? sanitize_key( wp_unslash( $_GET['view'] ) ) : 'dashboard'; // phpcs:ignore
		$menu = $this->menu();

		// گیت دسترسی per-view.
		if ( ! isset( $menu[ $view ] ) || ! $this->can_view( $menu[ $view ][1] ) ) {
			$view = 'dashboard';
		}
		if ( 'dashboard' === $view && ! current_user_can( 'bespari_read_dashboard' ) && ! current_user_can( 'bespari_seller_view' ) ) {
			wp_die( esc_html__( 'شما دسترسی لازم را ندارید.', 'bespari-core' ) );
		}

		$is_seller_only = current_user_can( 'bespari_seller_view' ) && ! current_user_can( 'bespari_read_dashboard' );
		$user           = wp_get_current_user();

		header( 'Content-Type: text/html; charset=utf-8' );
		?>
<!DOCTYPE html>
<html dir="rtl" lang="fa">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title><?php echo esc_html( $menu[ $view ][0] ); ?> — <?php esc_html_e( 'پنل بسپاری ERP', 'bespari-core' ); ?></title>
<link rel="stylesheet" href="<?php echo esc_url( BESPARI_URL . 'assets/css/panel.css' ); ?>?ver=<?php echo rawurlencode( BESPARI_VERSION ); ?>" />
</head>
<body class="bpanel-body">
<div class="bpanel">
	<aside class="bpanel-sidebar">
		<div class="bpanel-sidebar__logo">بسپاری <span>ERP</span></div>
		<nav class="bpanel-nav">
			<?php
			foreach ( $menu as $key => $item ) {
				if ( '' !== $item[1] && ! $this->can_view( $item[1] ) ) {
					continue;
				}
				if ( 'logout' === $key ) {
					echo '<a class="bpanel-nav__item bpanel-nav__item--logout" href="' . esc_url( wp_logout_url( admin_url( 'admin-post.php?action=bespari_panel_login' ) ) ) . '"><span class="dashicons ' . esc_attr( $item[2] ) . '"></span> ' . esc_html( $item[0] ) . '</a>';
					continue;
				}
				$url = 'pos' === $key ? admin_url( 'admin-post.php?action=bespari_pos' ) : self::url( array( 'view' => $key ) );
				$cls = 'bpanel-nav__item' . ( $key === $view && 'pos' !== $key ? ' is-active' : '' );
				echo '<a class="' . esc_attr( $cls ) . '" href="' . esc_url( $url ) . '"><span class="dashicons ' . esc_attr( $item[2] ) . '"></span> ' . esc_html( $item[0] ) . '</a>';
			}
			?>
		</nav>
		<div class="bpanel-sidebar__user">
			<div class="bpanel-sidebar__avatar"><?php echo esc_html( mb_substr( $user->display_name, 0, 1 ) ); ?></div>
			<div>
				<div class="bpanel-sidebar__uname"><?php echo esc_html( $user->display_name ); ?></div>
				<div class="bpanel-sidebar__urole"><?php echo esc_html( $is_seller_only ? 'بازاریاب' : 'مدیر' ); ?></div>
			</div>
		</div>
	</aside>

	<main class="bpanel-main">
		<header class="bpanel-topbar">
			<h1 class="bpanel-topbar__title"><?php echo esc_html( $menu[ $view ][0] ); ?></h1>
			<div class="bpanel-topbar__actions">
				<?php if ( current_user_can( 'bespari_read_dashboard' ) ) : ?>
				<a class="bpanel-btn" href="<?php echo esc_url( admin_url( 'admin.php?page=bespari' ) ); ?>">نسخه مدیریت وردپرس</a>
				<?php endif; ?>
				<a class="bpanel-btn bpanel-btn--primary" href="<?php echo esc_url( admin_url( 'admin-post.php?action=bespari_pos' ) ); ?>">+ ثبت سفارش</a>
			</div>
		</header>

		<div class="bpanel-content">
			<?php
			switch ( $view ) {
				case 'orders':
					( new PanelViews() )->orders( $is_seller_only );
					break;
				case 'products':
					( new PanelViews() )->products();
					break;
				case 'channels':
					( new PanelViews() )->channels();
					break;
				case 'sellers':
					( new PanelViews() )->sellers();
					break;
				case 'commissions':
					( new PanelViews() )->commissions( $is_seller_only );
					break;
				case 'warehouse':
					( new PanelViews() )->warehouse();
					break;
				case 'reports':
					( new PanelViews() )->reports();
					break;
				default:
					( new PanelViews() )->dashboard( $is_seller_only );
			}
			?>
		</div>
	</main>
</div>
</body>
</html>
		<?php
		exit;
	}
}
