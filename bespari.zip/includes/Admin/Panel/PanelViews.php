<?php
/**
 * نماهای پنل مستقل بسپاری — خواندنی (read-only) از Repositories.
 *
 * @package Bespari\Admin\Panel
 */

namespace Bespari\Admin\Panel;

use Bespari\Support\Helpers;
use Bespari\Modules\Order\OrderRepository;
use Bespari\Modules\Product\ProductRepository;
use Bespari\Modules\Channel\ChannelRepository;
use Bespari\Modules\Seller\SellerRepository;
use Bespari\Modules\Commission\CommissionRepository;

// جلوگیری از دسترسی مستقیم.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class PanelViews {

	private function fmt( $n ): string {
		return Helpers::format_money( (float) $n );
	}

	/**
	 * فیلتر seller برای بازاریاب.
	 */
	private function seller_scope( bool $is_seller_only ): int {
		return $is_seller_only ? get_current_user_id() : 0;
	}

	private function table( array $headers, array $rows ): void {
		echo '<div class="bpanel-card"><table class="bpanel-table"><thead><tr>';
		foreach ( $headers as $h ) {
			echo '<th>' . esc_html( $h ) . '</th>';
		}
		echo '</tr></thead><tbody>';
		if ( ! $rows ) {
			echo '<tr><td colspan="' . count( $headers ) . '" class="bpanel-empty">موردی یافت نشد.</td></tr>';
		}
		foreach ( $rows as $row ) {
			echo '<tr>';
			foreach ( $row as $cell ) {
				echo '<td>' . wp_kses_post( $cell ) . '</td>';
			}
			echo '</tr>';
		}
		echo '</tbody></table></div>';
	}

	private function badge( string $label, string $cls ): string {
		return '<span class="bpanel-badge bpanel-badge--' . esc_attr( $cls ) . '">' . esc_html( $label ) . '</span>';
	}

	private function order_status_badge( string $status ): string {
		$map = array(
			'pending'   => array( 'در انتظار', 'warning' ),
			'confirmed' => array( 'تاییدشده', 'info' ),
			'prepared'  => array( 'آماده‌سازی', 'info' ),
			'shipped'   => array( 'ارسال‌شده', 'info' ),
			'delivered' => array( 'تحویل‌شده', 'success' ),
			'cancelled' => array( 'لغوشده', 'danger' ),
		);
		$m   = $map[ $status ] ?? array( $status, 'muted' );
		return $this->badge( $m[0], $m[1] );
	}

	private function settlement_badge( string $status ): string {
		$map = array(
			'pending'          => array( 'در انتظار تسویه', 'warning' ),
			'partial_settled'  => array( 'تسویه جزئی', 'info' ),
			'settled'          => array( 'تسویه‌شده', 'success' ),
		);
		$m   = $map[ $status ] ?? array( $status, 'muted' );
		return $this->badge( $m[0], $m[1] );
	}

	private function commission_badge( string $status ): string {
		$map = array(
			'pending'   => array( 'در انتظار', 'warning' ),
			'approved'  => array( 'تاییدشده', 'info' ),
			'paid'      => array( 'پرداخت‌شده', 'success' ),
			'cancelled' => array( 'لغوشده', 'danger' ),
		);
		$m   = $map[ $status ] ?? array( $status, 'muted' );
		return $this->badge( $m[0], $m[1] );
	}

	/* ---------- داشبورد ---------- */

	public function dashboard( bool $is_seller_only ): void {
		global $wpdb;
		$orders = Helpers::table( 'orders' );
		$seller = $this->seller_scope( $is_seller_only );

		$where  = $seller ? $wpdb->prepare( 'WHERE seller_id = %d', $seller ) : '';
		$stats  = $wpdb->get_row( "SELECT COUNT(*) AS cnt, COALESCE(SUM(total_net),0) AS net, COALESCE(SUM(total_profit),0) AS profit FROM {$orders} {$where}" ); // phpcs:ignore
		$pend_q = $seller
			? $wpdb->prepare( "SELECT COUNT(*) FROM {$orders} WHERE seller_id = %d AND settlement_status = 'pending'", $seller )
			: "SELECT COUNT(*) FROM {$orders} WHERE settlement_status = 'pending'";
		$pending = (int) $wpdb->get_var( $pend_q ); // phpcs:ignore

		echo '<div class="bpanel-stats">';
		echo '<div class="bpanel-stat"><div class="bpanel-stat__value">' . esc_html( number_format_i18n( (int) $stats->cnt ) ) . '</div><div class="bpanel-stat__label">' . esc_html__( 'کل سفارشات', 'bespari-core' ) . '</div></div>';
		echo '<div class="bpanel-stat"><div class="bpanel-stat__value">' . esc_html( $this->fmt( $stats->net ) ) . '</div><div class="bpanel-stat__label">' . esc_html__( 'مجموع فروش خالص', 'bespari-core' ) . '</div></div>';
		if ( ! $is_seller_only ) {
			echo '<div class="bpanel-stat"><div class="bpanel-stat__value">' . esc_html( $this->fmt( $stats->profit ) ) . '</div><div class="bpanel-stat__label">' . esc_html__( 'سود کل', 'bespari-core' ) . '</div></div>';
		}
		echo '<div class="bpanel-stat"><div class="bpanel-stat__value">' . esc_html( number_format_i18n( $pending ) ) . '</div><div class="bpanel-stat__label">' . esc_html__( 'در انتظار تسویه', 'bespari-core' ) . '</div></div>';
		echo '</div>';

		// آخرین سفارشات.
		$rows = ( new OrderRepository() )->paginate( array( 'seller_id' => $seller ), 1, 10 );

		$out = array();
		foreach ( (array) ( $rows['items'] ?? array() ) as $o ) {
			$out[] = array(
				esc_html( $o->order_number ),
				esc_html( $o->channel_name ?: '—' ),
				esc_html( $o->customer_name ?: '—' ),
				esc_html( $this->fmt( $o->total_net ) ),
				$this->order_status_badge( (string) $o->status ),
			);
		}
		echo '<h2 class="bpanel-section">آخرین سفارشات</h2>';
		$this->table( array( 'شماره', 'کانال', 'مشتری', 'خالص', 'وضعیت' ), $out );
	}

	/* ---------- سفارشات ---------- */

	public function orders( bool $is_seller_only ): void {
		$seller = $this->seller_scope( $is_seller_only );
		$paged  = max( 1, isset( $_GET['paged'] ) ? (int) $_GET['paged'] : 1 ); // phpcs:ignore

		$per_page = 20;
		$res      = ( new OrderRepository() )->paginate( array( 'seller_id' => $seller ), $paged, $per_page );

		$out = array();
		foreach ( (array) ( $res['items'] ?? array() ) as $o ) {
			$out[] = array(
				esc_html( $o->order_number ),
				esc_html( $o->channel_name ?: '—' ),
				esc_html( $o->customer_name ?: '—' ),
				'credit' === $o->sale_type ? 'اعتباری' : 'نقدی',
				esc_html( $this->fmt( $o->total_gross ) ),
				esc_html( $this->fmt( $o->total_net ) ),
				$this->order_status_badge( (string) $o->status ),
				$this->settlement_badge( (string) $o->settlement_status ),
				esc_html( (string) $o->ordered_at ? mysql2date( 'Y/m/d', (string) $o->ordered_at ) : '—' ),
			);
		}

		$total = (int) ( $res['total'] ?? 0 );
		$pages = max( 1, (int) ceil( $total / $per_page ) );
		if ( $pages > 1 ) {
			echo '<div class="bpanel-pagination">';
			for ( $i = 1; $i <= min( $pages, 15 ); $i++ ) {
				$url = PanelPage::url( array( 'view' => 'orders', 'paged' => $i ) );
				echo '<a class="bpanel-page' . ( $i === $paged ? ' is-current' : '' ) . '" href="' . esc_url( $url ) . '">' . esc_html( number_format_i18n( $i ) ) . '</a>';
			}
			echo '</div>';
		}

		$this->table( array( 'شماره', 'کانال', 'مشتری', 'نوع فروش', 'ناخالص', 'خالص', 'وضعیت', 'تسویه', 'تاریخ' ), $out );
	}

	/* ---------- محصولات ---------- */

	public function products(): void {
		$res = ( new ProductRepository() )->paginate( array( 'per_page' => 50, 'page' => 1, 'status' => -1 ) );

		$out = array();
		foreach ( (array) ( $res['items'] ?? array() ) as $p ) {
			$out[] = array(
				esc_html( $p->name ),
				esc_html( $p->sku ?: '—' ),
				esc_html( $p->brand_name ?: '—' ),
				esc_html( $this->fmt( $p->base_price ) ),
				esc_html( number_format_i18n( (int) $p->stock ) ),
				(int) $p->status ? $this->badge( 'فعال', 'success' ) : $this->badge( 'غیرفعال', 'muted' ),
			);
		}
		$this->table( array( 'نام', 'SKU', 'برند', 'قیمت پایه', 'موجودی', 'وضعیت' ), $out );
	}

	/* ---------- کانال‌ها ---------- */

	public function channels(): void {
		$out = array();
		foreach ( (array) ( new ChannelRepository() )->get_all( false ) as $ch ) {
			$out[] = array(
				esc_html( $ch->name ),
				esc_html( $ch->settlement_label() ),
				esc_html( number_format_i18n( (float) $ch->commission_percent ) ) . '٪',
				(int) $ch->status ? $this->badge( 'فعال', 'success' ) : $this->badge( 'غیرفعال', 'muted' ),
			);
		}
		$this->table( array( 'کانال', 'حالت تسویه', 'درصد پورسانت', 'وضعیت' ), $out );
	}

	/* ---------- بازاریاب‌ها ---------- */

	public function sellers(): void {
		$res = ( new SellerRepository() )->paginate( array(), 1, 50 );

		$out = array();
		foreach ( (array) ( $res['items'] ?? array() ) as $s ) {
			$out[] = array(
				esc_html( $s->display_name ),
				esc_html( $s->email ),
				'active' === $s->seller_status ? $this->badge( 'فعال', 'success' ) : $this->badge( 'غیرفعال', 'muted' ),
			);
		}
		$this->table( array( 'نام', 'ایمیل', 'وضعیت' ), $out );
	}

	/* ---------- پورسانت‌ها ---------- */

	public function commissions( bool $is_seller_only ): void {
		$seller = $this->seller_scope( $is_seller_only );

		if ( $seller ) {
			$balance = ( new CommissionRepository() )->get_seller_balance( $seller );
			echo '<div class="bpanel-stats">';
			foreach ( array( 'pending' => 'در انتظار', 'approved' => 'تاییدشده', 'paid' => 'پرداخت‌شده' ) as $k => $lbl ) {
				echo '<div class="bpanel-stat"><div class="bpanel-stat__value">' . esc_html( $this->fmt( $balance[ $k ] ?? 0 ) ) . '</div><div class="bpanel-stat__label">' . esc_html( $lbl ) . '</div></div>';
			}
			echo '</div>';
		}

		$res = ( new CommissionRepository() )->paginate( array( 'seller_id' => $seller ), 1, 30 );

		$out = array();
		foreach ( (array) ( $res['items'] ?? array() ) as $c ) {
			$out[] = array(
				esc_html( $c->order_number ?: '—' ),
				esc_html( $c->seller_name ?: '—' ),
				esc_html( $this->fmt( $c->base_amount ) ),
				esc_html( number_format_i18n( (float) $c->percent ) ) . '٪',
				esc_html( $this->fmt( $c->amount ) ),
				$this->commission_badge( (string) $c->status ),
			);
		}

		$this->table( array( 'سفارش', 'بازاریاب', 'مبنا', 'درصد', 'مبلغ', 'وضعیت' ), $out );
	}

	/* ---------- انبار ---------- */

	public function warehouse(): void {
		global $wpdb;
		$products = Helpers::table( 'products' );

		$rows_db = $wpdb->get_results( "SELECT name, sku, stock, low_stock_threshold FROM {$products} ORDER BY stock ASC LIMIT 50" ); // phpcs:ignore

		$out = array();
		foreach ( (array) $rows_db as $p ) {
			$low = (int) $p->stock <= (int) $p->low_stock_threshold;
			$out[] = array(
				esc_html( $p->name ),
				esc_html( $p->sku ?: '—' ),
				esc_html( number_format_i18n( (int) $p->stock ) ),
				$low ? $this->badge( 'کم‌موجود', 'danger' ) : $this->badge( 'مناسب', 'success' ),
			);
		}
		$this->table( array( 'محصول', 'SKU', 'موجودی', 'وضعیت' ), $out );
	}

	/* ---------- گزارشات ---------- */

	public function reports(): void {
		global $wpdb;
		$orders   = Helpers::table( 'orders' );
		$channels = Helpers::table( 'channels' );

		$rows_db = $wpdb->get_results( "SELECT c.name AS channel, COUNT(o.id) AS cnt, COALESCE(SUM(o.total_net),0) AS net, COALESCE(SUM(o.total_profit),0) AS profit FROM {$orders} o LEFT JOIN {$channels} c ON c.id = o.channel_id WHERE o.status != 'cancelled' GROUP BY o.channel_id ORDER BY net DESC" ); // phpcs:ignore

		$out = array();
		foreach ( (array) $rows_db as $r ) {
			$out[] = array(
				esc_html( $r->channel ?: '—' ),
				esc_html( number_format_i18n( (int) $r->cnt ) ),
				esc_html( $this->fmt( $r->net ) ),
				esc_html( $this->fmt( $r->profit ) ),
			);
		}
		echo '<h2 class="bpanel-section">فروش به تفکیک کانال</h2>';
		$this->table( array( 'کانال', 'تعداد سفارش', 'فروش خالص', 'سود' ), $out );
	}
}
