<?php
/**
 * پنل POS ثبت سفارش — صفحه مستقل تمام‌صفحه (خارج از قالب wp-admin).
 *
 * @package Bespari\Admin
 */

namespace Bespari\Admin;

// جلوگیری از دسترسی مستقیم.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class PosPage {

	public function register(): void {
		add_action( 'admin_menu', array( $this, 'register_menu' ), 20 );
		add_action( 'admin_post_bespari_pos', array( $this, 'render' ) );
	}

	/**
	 * منوی «ثبت سفارش (POS)» — باز شدن در تب جدید.
	 */
	public function register_menu(): void {
		if ( ! ( current_user_can( 'bespari_manage_orders' ) || current_user_can( 'bespari_seller_view' ) ) ) {
			return;
		}

		global $submenu;
		$submenu['bespari'][] = array(
			__( 'ثبت سفارش (POS)', 'bespari-core' ),
			'read',
			admin_url( 'admin-post.php?action=bespari_pos' ),
		);
	}

	public function enqueue(): void {
		// فقط در صفحه POS.
		if ( ! isset( $_GET['action'] ) || 'bespari_pos' !== $_GET['action'] ) { // phpcs:ignore
			return;
		}

		wp_enqueue_style( 'bespari-pos', BESPARI_URL . 'assets/css/pos.css', array(), BESPARI_VERSION );
		wp_enqueue_script( 'bespari-pos', BESPARI_URL . 'assets/js/pos.js', array(), BESPARI_VERSION, true );

		wp_localize_script( 'bespari-pos', 'bespariPos', array(
			'restUrl'   => esc_url_raw( rest_url( 'bespari/v1/pos/' ) ),
			'nonce'     => wp_create_nonce( 'wp_rest' ),
			'dashboard' => admin_url( 'admin.php?page=bespari' ),
		) );
	}

	/**
	 * رندر پنل POS تمام‌صفحه.
	 */
	public function render(): void {
		if ( ! ( current_user_can( 'bespari_manage_orders' ) || current_user_can( 'bespari_seller_view' ) ) ) {
			wp_die( esc_html__( 'شما دسترسی لازم را ندارید.', 'bespari-core' ) );
		}

		$is_seller_only = current_user_can( 'bespari_seller_view' ) && ! current_user_can( 'bespari_manage_orders' );

		// اکشن admin_post از admin_enqueue_scripts عبور نمی‌کند — مستقیم لود می‌کنیم.
		$css_url = BESPARI_URL . 'assets/css/pos.css';
		$js_url  = BESPARI_URL . 'assets/js/pos.js';
		$pos_cfg = array(
			'restUrl'   => esc_url_raw( rest_url( 'bespari/v1/pos/' ) ),
			'nonce'     => wp_create_nonce( 'wp_rest' ),
			'dashboard' => admin_url( 'admin.php?page=bespari' ),
		);

		header( 'Content-Type: text/html; charset=utf-8' );
		?>
<!DOCTYPE html>
<html dir="rtl" lang="fa">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title><?php esc_html_e( 'ثبت سفارش — بسپاری ERP', 'bespari-core' ); ?></title>
<link rel="stylesheet" href="<?php echo esc_url( $css_url ); ?>?ver=<?php echo rawurlencode( BESPARI_VERSION ); ?>" />
</head>
<body class="bespari-pos-body">
	<header class="pos-header">
		<div class="pos-header__brand">بسپاری ERP <span>ثبت سفارش (POS)</span></div>
		<div class="pos-header__user">
			<span><?php echo esc_html( wp_get_current_user()->display_name ); ?></span>
			<a class="pos-btn pos-btn--ghost" href="<?php echo esc_url( admin_url( 'admin.php?page=bespari' ) ); ?>"><?php esc_html_e( 'بازگشت به داشبورد', 'bespari-core' ); ?></a>
		</div>
	</header>

	<div class="pos-layout">
		<!-- ستون راست: جستجو و محصولات -->
		<section class="pos-products">
			<div class="pos-search">
				<input type="search" id="pos-search" placeholder="<?php esc_attr_e( 'جستجوی محصول (نام، کد، SKU)...', 'bespari-core' ); ?>" autofocus />
				<button type="button" class="pos-btn" id="pos-search-btn"><?php esc_html_e( 'جستجو', 'bespari-core' ); ?></button>
			</div>
			<div class="pos-product-grid" id="pos-product-grid">
				<div class="pos-loading"><?php esc_html_e( 'در حال بارگذاری محصولات...', 'bespari-core' ); ?></div>
			</div>
		</section>

		<!-- ستون چپ: سبد -->
		<aside class="pos-cart">
			<h2 class="pos-cart__title"><?php esc_html_e( 'سبد سفارش', 'bespari-core' ); ?></h2>
			<table class="pos-cart__table">
				<thead><tr>
					<th><?php esc_html_e( 'محصول', 'bespari-core' ); ?></th>
					<th><?php esc_html_e( 'تعداد', 'bespari-core' ); ?></th>
					<th><?php esc_html_e( 'قیمت', 'bespari-core' ); ?></th>
					<th></th>
				</tr></thead>
				<tbody id="pos-cart-body">
					<tr class="pos-cart__empty"><td colspan="4"><?php esc_html_e( 'محصولی اضافه نشده است.', 'bespari-core' ); ?></td></tr>
				</tbody>
			</table>
			<div class="pos-totals" id="pos-totals">
				<div class="pos-totals__row"><span><?php esc_html_e( 'جمع کل:', 'bespari-core' ); ?></span><strong id="pos-total-gross">۰</strong></div>
				<div class="pos-totals__row pos-totals__row--muted"><span><?php esc_html_e( 'کسورات:', 'bespari-core' ); ?></span><span id="pos-total-deductions">۰</span></div>
				<div class="pos-totals__row pos-totals__row--net"><span><?php esc_html_e( 'خالص دریافتی:', 'bespari-core' ); ?></span><strong id="pos-total-net">۰</strong></div>
			</div>

			<!-- فرم ثبت نهایی -->
			<div class="pos-checkout" id="pos-checkout" hidden>
				<h3><?php esc_html_e( 'ثبت نهایی سفارش', 'bespari-core' ); ?></h3>

				<label class="pos-field">
					<span><?php esc_html_e( 'نوع فروش', 'bespari-core' ); ?></span>
					<select id="pos-sale-type">
						<option value="cash"><?php esc_html_e( 'نقدی', 'bespari-core' ); ?></option>
						<option value="credit"><?php esc_html_e( 'اعتباری', 'bespari-core' ); ?></option>
					</select>
				</label>

				<label class="pos-field">
					<span><?php esc_html_e( 'کانال فروش', 'bespari-core' ); ?></span>
					<select id="pos-channel"></select>
				</label>

				<?php if ( ! $is_seller_only ) : ?>
				<label class="pos-field">
					<span><?php esc_html_e( 'بازاریاب (اختیاری)', 'bespari-core' ); ?></span>
					<select id="pos-seller"><option value="0"><?php esc_html_e( '— بدون بازاریاب —', 'bespari-core' ); ?></option></select>
				</label>
				<?php endif; ?>

				<div id="pos-customer-fields" hidden>
					<label class="pos-field">
						<span><?php esc_html_e( 'نام مشتری *', 'bespari-core' ); ?></span>
						<input type="text" id="pos-customer-name" />
					</label>
					<label class="pos-field">
						<span><?php esc_html_e( 'تلفن مشتری *', 'bespari-core' ); ?></span>
						<input type="tel" id="pos-customer-phone" dir="ltr" />
					</label>
					<label class="pos-field">
						<span><?php esc_html_e( 'آدرس مشتری', 'bespari-core' ); ?></span>
						<textarea id="pos-customer-address" rows="2"></textarea>
					</label>
					<p class="pos-hint"><?php esc_html_e( 'این کانال «فاکتور به فاکتور» است — اطلاعات مشتری الزامی است.', 'bespari-core' ); ?></p>
				</div>

				<label class="pos-field">
					<span><?php esc_html_e( 'توضیحات', 'bespari-core' ); ?></span>
					<textarea id="pos-notes" rows="2"></textarea>
				</label>

				<button type="button" class="pos-btn pos-btn--primary pos-btn--block" id="pos-submit"><?php esc_html_e( 'ثبت سفارش', 'bespari-core' ); ?></button>
				<div class="pos-result" id="pos-result"></div>
			</div>
		</aside>
	</div>

<script>window.bespariPos = <?php echo wp_json_encode( $pos_cfg ); ?>;</script>
<script src="<?php echo esc_url( $js_url ); ?>?ver=<?php echo rawurlencode( BESPARI_VERSION ); ?>"></script>
</body>
</html>
		<?php
		exit;
	}
}
