<?php
/**
 * صفحه درخواست‌ها — گردش کار درخواست‌ها.
 *
 * @package Bespari\Admin\Pages
 */

namespace Bespari\Admin\Pages;

use Bespari\Modules\Request\RequestService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class RequestPage extends BasePage {

	protected string $slug = 'bespari-requests';
	protected string $cap  = 'bespari_manage_requests';

	public function render(): void {
		if ( ! $this->can_access() ) {
			wp_die( esc_html__( 'شما دسترسی لازم را ندارید.', 'bespari-core' ) );
		}

		$tab = $this->current_tab( 'list' );

		echo '<div class="wrap bespari-wrap">';
		$this->page_header( __( 'درخواست‌ها', 'bespari-core' ), __( 'گردش کار درخواست‌های بازاریاب‌ها و کارکنان — تایید یا رد با یادداشت پاسخ.', 'bespari-core' ) );
		$this->render_notice();
		$this->render_tabs( $tab, array(
			'list' => __( 'لیست درخواست‌ها', 'bespari-core' ),
			'add'  => __( 'ثبت درخواست', 'bespari-core' ),
		) );

		if ( 'add' === $tab ) {
			$this->render_form();
		} else {
			$this->render_filters();
			$this->render_list();
		}

		echo '</div>';
	}

	private function render_filters(): void {
		$search = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : ''; // phpcs:ignore
		$type   = isset( $_GET['type'] ) ? sanitize_key( wp_unslash( $_GET['type'] ) ) : ''; // phpcs:ignore
		$status = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : ''; // phpcs:ignore

		echo '<form method="get" class="bespari-filters">';
		echo '<input type="hidden" name="page" value="bespari-requests" />';
		echo '<div class="bespari-filters__row">';
		echo '<input type="search" name="s" value="' . esc_attr( $search ) . '" placeholder="' . esc_attr__( 'عنوان / توضیح', 'bespari-core' ) . '" class="regular-text" />';
		echo '<select name="type"><option value="">' . esc_html__( 'همه انواع', 'bespari-core' ) . '</option>';
		foreach ( array( 'stock' => __( 'موجودی', 'bespari-core' ), 'price' => __( 'قیمت', 'bespari-core' ), 'discount' => __( 'تخفیف', 'bespari-core' ), 'other' => __( 'سایر', 'bespari-core' ) ) as $k => $label ) {
			echo '<option value="' . esc_attr( $k ) . '"' . selected( $type, $k, false ) . '>' . esc_html( $label ) . '</option>';
		}
		echo '</select>';
		echo '<select name="status"><option value="">' . esc_html__( 'همه وضعیت‌ها', 'bespari-core' ) . '</option>';
		foreach ( array( 'pending' => __( 'در انتظار', 'bespari-core' ), 'approved' => __( 'تاییدشده', 'bespari-core' ), 'rejected' => __( 'ردشده', 'bespari-core' ) ) as $k => $label ) {
			echo '<option value="' . esc_attr( $k ) . '"' . selected( $status, $k, false ) . '>' . esc_html( $label ) . '</option>';
		}
		echo '</select>';
		echo '<button type="submit" class="button">' . esc_html__( 'فیلتر', 'bespari-core' ) . '</button> ';
		$clear = add_query_arg( array( 'page' => 'bespari-requests' ), admin_url( 'admin.php' ) );
		echo '<a href="' . esc_url( $clear ) . '" class="button">' . esc_html__( 'پاک کردن', 'bespari-core' ) . '</a>';
		echo '</div></form>';
	}

	private function render_list(): void {
		$args = array(
			'page'   => isset( $_GET['paged'] ) ? max( 1, (int) $_GET['paged'] ) : 1, // phpcs:ignore
			'search' => isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '', // phpcs:ignore
			'type'   => isset( $_GET['type'] ) ? sanitize_key( wp_unslash( $_GET['type'] ) ) : '', // phpcs:ignore
			'status' => isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : '', // phpcs:ignore
			'per_page' => 20,
		);
		$service = new RequestService();
		$res     = $service->list( $args );
		$items   = $res['items'];
		$total   = $res['total'];
		$page    = max( 1, (int) ( $args['page'] ?? 1 ) );
		$pages   = max( 1, (int) ceil( $total / 20 ) );

		if ( empty( $items ) ) {
			echo '<div class="bespari-empty"><p>' . esc_html__( 'درخواستی یافت نشد.', 'bespari-core' ) . '</p></div>';
			return;
		}

		echo '<table class="bespari-table widefat striped"><thead><tr>';
		echo '<th>#</th>';
		echo '<th>' . esc_html__( 'عنوان', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'نوع', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'درخواست‌دهنده', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'محصول / سفارش', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'وضعیت', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'تاریخ', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'عملیات', 'bespari-core' ) . '</th>';
		echo '</tr></thead><tbody>';

		$badge_map = array( 'pending' => 'bespari-badge--warning', 'approved' => 'bespari-badge--success', 'rejected' => 'bespari-badge--danger' );

		foreach ( $items as $m ) {
			$cls = $badge_map[ $m->status ] ?? 'bespari-badge--muted';
			echo '<tr>';
			echo '<td>' . esc_html( $m->id ) . '</td>';
			echo '<td><strong>' . esc_html( $m->title ) . '</strong>' . ( $m->description ? '<br /><span class="bespari-muted">' . esc_html( mb_strimwidth( $m->description, 0, 80, '…' ) ) . '</span>' : '' ) . '</td>';
			echo '<td>' . esc_html( $m->type_label() ) . '</td>';
			echo '<td>' . esc_html( $m->requester_name ?: (string) $m->requester_id ) . '</td>';
			echo '<td>';
			if ( $m->product_name ) {
				echo esc_html( $m->product_name );
			}
			if ( $m->order_number ) {
				echo ( $m->product_name ? ' / ' : '' ) . esc_html( $m->order_number );
			}
			if ( ! $m->product_name && ! $m->order_number ) {
				echo '—';
			}
			echo '</td>';
			echo '<td><span class="bespari-badge ' . esc_attr( $cls ) . '">' . esc_html( $m->status_label() ) . '</span>';
			if ( $m->resolution_notes ) {
				echo '<br /><span class="bespari-muted">' . esc_html( mb_strimwidth( $m->resolution_notes, 0, 60, '…' ) ) . '</span>';
			}
			echo '</td>';
			echo '<td><span class="bespari-muted">' . esc_html( $m->created_at ) . '</span></td>';
			echo '<td class="bespari-actions">';
			if ( 'pending' === $m->status ) {
				echo '<a href="' . esc_url( $this->admin_action_url( 'approve_request', array( 'id' => $m->id ) ) ) . '" class="button button-small button-primary">' . esc_html__( 'تایید', 'bespari-core' ) . '</a> ';
				echo '<a href="' . esc_url( $this->admin_action_url( 'reject_request', array( 'id' => $m->id ) ) ) . '" class="button button-small">' . esc_html__( 'رد', 'bespari-core' ) . '</a>';
			} else {
				echo '<span class="bespari-muted">' . esc_html( $m->resolved_at ?: '—' ) . '</span>';
			}
			echo '</td></tr>';
		}
		echo '</tbody></table>';

		if ( $pages > 1 ) {
			echo '<div class="tablenav"><div class="tablenav-pages">';
			echo paginate_links( array( 'base' => add_query_arg( 'paged', '%#%' ), 'format' => '', 'prev_text' => __( '&laquo; قبلی', 'bespari-core' ), 'next_text' => __( 'بعدی &raquo;', 'bespari-core' ), 'total' => $pages, 'current' => $page ) );
			echo '</div></div>';
		}
		echo '<p class="description">' . sprintf( esc_html__( 'مجموع %d درخواست', 'bespari-core' ), (int) $total ) . '</p>';
	}

	private function render_form(): void {
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="bespari-form">';
		wp_nonce_field( 'bespari_save_request', 'bespari_nonce' );
		echo '<input type="hidden" name="action" value="bespari_save_request" />';
		echo '<table class="form-table">';

		echo '<tr><th scope="row"><label>' . esc_html__( 'نوع', 'bespari-core' ) . '</label></th><td><select name="request[type]">';
		foreach ( array( 'stock' => __( 'موجودی', 'bespari-core' ), 'price' => __( 'قیمت', 'bespari-core' ), 'discount' => __( 'تخفیف', 'bespari-core' ), 'other' => __( 'سایر', 'bespari-core' ) ) as $k => $label ) {
			echo '<option value="' . esc_attr( $k ) . '">' . esc_html( $label ) . '</option>';
		}
		echo '</select></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'عنوان', 'bespari-core' ) . ' <span class="required">*</span></label></th>';
		echo '<td><input type="text" name="request[title]" class="regular-text" required /></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'توضیح', 'bespari-core' ) . '</label></th>';
		echo '<td><textarea name="request[description]" rows="4" class="large-text"></textarea></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'شناسه محصول (اختیاری)', 'bespari-core' ) . '</label></th>';
		echo '<td><input type="number" name="request[product_id]" min="0" class="small-text" /></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'شناسه سفارش (اختیاری)', 'bespari-core' ) . '</label></th>';
		echo '<td><input type="number" name="request[order_id]" min="0" class="small-text" /></td></tr>';

		echo '</table>';
		submit_button( __( 'ثبت درخواست', 'bespari-core' ), 'primary', 'submit' );
		echo '</form>';
	}
}
