<?php
/**
 * صفحه حسابداری — کیف پول بازاریاب‌ها و تراکنش‌ها.
 *
 * @package Bespari\Admin\Pages
 */

namespace Bespari\Admin\Pages;

use Bespari\Modules\Accounting\AccountingService;
use Bespari\Support\Helpers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AccountingPage extends BasePage {

	protected string $slug = 'bespari-accounting';
	protected string $cap  = 'bespari_manage_finance';

	public function render(): void {
		if ( ! $this->can_access() ) {
			wp_die( esc_html__( 'شما دسترسی لازم را ندارید.', 'bespari-core' ) );
		}

		$tab = $this->current_tab( 'list' );

		echo '<div class="wrap bespari-wrap">';
		$this->page_header( __( 'حسابداری', 'bespari-core' ), __( 'کیف پول بازاریاب‌ها — تراکنش‌ها، شارژ دستی و مانده هر بازاریاب.', 'bespari-core' ) );
		$this->render_notice();
		$this->render_tabs( $tab, array(
			'list'             => __( 'تراکنش‌ها', 'bespari-core' ),
			'transactions-add' => __( 'ثبت تراکنش', 'bespari-core' ),
			'sellers'          => __( 'مانده بازاریاب‌ها', 'bespari-core' ),
		) );

		if ( 'transactions-add' === $tab ) {
			$this->render_add_form();
		} elseif ( 'sellers' === $tab ) {
			$this->render_sellers();
		} else {
			$this->render_filters();
			$this->render_list();
		}

		echo '</div>';
	}

	private function render_filters(): void {
		$search = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : ''; // phpcs:ignore
		$type   = isset( $_GET['type'] ) ? sanitize_key( wp_unslash( $_GET['type'] ) ) : ''; // phpcs:ignore
		$seller = isset( $_GET['seller_id'] ) ? (int) $_GET['seller_id'] : 0; // phpcs:ignore
		$from   = isset( $_GET['date_from'] ) ? sanitize_text_field( wp_unslash( $_GET['date_from'] ) ) : ''; // phpcs:ignore
		$to     = isset( $_GET['date_to'] ) ? sanitize_text_field( wp_unslash( $_GET['date_to'] ) ) : ''; // phpcs:ignore

		echo '<form method="get" class="bespari-filters">';
		echo '<input type="hidden" name="page" value="bespari-accounting" />';
		echo '<input type="search" name="s" value="' . esc_attr( $search ) . '" placeholder="' . esc_attr__( 'توضیح / بازاریاب', 'bespari-core' ) . '" class="regular-text" />';
		echo '<select name="type"><option value="">' . esc_html__( 'همه انواع', 'bespari-core' ) . '</option>';
		foreach ( array( 'charge' => __( 'شارژ', 'bespari-core' ), 'commission' => __( 'پورسانت', 'bespari-core' ), 'payout' => __( 'برداشت', 'bespari-core' ), 'adjust' => __( 'تعدیل', 'bespari-core' ), 'refund' => __( 'بازگشت وجه', 'bespari-core' ) ) as $k => $label ) {
			echo '<option value="' . esc_attr( $k ) . '"' . selected( $type, $k, false ) . '>' . esc_html( $label ) . '</option>';
		}
		echo '</select>';
		echo '<input type="number" name="seller_id" value="' . esc_attr( $seller ?: '' ) . '" placeholder="' . esc_attr__( 'شناسه بازاریاب', 'bespari-core' ) . '" class="small-text" />';
		echo '<input type="date" name="date_from" value="' . esc_attr( $from ) . '" />';
		echo '<input type="date" name="date_to" value="' . esc_attr( $to ) . '" />';
		echo '<button type="submit" class="button">' . esc_html__( 'فیلتر', 'bespari-core' ) . '</button> ';
		$clear = add_query_arg( array( 'page' => 'bespari-accounting' ), admin_url( 'admin.php' ) );
		echo '<a href="' . esc_url( $clear ) . '" class="button">' . esc_html__( 'پاک کردن', 'bespari-core' ) . '</a>';
		echo '</form>';
	}

	private function render_list(): void {
		$args = array(
			'page'     => isset( $_GET['paged'] ) ? max( 1, (int) $_GET['paged'] ) : 1, // phpcs:ignore
			'search'   => isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '', // phpcs:ignore
			'type'     => isset( $_GET['type'] ) ? sanitize_key( wp_unslash( $_GET['type'] ) ) : '', // phpcs:ignore
			'seller_id' => isset( $_GET['seller_id'] ) ? (int) $_GET['seller_id'] : 0, // phpcs:ignore
			'date_from' => isset( $_GET['date_from'] ) ? sanitize_text_field( wp_unslash( $_GET['date_from'] ) ) : '', // phpcs:ignore
			'date_to'   => isset( $_GET['date_to'] ) ? sanitize_text_field( wp_unslash( $_GET['date_to'] ) ) : '', // phpcs:ignore
			'per_page' => 20,
		);
		$service = new AccountingService();
		$res     = $service->list_transactions( $args );
		$items   = $res['items'];
		$total   = $res['total'];
		$page    = max( 1, (int) ( $args['page'] ?? 1 ) );
		$pages   = max( 1, (int) ceil( $total / 20 ) );

		if ( empty( $items ) ) {
			echo '<div class="bespari-empty"><p>' . esc_html__( 'تراکنشی یافت نشد.', 'bespari-core' ) . '</p></div>';
			return;
		}

		$badge_map = array(
			'charge'     => 'bespari-badge--success',
			'commission' => 'bespari-badge--info',
			'payout'     => 'bespari-badge--danger',
			'adjust'     => 'bespari-badge--warning',
			'refund'     => 'bespari-badge--muted',
		);

		echo '<table class="bespari-table widefat striped"><thead><tr>';
		echo '<th>#</th>';
		echo '<th>' . esc_html__( 'بازاریاب', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'نوع', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'مبلغ', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'مانده پس از تراکنش', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'توضیح', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'تاریخ', 'bespari-core' ) . '</th>';
		echo '</tr></thead><tbody>';

		foreach ( $items as $m ) {
			$cls   = $badge_map[ $m->type ] ?? 'bespari-badge--muted';
			$color = $m->amount >= 0 ? 'var(--bespari-success)' : 'var(--bespari-danger)';
			echo '<tr>';
			echo '<td>' . esc_html( $m->id ) . '</td>';
			echo '<td>' . esc_html( $m->seller_name ?: (string) $m->seller_id ) . '</td>';
			echo '<td><span class="bespari-badge ' . esc_attr( $cls ) . '">' . esc_html( $m->type_label() ) . '</span></td>';
			echo '<td style="color:' . esc_attr( $color ) . ';font-weight:700;">' . esc_html( ( $m->amount >= 0 ? '+' : '' ) . Helpers::format_money( $m->amount ) ) . '</td>';
			echo '<td>' . esc_html( Helpers::format_money( $m->balance_after ) ) . '</td>';
			echo '<td><span class="bespari-muted">' . esc_html( $m->description ?: '—' ) . '</span></td>';
			echo '<td><span class="bespari-muted">' . esc_html( $m->created_at ) . '</span></td>';
			echo '</tr>';
		}
		echo '</tbody></table>';

		if ( $pages > 1 ) {
			echo '<div class="tablenav"><div class="tablenav-pages">';
			echo paginate_links( array( 'base' => add_query_arg( 'paged', '%#%' ), 'format' => '', 'prev_text' => __( '&laquo; قبلی', 'bespari-core' ), 'next_text' => __( 'بعدی &raquo;', 'bespari-core' ), 'total' => $pages, 'current' => $page ) );
			echo '</div></div>';
		}
		echo '<p class="description">' . sprintf( esc_html__( 'مجموع %d تراکنش', 'bespari-core' ), (int) $total ) . '</p>';
	}

	private function render_add_form(): void {
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="bespari-form">';
		wp_nonce_field( 'bespari_record_transaction', 'bespari_nonce' );
		echo '<input type="hidden" name="action" value="bespari_record_transaction" />';
		echo '<table class="form-table">';

		echo '<tr><th scope="row"><label>' . esc_html__( 'بازاریاب (شناسه)', 'bespari-core' ) . ' <span class="required">*</span></label></th>';
		echo '<td><input type="number" name="transaction[seller_id]" min="1" class="small-text" required /> <span class="description">' . esc_html__( 'شناسه کاربر بازاریاب (WP Users)', 'bespari-core' ) . '</span></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'نوع تراکنش', 'bespari-core' ) . '</label></th><td><select name="transaction[type]">';
		foreach ( array( 'charge' => __( 'شارژ (واریز به کیف پول)', 'bespari-core' ), 'adjust' => __( 'تعدیل (دستی)', 'bespari-core' ), 'refund' => __( 'بازگشت وجه', 'bespari-core' ), 'payout' => __( 'برداشت (کسر از کیف پول)', 'bespari-core' ) ) as $k => $label ) {
			echo '<option value="' . esc_attr( $k ) . '">' . esc_html( $label ) . '</option>';
		}
		echo '</select></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'مبلغ', 'bespari-core' ) . ' <span class="required">*</span></label></th>';
		echo '<td><input type="number" name="transaction[amount]" min="0.01" step="0.01" class="regular-text" required /></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'توضیح', 'bespari-core' ) . '</label></th>';
		echo '<td><input type="text" name="transaction[description]" class="regular-text" /></td></tr>';

		echo '</table>';
		submit_button( __( 'ثبت تراکنش', 'bespari-core' ), 'primary', 'submit' );
		echo '</form>';
	}

	private function render_sellers(): void {
		$service = new AccountingService();
		$balances = $service->get_all_seller_balances();

		if ( empty( $balances ) ) {
			echo '<div class="bespari-empty"><p>' . esc_html__( 'تراکنشی ثبت نشده است.', 'bespari-core' ) . '</p></div>';
			return;
		}

		echo '<table class="bespari-table widefat striped"><thead><tr>';
		echo '<th>' . esc_html__( 'بازاریاب', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'مانده کیف پول', 'bespari-core' ) . '</th>';
		echo '</tr></thead><tbody>';

		foreach ( $balances as $b ) {
			$color = (float) $b->balance >= 0 ? 'var(--bespari-dark)' : 'var(--bespari-danger)';
			echo '<tr>';
			echo '<td><strong>' . esc_html( $b->seller_name ?: (string) $b->seller_id ) . '</strong></td>';
			echo '<td style="color:' . esc_attr( $color ) . ';font-weight:700;">' . esc_html( Helpers::format_money( (float) $b->balance ) ) . '</td>';
			echo '</tr>';
		}
		echo '</tbody></table>';
	}
}
