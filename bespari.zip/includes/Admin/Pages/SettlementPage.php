<?php
/**
 * صفحه تسویه.
 *
 * @package Bespari\Admin\Pages
 */

namespace Bespari\Admin\Pages;

use Bespari\Modules\Settlement\SettlementService;
use Bespari\Modules\Settlement\SettlementRepository;
use Bespari\Modules\Channel\ChannelService;
use Bespari\Support\Helpers;

// جلوگیری از دسترسی مستقیم.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SettlementPage extends BasePage {

	protected string $slug = 'bespari-settlements';
	protected string $cap  = 'bespari_manage_settlement';

	public function render(): void {
		if ( ! $this->can_access() ) {
			wp_die( esc_html__( 'شما دسترسی لازم را ندارید.', 'bespari-core' ) );
		}

		$tab     = $this->current_tab( 'list' );
		$view_id = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0; // phpcs:ignore
		if ( $view_id && 'list' === $tab ) {
			$tab = 'view';
		}

		echo '<div class="wrap bespari-wrap">';
		$this->page_header( __( 'تسویه', 'bespari-core' ), __( 'ایجاد تسویه از سفارش‌های pending هر کانال و ثبت پرداخت.', 'bespari-core' ) );
		$this->render_notice();
		$this->render_tabs( $tab, array(
			'list' => __( 'لیست تسویه‌ها', 'bespari-core' ),
			'add'  => __( 'ایجاد تسویه', 'bespari-core' ),
		) );

		if ( 'add' === $tab ) {
			$this->render_form();
		} elseif ( 'view' === $tab && $view_id ) {
			$this->render_view( $view_id );
		} else {
			$this->render_filters();
			$this->render_list();
		}

		echo '</div>';
	}

	private function render_filters(): void {
		$channels = ( new ChannelService() )->list( true );
		$filter_channel = isset( $_GET['channel_id'] ) ? (int) $_GET['channel_id'] : 0; // phpcs:ignore
		$filter_status  = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : ''; // phpcs:ignore
		$date_from      = isset( $_GET['date_from'] ) ? sanitize_text_field( wp_unslash( $_GET['date_from'] ) ) : ''; // phpcs:ignore
		$date_to        = isset( $_GET['date_to'] ) ? sanitize_text_field( wp_unslash( $_GET['date_to'] ) ) : ''; // phpcs:ignore

		echo '<form method="get" class="bespari-filters">';
		echo '<input type="hidden" name="page" value="bespari-settlements" />';
		echo '<div class="bespari-filters__row">';

		echo '<select name="channel_id"><option value="0">' . esc_html__( 'همه کانال‌ها', 'bespari-core' ) . '</option>';
		foreach ( $channels as $ch ) {
			echo '<option value="' . esc_attr( $ch->id ) . '"' . selected( $filter_channel, $ch->id, false ) . '>' . esc_html( $ch->name ) . '</option>';
		}
		echo '</select>';

		echo '<select name="status"><option value="">' . esc_html__( 'همه وضعیت‌ها', 'bespari-core' ) . '</option>';
		echo '<option value="pending"' . selected( $filter_status, 'pending', false ) . '>' . esc_html__( 'در انتظار', 'bespari-core' ) . '</option>';
		echo '<option value="paid"' . selected( $filter_status, 'paid', false ) . '>' . esc_html__( 'پرداخت‌شده', 'bespari-core' ) . '</option>';
		echo '</select>';

		echo '<input type="date" name="date_from" value="' . esc_attr( $date_from ) . '" />';
		echo '<input type="date" name="date_to" value="' . esc_attr( $date_to ) . '" />';

		echo '<button type="submit" class="button">' . esc_html__( 'فیلتر', 'bespari-core' ) . '</button>';
		$clear_url = add_query_arg( array( 'page' => 'bespari-settlements' ), admin_url( 'admin.php' ) );
		echo ' <a href="' . esc_url( $clear_url ) . '" class="button">' . esc_html__( 'پاک کردن', 'bespari-core' ) . '</a>';
		echo '</div></form>';
	}

	private function render_list(): void {
		$args = array(
			'page'       => isset( $_GET['paged'] ) ? (int) $_GET['paged'] : 1, // phpcs:ignore
			'channel_id' => isset( $_GET['channel_id'] ) ? (int) $_GET['channel_id'] : 0, // phpcs:ignore
			'status'     => isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : '', // phpcs:ignore
			'date_from'  => isset( $_GET['date_from'] ) ? sanitize_text_field( wp_unslash( $_GET['date_from'] ) ) : '', // phpcs:ignore
			'date_to'    => isset( $_GET['date_to'] ) ? sanitize_text_field( wp_unslash( $_GET['date_to'] ) ) : '', // phpcs:ignore
			'per_page'   => 20,
		);

		$service = new SettlementService();
		$res     = $service->list( $args );
		$items   = $res['items'];
		$total   = $res['total'];
		$page    = max( 1, (int) ( $args['page'] ?? 1 ) );
		$pages   = max( 1, (int) ceil( $total / 20 ) );

		if ( empty( $items ) ) {
			echo '<div class="bespari-empty"><p>' . esc_html__( 'تسویه‌ای یافت نشد. از تب «ایجاد تسویه» شروع کنید.', 'bespari-core' ) . '</p></div>';
			return;
		}

		echo '<table class="bespari-table widefat striped">';
		echo '<thead><tr>';
		echo '<th>' . esc_html__( 'عنوان', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'کانال', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'بازه', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'تعداد سفارش', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'خالص', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'سود', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'وضعیت', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'عملیات', 'bespari-core' ) . '</th>';
		echo '</tr></thead><tbody>';

		foreach ( $items as $s ) {
			$view_url = add_query_arg( array( 'page' => 'bespari-settlements', 'id' => $s->id ), admin_url( 'admin.php' ) );
			$paid_url = $this->admin_action_url( 'mark_settlement_paid', array( 'id' => $s->id ) );
			$del_url  = $this->admin_action_url( 'delete_settlement', array( 'id' => $s->id ) );

			echo '<tr>';
			echo '<td><a href="' . esc_url( $view_url ) . '"><strong>' . esc_html( $s->title ) . '</strong></a></td>';
			echo '<td>' . esc_html( $s->channel_name ?: (string) $s->channel_id ) . '</td>';
			echo '<td><span class="bespari-muted">' . esc_html( $s->period_start ) . ' — ' . esc_html( $s->period_end ) . '</span></td>';
			echo '<td>' . esc_html( $s->total_orders ) . '</td>';
			echo '<td>' . esc_html( Helpers::format_money( $s->total_net ) ) . '</td>';
			echo '<td>' . esc_html( Helpers::format_money( $s->total_profit ) ) . '</td>';
			echo '<td>' . $this->status_badge( $s->status ) . '</td>';
			echo '<td class="bespari-actions">';
			echo '<a href="' . esc_url( $view_url ) . '" class="button button-small">' . esc_html__( 'مشاهده', 'bespari-core' ) . '</a> ';
			if ( 'pending' === $s->status ) {
				echo '<a href="' . esc_url( $paid_url ) . '" class="button button-small button-primary">' . esc_html__( 'ثبت پرداخت', 'bespari-core' ) . '</a> ';
				echo '<a href="' . esc_url( $del_url ) . '" class="button button-small button-link-delete bespari-confirm-delete" data-message="' . esc_attr__( 'آیا از حذف این تسویه اطمینان دارید؟ سفارش‌ها به حالت pending برمی‌گردند.', 'bespari-core' ) . '">' . esc_html__( 'حذف', 'bespari-core' ) . '</a>';
			}
			echo '</td>';
			echo '</tr>';
		}

		echo '</tbody></table>';

		if ( $pages > 1 ) {
			echo '<div class="tablenav"><div class="tablenav-pages">';
			echo paginate_links( array(
				'base'      => add_query_arg( 'paged', '%#%' ),
				'format'    => '',
				'prev_text' => __( '&laquo; قبلی', 'bespari-core' ),
				'next_text' => __( 'بعدی &raquo;', 'bespari-core' ),
				'total'     => $pages,
				'current'   => $page,
			) );
			echo '</div></div>';
		}
		echo '<p class="description">' . sprintf( esc_html__( 'مجموع %d تسویه', 'bespari-core' ), (int) $total ) . '</p>';
	}

	private function render_form(): void {
		$action   = admin_url( 'admin-post.php' );
		$channels = ( new ChannelService() )->list( true );

		echo '<form method="post" action="' . esc_url( $action ) . '" class="bespari-form">';
		wp_nonce_field( 'bespari_save_settlement', 'bespari_nonce' );
		echo '<input type="hidden" name="action" value="bespari_save_settlement" />';

		echo '<table class="form-table">';
		echo '<tr><th scope="row"><label>' . esc_html__( 'کانال', 'bespari-core' ) . ' <span class="required">*</span></label></th><td><select name="channel_id" required><option value="">' . esc_html__( '— انتخاب کنید —', 'bespari-core' ) . '</option>';
		foreach ( $channels as $ch ) {
			echo '<option value="' . esc_attr( $ch->id ) . '">' . esc_html( $ch->name ) . '</option>';
		}
		echo '</select></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'از تاریخ', 'bespari-core' ) . ' <span class="required">*</span></label></th>';
		echo '<td><input type="date" name="period_start" required /></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'تا تاریخ', 'bespari-core' ) . ' <span class="required">*</span></label></th>';
		echo '<td><input type="date" name="period_end" required /></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'عنوان', 'bespari-core' ) . '</label></th>';
		echo '<td><input type="text" name="title" class="regular-text" placeholder="' . esc_attr__( 'خالی = خودکار', 'bespari-core' ) . '" /></td></tr>';

		echo '</table>';
		echo '<p class="description">' . esc_html__( 'تسویه از روی سفارش‌های settlement_status=pending در بازه انتخابی و از snapshot مالی (نه محاسبه زنده) ساخته می‌شود.', 'bespari-core' ) . '</p>';
		submit_button( __( 'ایجاد تسویه', 'bespari-core' ), 'primary', 'submit' );
		echo '</form>';
	}

	private function render_view( int $id ): void {
		$service    = new SettlementService();
		$settlement = $service->get( $id );
		if ( ! $settlement ) {
			echo '<div class="bespari-notice bespari-notice--error"><span>' . esc_html__( 'تسویه یافت نشد.', 'bespari-core' ) . '</span></div>';
			return;
		}

		echo '<div class="bespari-box bespari-box--white">';
		echo '<h3 class="bespari-box__title">' . esc_html( $settlement->title ) . ' ' . $this->status_badge( $settlement->status ) . '</h3>';
		echo '<table class="bespari-table widefat"><tbody>';
		echo '<tr><th>' . esc_html__( 'کانال', 'bespari-core' ) . '</th><td>' . esc_html( $settlement->channel_name ?: (string) $settlement->channel_id ) . '</td></tr>';
		echo '<tr><th>' . esc_html__( 'بازه', 'bespari-core' ) . '</th><td>' . esc_html( $settlement->period_start ) . ' — ' . esc_html( $settlement->period_end ) . '</td></tr>';
		echo '<tr><th>' . esc_html__( 'تعداد سفارش', 'bespari-core' ) . '</th><td>' . esc_html( $settlement->total_orders ) . '</td></tr>';
		echo '<tr><th>' . esc_html__( 'ناخالص', 'bespari-core' ) . '</th><td>' . esc_html( Helpers::format_money( $settlement->total_gross ) ) . '</td></tr>';
		echo '<tr><th>' . esc_html__( 'کسورات', 'bespari-core' ) . '</th><td>' . esc_html( Helpers::format_money( $settlement->total_deductions ) ) . '</td></tr>';
		echo '<tr><th>' . esc_html__( 'خالص', 'bespari-core' ) . '</th><td>' . esc_html( Helpers::format_money( $settlement->total_net ) ) . '</td></tr>';
		echo '<tr><th>' . esc_html__( 'سود', 'bespari-core' ) . '</th><td>' . esc_html( Helpers::format_money( $settlement->total_profit ) ) . '</td></tr>';
		if ( $settlement->paid_at ) {
			echo '<tr><th>' . esc_html__( 'تاریخ پرداخت', 'bespari-core' ) . '</th><td>' . esc_html( $settlement->paid_at ) . '</td></tr>';
		}
		echo '</tbody></table>';

		if ( 'pending' === $settlement->status ) {
			$paid_url = $this->admin_action_url( 'mark_settlement_paid', array( 'id' => $settlement->id ) );
			echo '<p><a href="' . esc_url( $paid_url ) . '" class="button button-primary">' . esc_html__( 'ثبت پرداخت', 'bespari-core' ) . '</a></p>';
		}
		echo '</div>';

		// سفارش‌های این تسویه.
		$repo   = new SettlementRepository();
		$orders = $repo->get_orders( $id );

		echo '<div class="bespari-box bespari-box--white" style="margin-top:16px;">';
		echo '<h3 class="bespari-box__title">' . esc_html__( 'سفارش‌های این تسویه', 'bespari-core' ) . '</h3>';
		if ( empty( $orders ) ) {
			echo '<p class="description">' . esc_html__( 'سفارشی یافت نشد.', 'bespari-core' ) . '</p>';
		} else {
			echo '<table class="bespari-table widefat striped"><thead><tr>';
			echo '<th>' . esc_html__( 'شماره سفارش', 'bespari-core' ) . '</th>';
			echo '<th>' . esc_html__( 'مشتری', 'bespari-core' ) . '</th>';
			echo '<th>' . esc_html__( 'ناخالص', 'bespari-core' ) . '</th>';
			echo '<th>' . esc_html__( 'خالص', 'bespari-core' ) . '</th>';
			echo '<th>' . esc_html__( 'تاریخ', 'bespari-core' ) . '</th>';
			echo '</tr></thead><tbody>';
			foreach ( $orders as $o ) {
				echo '<tr>';
				echo '<td>' . esc_html( $o->order_number ) . '</td>';
				echo '<td>' . esc_html( $o->customer_name ?: '-' ) . '</td>';
				echo '<td>' . esc_html( Helpers::format_money( $o->total_gross ) ) . '</td>';
				echo '<td>' . esc_html( Helpers::format_money( $o->total_net ) ) . '</td>';
				echo '<td><span class="bespari-muted">' . esc_html( $o->ordered_at ) . '</span></td>';
				echo '</tr>';
			}
			echo '</tbody></table>';
		}
		echo '</div>';

		$back_url = add_query_arg( array( 'page' => 'bespari-settlements' ), admin_url( 'admin.php' ) );
		echo '<p><a href="' . esc_url( $back_url ) . '" class="button">' . esc_html__( 'بازگشت به لیست', 'bespari-core' ) . '</a></p>';
	}

	private function status_badge( string $status ): string {
		if ( 'paid' === $status ) {
			return '<span class="bespari-badge bespari-badge--success">' . esc_html__( 'پرداخت‌شده', 'bespari-core' ) . '</span>';
		}
		return '<span class="bespari-badge bespari-badge--warning">' . esc_html__( 'در انتظار', 'bespari-core' ) . '</span>';
	}
}
