<?php
/**
 * صفحه کانال‌های فروش.
 *
 * @package Bespari\Admin\Pages
 */

namespace Bespari\Admin\Pages;

use Bespari\Modules\Channel\ChannelService;

// جلوگیری از دسترسی مستقیم.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ChannelPage extends BasePage {

	protected string $slug = 'bespari-channels';
	protected string $cap  = 'bespari_manage_channels';

	public function render(): void {
		if ( ! $this->can_access() ) {
			wp_die( esc_html__( 'شما دسترسی لازم را ندارید.', 'bespari-core' ) );
		}

		$tab = $this->current_tab( 'list' );

		// حالت ویرایش: اگر id داده شده باشد تب را به edit ببر.
		$edit_id = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0; // phpcs:ignore
		if ( $edit_id && 'list' === $tab ) {
			$tab = 'edit';
		}

		echo '<div class="wrap bespari-wrap">';
		$this->page_header( __( 'کانال‌های فروش', 'bespari-core' ), __( 'مدیریت کانال‌ها، درصد افزایش قیمت، کارمزدها و بازه‌های تسویه.', 'bespari-core' ) );
		$this->render_notice();
		$this->render_tabs( $tab, array(
			'list' => __( 'لیست کانال‌ها', 'bespari-core' ),
			'add'  => __( 'افزودن کانال', 'bespari-core' ),
		) );

		if ( 'add' === $tab ) {
			$this->render_form( null );
		} elseif ( 'edit' === $tab && $edit_id ) {
			$service = new ChannelService();
			$channel = $service->get( $edit_id );
			if ( ! $channel ) {
				echo '<div class="bespari-notice bespari-notice--error"><span>' . esc_html__( 'کانال یافت نشد.', 'bespari-core' ) . '</span></div>';
			} else {
				$this->render_form( $channel );
			}
		} else {
			$this->render_list();
		}

		echo '</div>';
	}

	private function render_list(): void {
		$service  = new ChannelService();
		$channels = $service->list();

		if ( empty( $channels ) ) {
			echo '<div class="bespari-empty"><p>' . esc_html__( 'هنوز کانالی ثبت نشده است. از تب «افزودن کانال» شروع کنید.', 'bespari-core' ) . '</p></div>';
			return;
		}

		echo '<table class="bespari-table widefat striped">';
		echo '<thead><tr>';
		echo '<th>' . esc_html__( 'نام', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'اسلاگ', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'وضعیت', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'افزایش قیمت', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'کارمزد', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'تسویه', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'عملیات', 'bespari-core' ) . '</th>';
		echo '</tr></thead><tbody>';

		foreach ( $channels as $ch ) {
			$edit_url   = add_query_arg( array( 'page' => 'bespari-channels', 'id' => $ch->id ), admin_url( 'admin.php' ) );
			$delete_url = $this->admin_action_url( 'delete_channel', array( 'id' => $ch->id ) );
			$toggle_url = $this->admin_action_url( 'toggle_channel', array( 'id' => $ch->id ) );
			$badge_cls  = 1 === $ch->status ? 'bespari-badge--success' : 'bespari-badge--muted';

			echo '<tr>';
			echo '<td><strong>' . esc_html( $ch->name ) . '</strong>' . ( $ch->is_marketplace ? ' <span class="bespari-badge bespari-badge--info">' . esc_html__( 'مارکت‌پلیس', 'bespari-core' ) . '</span>' : '' ) . '</td>';
			echo '<td><code>' . esc_html( $ch->slug ) . '</code></td>';
			echo '<td><span class="bespari-badge ' . esc_attr( $badge_cls ) . '">' . esc_html( $ch->status_label() ) . '</span></td>';
			echo '<td>' . esc_html( \Bespari\Support\Helpers::format_percent( $ch->price_markup_percent ) ) . '</td>';
			echo '<td>' . esc_html( \Bespari\Support\Helpers::format_percent( $ch->commission_percent ) ) . '</td>';
			echo '<td>' . esc_html( $ch->settlement_label() ) . '</td>';
			echo '<td class="bespari-actions">';
			echo '<a href="' . esc_url( $edit_url ) . '" class="button button-small">' . esc_html__( 'ویرایش', 'bespari-core' ) . '</a> ';
			echo '<a href="' . esc_url( $toggle_url ) . '" class="button button-small">' . esc_html( 1 === $ch->status ? __( 'غیرفعال‌سازی', 'bespari-core' ) : __( 'فعال‌سازی', 'bespari-core' ) ) . '</a> ';
			echo '<a href="' . esc_url( $delete_url ) . '" class="button button-small button-link-delete bespari-confirm-delete" data-message="' . esc_attr__( 'آیا از حذف این کانال اطمینان دارید؟', 'bespari-core' ) . '">' . esc_html__( 'حذف', 'bespari-core' ) . '</a>';
			echo '</td>';
			echo '</tr>';
		}

		echo '</tbody></table>';
	}

	/**
	 * فرم افزودن/ویرایش کانال.
	 *
	 * @param \Bespari\Modules\Channel\ChannelModel|null $channel
	 */
	private function render_form( $channel ): void {
		$is_edit = null !== $channel;
		$action  = admin_url( 'admin-post.php' );

		$val = function( string $key, $default = '' ) use ( $channel ) {
			if ( ! $channel ) {
				return $default;
			}
			return $channel->$key ?? $default;
		};

		echo '<form method="post" action="' . esc_url( $action ) . '" class="bespari-form">';
		wp_nonce_field( 'bespari_save_channel', 'bespari_nonce' );
		echo '<input type="hidden" name="action" value="bespari_save_channel" />';
		if ( $is_edit ) {
			echo '<input type="hidden" name="channel_id" value="' . esc_attr( $channel->id ) . '" />';
		}

		echo '<table class="form-table">';

		$this->form_row_text( 'channel[name]', __( 'نام کانال', 'bespari-core' ), (string) $val( 'name' ), true, __( 'مثلاً: دیجی‌کالا', 'bespari-core' ) );
		$this->form_row_select( 'channel[status]', __( 'وضعیت', 'bespari-core' ), (int) $val( 'status', 1 ), array( 1 => __( 'فعال', 'bespari-core' ), 0 => __( 'غیرفعال', 'bespari-core' ) ) );
		$this->form_row_select( 'channel[is_marketplace]', __( 'نوع', 'bespari-core' ), (int) $val( 'is_marketplace', 0 ), array( 0 => __( 'فروشگاه عادی', 'bespari-core' ), 1 => __( 'مارکت‌پلیس', 'bespari-core' ) ) );
		$this->form_row_number( 'channel[price_markup_percent]', __( 'درصد افزایش قیمت پایه (%)', 'bespari-core' ), (float) $val( 'price_markup_percent', 0 ), __( 'روی قیمت پایه اعمال می‌شود.', 'bespari-core' ) );
		$this->form_row_number( 'channel[credit_markup_percent]', __( 'درصد افزایش فروش اعتباری (%)', 'bespari-core' ), (float) $val( 'credit_markup_percent', 0 ) );
		$this->form_row_number( 'channel[commission_percent]', __( 'درصد پورسانت این کانال برای بازاریاب (%)', 'bespari-core' ), (float) $val( 'commission_percent', 0 ), __( 'برای بازاریابانی که درصد سفارشی ندارند، همین درصد ملاک است. مثلاً دیجی‌کالا ۲٪، باسلام ۵٪.', 'bespari-core' ) );
		$this->form_row_number( 'channel[production_priority]', __( 'الویت تولید در خط تولید', 'bespari-core' ), (int) $val( 'production_priority', 0 ), __( 'عدد کوچک‌تر = الویت بالاتر. مثلاً دیجی‌کالا ۱، باسلام ۲. سفارش‌های هر کانال در خط تولید بر اساس این الویت مرتب می‌شوند.', 'bespari-core' ) );
		$this->form_row_text( 'channel[shipping_window]', __( 'بازه ارسال سفارشات', 'bespari-core' ), (string) $val( 'shipping_window' ), false, __( 'مثلاً: ۸ تا ۱۲ صبح', 'bespari-core' ) );
		$this->form_row_number( 'channel[processing_fee_percent]', __( 'کارمزد پردازش (%)', 'bespari-core' ), (float) $val( 'processing_fee_percent', 0 ) );
		$this->form_row_number( 'channel[shipping_fee_percent]', __( 'هزینه ارسال (%)', 'bespari-core' ), (float) $val( 'shipping_fee_percent', 0 ) );
		$this->form_row_number( 'channel[advertising_fee_percent]', __( 'هزینه تبلیغات (%)', 'bespari-core' ), (float) $val( 'advertising_fee_percent', 0 ) );
		$this->form_row_number( 'channel[gateway_fee_percent]', __( 'کارمزد درگاه (%)', 'bespari-core' ), (float) $val( 'gateway_fee_percent', 0 ) );
		$this->form_row_number( 'channel[fixed_fee]', __( 'کارمزد ثابت', 'bespari-core' ), (float) $val( 'fixed_fee', 0 ) );
		$this->form_row_number( 'channel[tax_percent]', __( 'مالیات (%)', 'bespari-core' ), (float) $val( 'tax_percent', 0 ) );
		$this->form_row_select( 'channel[tax_mode]', __( 'حالت مالیات', 'bespari-core' ), (string) $val( 'tax_mode', 'inclusive' ), array( 'inclusive' => __( 'شامل در قیمت', 'bespari-core' ), 'exclusive' => __( 'افزوده به قیمت', 'bespari-core' ) ) );
		$this->form_row_select( 'channel[settlement_mode]', __( 'حالت تسویه', 'bespari-core' ), (string) $val( 'settlement_mode', 'invoice' ), array(
			'invoice'   => __( 'فاکتور به فاکتور (هر سفارش جداگانه)', 'bespari-core' ),
			'batch'     => __( 'محموله به محموله (جمع چند سفارش)', 'bespari-core' ),
			'statement' => __( 'صورت‌حساب به صورت‌حساب (جمع چند محموله)', 'bespari-core' ),
		) );
		$this->form_row_number( 'channel[settlement_days]', __( 'روزهای دوره صورت‌حساب', 'bespari-core' ), (int) $val( 'settlement_days', 0 ), __( 'فقط در حالت صورت‌حساب به صورت‌حساب استفاده می‌شود.', 'bespari-core' ) );
		$this->form_row_text( 'channel[logo]', __( 'آدرس لوگو', 'bespari-core' ), (string) $val( 'logo' ) );
		$this->form_row_text( 'channel[webhook_url]', __( 'آدرس وب‌هوک', 'bespari-core' ), (string) $val( 'webhook_url' ) );
		$this->form_row_number( 'channel[sort_order]', __( 'ترتیب نمایش', 'bespari-core' ), (int) $val( 'sort_order', 0 ) );
		$this->form_row_textarea( 'channel[description]', __( 'توضیحات', 'bespari-core' ), (string) $val( 'description' ) );

		echo '</table>';

		submit_button( $is_edit ? __( 'به‌روزرسانی کانال', 'bespari-core' ) : __( 'ایجاد کانال', 'bespari-core' ), 'primary', 'submit' );
		echo '</form>';
	}

	private function form_row_text( string $name, string $label, string $value, bool $required = false, string $placeholder = '' ): void {
		echo '<tr><th scope="row"><label>' . esc_html( $label ) . ( $required ? ' <span class="required">*</span>' : '' ) . '</label></th>';
		echo '<td><input type="text" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '" class="regular-text" placeholder="' . esc_attr( $placeholder ) . '"' . ( $required ? ' required' : '' ) . ' /></td></tr>';
	}

	private function form_row_number( string $name, string $label, $value, string $desc = '' ): void {
		echo '<tr><th scope="row"><label>' . esc_html( $label ) . '</label></th>';
		echo '<td><input type="number" step="0.01" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '" class="small-text" />';
		if ( '' !== $desc ) {
			echo '<p class="description">' . esc_html( $desc ) . '</p>';
		}
		echo '</td></tr>';
	}

	private function form_row_select( string $name, string $label, $selected, array $options ): void {
		echo '<tr><th scope="row"><label>' . esc_html( $label ) . '</label></th><td><select name="' . esc_attr( $name ) . '">';
		foreach ( $options as $val => $title ) {
			echo '<option value="' . esc_attr( $val ) . '"' . selected( $selected, $val, false ) . '>' . esc_html( $title ) . '</option>';
		}
		echo '</select></td></tr>';
	}

	private function form_row_textarea( string $name, string $label, string $value ): void {
		echo '<tr><th scope="row"><label>' . esc_html( $label ) . '</label></th>';
		echo '<td><textarea name="' . esc_attr( $name ) . '" rows="3" class="large-text">' . esc_textarea( $value ) . '</textarea></td></tr>';
	}
}
