<?php
/**
 * صفحه سفارشات.
 *
 * @package Bespari\Admin\Pages
 */

namespace Bespari\Admin\Pages;

use Bespari\Modules\Order\OrderService;
use Bespari\Modules\Order\OrderRepository;
use Bespari\Modules\Channel\ChannelService;
use Bespari\Modules\Brand\BrandService;
use Bespari\Modules\Product\ProductService;
use Bespari\Support\Helpers;

// جلوگیری از دسترسی مستقیم.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class OrderPage extends BasePage {

	protected string $slug = 'bespari-orders';
	protected string $cap  = 'bespari_manage_orders';

	public function render(): void {
		if ( ! $this->can_access() ) {
			wp_die( esc_html__( 'شما دسترسی لازم را ندارید.', 'bespari-core' ) );
		}

		$tab     = $this->current_tab( 'list' );
		$edit_id = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0; // phpcs:ignore
		if ( $edit_id && 'list' === $tab ) {
			$tab = 'edit';
		}

		echo '<div class="wrap bespari-wrap">';
		$this->page_header( __( 'سفارشات', 'bespari-core' ), __( 'ثبت سفارش چندآیتمی با محاسبه زنده از PricingEngine + snapshot مالی.', 'bespari-core' ) );
		$this->render_notice();

		$channel_id    = isset( $_GET['channel_id'] ) ? (int) $_GET['channel_id'] : 0; // phpcs:ignore
		$view_invoice  = isset( $_GET['invoice'] ) ? (int) $_GET['invoice'] : 0; // phpcs:ignore
		$channel       = null;

		if ( $channel_id > 0 ) {
			$channel = ( new ChannelService() )->get( $channel_id );
		}

		// نمای درختوار صورت‌حساب (فقط در حالت صورت‌حساب به صورت‌حساب).
		if ( $view_invoice > 0 && $channel && 'statement' === $channel->settlement_mode ) {
			$this->render_invoice_tree( $view_invoice, $channel );
			echo '</div>';
			return;
		}

		$this->render_channel_tabs( $channel_id );

		$this->render_tabs( $tab, array(
			'list' => __( 'لیست سفارشات', 'bespari-core' ),
		) );

		if ( 'edit' === $tab && $edit_id ) {
			$service = new OrderService();
			$order   = $service->get( $edit_id );
			if ( ! $order ) {
				echo '<div class="bespari-notice bespari-notice--error"><span>' . esc_html__( 'سفارش یافت نشد.', 'bespari-core' ) . '</span></div>';
			} else {
				$this->render_form( $order );
			}
		} elseif ( $channel_id > 0 && $channel && 'invoice' !== $channel->settlement_mode ) {
			// کانال محموله‌محور یا صورت‌حساب‌محور — نمای سه‌ساب‌تبی.
			$this->render_channel_view( $channel );
		} else {
			$this->render_filters();
			$this->render_list();
		}

		echo '</div>';
	}

	/**
	 * ردیف تب‌های کانال‌های موجود بالای صفحه.
	 */
	private function render_channel_tabs( int $current_channel ): void {
		$channels = ( new ChannelService() )->list( true );
		if ( empty( $channels ) ) {
			return;
		}

		echo '<div class="bespari-channel-tabs" style="margin-bottom:10px;">';
		echo '<a href="' . esc_url( add_query_arg( array( 'page' => 'bespari-orders' ), admin_url( 'admin.php' ) ) ) . '" class="button' . ( 0 === $current_channel ? ' button-primary' : '' ) . '">' . esc_html__( 'همه', 'bespari-core' ) . '</a> ';
		foreach ( $channels as $ch ) {
			$url = add_query_arg( array( 'page' => 'bespari-orders', 'channel_id' => (int) $ch->id ), admin_url( 'admin.php' ) );
			echo '<a href="' . esc_url( $url ) . '" class="button' . ( $current_channel === (int) $ch->id ? ' button-primary' : '' ) . '">' . esc_html( $ch->name ) . '<span class="bespari-muted" style="margin-inline-start:6px;">(' . esc_html( $ch->settlement_label() ) . ')</span></a> ';
		}
		echo '</div>';
	}

	/**
	 * نمای کانال بر اساس حالت تسویه — ساب‌تب‌ها.
	 *
	 * @param \Bespari\Modules\Channel\ChannelModel $channel
	 */
	private function render_channel_view( $channel ): void {
		$subtab = isset( $_GET['subtab'] ) ? sanitize_key( wp_unslash( $_GET['subtab'] ) ) : 'orders'; // phpcs:ignore

		// حالت صورت‌حساب به صورت‌حساب: سه ساب‌تب؛ حالت محموله به محموله: دو ساب‌تب.
		$is_statement = 'statement' === $channel->settlement_mode;

		$tabs = array( 'orders' => __( 'سفارشات', 'bespari-core' ), 'batches' => __( 'محموله‌ها', 'bespari-core' ) );
		if ( $is_statement ) {
			$tabs['invoices'] = __( 'صورت‌حساب‌ها', 'bespari-core' );
		}

		echo '<div style="margin-bottom:8px;">';
		foreach ( $tabs as $key => $label ) {
			$url = add_query_arg( array( 'page' => 'bespari-orders', 'channel_id' => (int) $channel->id, 'subtab' => $key ), admin_url( 'admin.php' ) );
			echo '<a href="' . esc_url( $url ) . '" class="button' . ( $subtab === $key ? ' button-primary' : '' ) . '" style="margin-inline-end:4px;">' . esc_html( $label ) . '</a>';
		}
		echo '</div>';

		if ( 'batches' === $subtab ) {
			$this->render_batches_view( $channel, $is_statement );
		} elseif ( 'invoices' === $subtab && $is_statement ) {
			$this->render_invoices_view( $channel );
		} else {
			// سفارشات بدون محموله.
			$this->render_filters();
			$this->render_unbatched_list( $channel );
		}
	}

	/**
	 * لیست سفارشات بدون محموله/صورت‌حساب + فرم تبدیل به محموله.
	 */
	private function render_unbatched_list( $channel ): void {
		global $wpdb;
		$orders_table = Helpers::table( 'orders' );

		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT id, order_number, customer_name, sale_type, status, settlement_status, total_gross, total_net, total_profit, ordered_at FROM {$orders_table} WHERE channel_id = %d AND batch_id = 0 AND channel_invoice_id = 0 AND settlement_status = 'pending' ORDER BY id DESC LIMIT 100", (int) $channel->id ) ); // phpcs:ignore

		if ( empty( $rows ) ) {
			echo '<div class="bespari-empty"><p>' . esc_html__( 'سفارشی در انتظار محموله نیست.', 'bespari-core' ) . '</p></div>';
			return;
		}

		$can_manage = current_user_can( 'bespari_manage_settlement' );

		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'bespari_create_batch', 'bespari_nonce' );
		echo '<input type="hidden" name="action" value="bespari_create_batch" />';
		echo '<input type="hidden" name="channel_id" value="' . esc_attr( $channel->id ) . '" />';

		echo '<div style="margin-bottom:8px;">';
		if ( $can_manage ) {
			echo '<button type="submit" class="button button-primary">' . esc_html__( 'تبدیل سفارشات تیک‌خورده به محموله', 'bespari-core' ) . '</button> ';
		}
		echo '</div>';

		echo '<table class="bespari-table widefat striped">';
		echo '<thead><tr>';
		if ( $can_manage ) {
			echo '<th><input type="checkbox" onclick="var c=this.closest(\'table\').querySelectorAll(\'tbody input[type=checkbox]\');for(var i=0;i<c.length;i++)c[i].checked=this.checked;" /></th>';
		}
		echo '<th>' . esc_html__( 'شماره سفارش', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'مشتری', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'نوع فروش', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'وضعیت', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'مبلغ ناخالص', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'تاریخ', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'عملیات', 'bespari-core' ) . '</th>';
		echo '</tr></thead><tbody>';

		foreach ( $rows as $o ) {
			$edit_url = add_query_arg( array( 'page' => 'bespari-orders', 'id' => (int) $o->id ), admin_url( 'admin.php' ) );
			echo '<tr>';
			if ( $can_manage ) {
				echo '<td><input type="checkbox" name="order_ids[]" value="' . esc_attr( $o->id ) . '" /></td>';
			}
			echo '<td><a href="' . esc_url( $edit_url ) . '"><strong>' . esc_html( $o->order_number ) . '</strong></a></td>';
			echo '<td>' . esc_html( $o->customer_name ?: '-' ) . '</td>';
			echo '<td>' . esc_html( 'credit' === $o->sale_type ? __( 'اعتباری', 'bespari-core' ) : __( 'نقدی', 'bespari-core' ) ) . '</td>';
			echo '<td>' . wp_kses_post( $this->status_badge( $o->status, $o->status ) ) . '</td>';
			echo '<td>' . esc_html( Helpers::format_money( $o->total_gross ) ) . '</td>';
			echo '<td><span class="bespari-muted">' . esc_html( $o->ordered_at ) . '</span></td>';
			echo '<td><a href="' . esc_url( $edit_url ) . '" class="button button-small">' . esc_html__( 'مشاهده', 'bespari-core' ) . '</a></td>';
			echo '</tr>';
		}

		echo '</tbody></table>';
		echo '</form>';
		echo '<p class="description">' . sprintf( esc_html__( 'مجموع %d سفارش در انتظار محموله', 'bespari-core' ), count( $rows ) ) . '</p>';
	}

	/**
	 * نمای محموله‌ها — لیست محموله‌های بدون صورت‌حساب + اکشن‌ها.
	 */
	private function render_batches_view( $channel, bool $is_statement ): void {
		$repo  = new \Bespari\Modules\Batch\BatchRepository();
		$res   = $repo->paginate( array( 'channel_id' => (int) $channel->id, 'invoice_id' => 0 ), 1, 100 );
		$items = $res['items'];

		$can_manage  = current_user_can( 'bespari_manage_settlement' );
		$can_delete  = current_user_can( 'bespari_manage_settings' );
		$base_args   = array( 'page' => 'bespari-orders', 'channel_id' => (int) $channel->id, 'subtab' => 'batches' );

		// فرم تبدیل چند محموله به صورت‌حساب (فقط حالت statement).
		if ( $is_statement && $can_manage && ! empty( $items ) ) {
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="margin-bottom:12px;">';
			wp_nonce_field( 'bespari_create_invoice', 'bespari_nonce' );
			echo '<input type="hidden" name="action" value="bespari_create_invoice" />';
			echo '<input type="hidden" name="channel_id" value="' . esc_attr( $channel->id ) . '" />';
		}

		echo '<table class="bespari-table widefat striped">';
		echo '<thead><tr>';
		if ( $is_statement && $can_manage ) {
			echo '<th><input type="checkbox" onclick="var c=this.closest(\'table\').querySelectorAll(\'tbody input[type=checkbox]\');for(var i=0;i<c.length;i++)c[i].checked=this.checked;" /></th>';
		}
		echo '<th>' . esc_html__( 'کد محموله', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'تعداد سفارش', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'نقدی', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'اعتباری', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'وضعیت', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'تاریخ ارسال', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'عملیات', 'bespari-core' ) . '</th>';
		echo '</tr></thead><tbody>';

		if ( empty( $items ) ) {
			echo '<tr><td colspan="8">' . esc_html__( 'محموله‌ای موجود نیست.', 'bespari-core' ) . '</td></tr>';
		}

		foreach ( $items as $b ) {
			echo '<tr>';
			if ( $is_statement && $can_manage ) {
				echo '<td><input type="checkbox" name="batch_ids[]" value="' . esc_attr( $b->id ) . '" /></td>';
			}
			echo '<td><code>' . esc_html( $b->batch_code ) . '</code></td>';
			echo '<td>' . (int) $b->total_orders . '</td>';
			echo '<td>' . esc_html( Helpers::format_money( $b->cash_total ) ) . '</td>';
			echo '<td>' . esc_html( Helpers::format_money( $b->credit_total ) ) . '</td>';
			echo '<td><span class="bespari-badge ' . esc_attr( $b->status_badge() ) . '">' . esc_html( $b->status_label() ) . '</span></td>';
			echo '<td><span class="bespari-muted">' . esc_html( $b->shipped_at ?: '—' ) . '</span></td>';
			echo '<td class="bespari-actions">';

			if ( $can_manage ) {
				if ( 'pending' === $b->status ) {
					$ship_url = $this->admin_action_url( 'ship_batch', array( 'id' => $b->id ) );
					echo '<a href="' . esc_url( $ship_url ) . '" class="button button-small">' . esc_html__( 'ثبت ارسال', 'bespari-core' ) . '</a> ';
				} elseif ( 'shipped' === $b->status ) {
					echo $this->settle_inline_form( 'bespari_settle_batch_cash', $b->id, (int) $channel->id, __( 'کد پیگیری تسویه نقدی', 'bespari-core' ) ) . ' ';
				} elseif ( 'partial_settled' === $b->status ) {
					echo $this->settle_inline_form( 'bespari_settle_batch_credit', $b->id, (int) $channel->id, __( 'کد پیگیری تسویه اعتباری', 'bespari-core' ) ) . ' ';
				}
			}

			if ( $can_delete && 'pending' === $b->status ) {
				$delete_url = $this->admin_action_url( 'delete_batch', array( 'id' => $b->id ) );
				echo '<a href="' . esc_url( $delete_url ) . '" class="button button-small button-link-delete bespari-confirm-delete" data-message="' . esc_attr__( 'حذف محموله، سفارشات آن به لیست سفارشات برمی‌گردند. مطمئن هستید؟', 'bespari-core' ) . '">' . esc_html__( 'حذف', 'bespari-core' ) . '</a>';
			}
			echo '</td>';
			echo '</tr>';
		}

		echo '</tbody></table>';

		// فرم ثبت صورت‌حساب از محموله‌های تیک‌خورده.
		if ( $is_statement && $can_manage && ! empty( $items ) ) {
			echo '<h3 style="margin-top:14px;">' . esc_html__( 'ترکیب محموله‌های تیک‌خورده به صورت‌حساب', 'bespari-core' ) . '</h3>';
			echo '<table class="form-table">';
			echo '<tr><th><label>' . esc_html__( 'چند روزه', 'bespari-core' ) . '</label></th><td><input type="number" name="period_days" min="0" class="small-text" /></td></tr>';
			echo '<tr><th><label>' . esc_html__( 'تاریخ تسویه نقدی', 'bespari-core' ) . '</label></th><td><input type="date" name="cash_due_date" /></td></tr>';
			echo '<tr><th><label>' . esc_html__( 'تاریخ تسویه اعتباری', 'bespari-core' ) . '</label></th><td><input type="date" name="credit_due_date" /></td></tr>';
			echo '</table>';
			echo '<button type="submit" class="button button-primary">' . esc_html__( 'ایجاد صورت‌حساب', 'bespari-core' ) . '</button>';
			echo '</form>';
		}
	}

	/**
	 * فرم کوچک inline ثبت کد پیگیری تسویه.
	 */
	private function settle_inline_form( string $action, int $id, int $channel_id, string $placeholder ): string {
		ob_start();
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:inline-block;">';
		wp_nonce_field( $action, 'bespari_nonce' );
		echo '<input type="hidden" name="action" value="' . esc_attr( $action ) . '" />';
		echo '<input type="hidden" name="id" value="' . esc_attr( $id ) . '" />';
		echo '<input type="hidden" name="channel_id" value="' . esc_attr( $channel_id ) . '" />';
		echo '<input type="text" name="tracking_code" placeholder="' . esc_attr( $placeholder ) . '" class="small-text" required />';
		echo '<button type="submit" class="button button-small">' . esc_html__( 'ثبت', 'bespari-core' ) . '</button>';
		echo '</form>';
		return (string) ob_get_clean();
	}

	/**
	 * نمای صورت‌حساب‌ها — لیست + اکشن‌های دو مرحله‌ای تسویه.
	 */
	private function render_invoices_view( $channel ): void {
		$repo  = new \Bespari\Modules\ChannelInvoice\ChannelInvoiceRepository();
		$res   = $repo->paginate( array( 'channel_id' => (int) $channel->id ), 1, 100 );
		$items = $res['items'];

		$can_manage = current_user_can( 'bespari_manage_settlement' );

		echo '<table class="bespari-table widefat striped">';
		echo '<thead><tr>';
		echo '<th>' . esc_html__( 'شماره صورت‌حساب', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'چند روزه', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'تسویه نقدی (تاریخ)', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'تسویه اعتباری (تاریخ)', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'نقدی', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'اعتباری', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'تعداد محموله', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'وضعیت', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'عملیات', 'bespari-core' ) . '</th>';
		echo '</tr></thead><tbody>';

		if ( empty( $items ) ) {
			echo '<tr><td colspan="9">' . esc_html__( 'صورت‌حسابی موجود نیست.', 'bespari-core' ) . '</td></tr>';
		}

		foreach ( $items as $inv ) {
			$tree_url = add_query_arg( array( 'page' => 'bespari-orders', 'channel_id' => (int) $channel->id, 'invoice' => (int) $inv->id ), admin_url( 'admin.php' ) );
			echo '<tr>';
			echo '<td><a href="' . esc_url( $tree_url ) . '"><strong><code>' . esc_html( $inv->invoice_number ) . '</code></strong></a></td>';
			echo '<td>' . (int) $inv->period_days . '</td>';
			echo '<td>' . esc_html( $inv->cash_due_date ?: '—' ) . '</td>';
			echo '<td>' . esc_html( $inv->credit_due_date ?: '—' ) . '</td>';
			echo '<td>' . esc_html( Helpers::format_money( $inv->cash_total ) ) . '</td>';
			echo '<td>' . esc_html( Helpers::format_money( $inv->credit_total ) ) . '</td>';
			echo '<td>' . (int) $inv->total_batches . '</td>';
			echo '<td><span class="bespari-badge ' . esc_attr( $inv->status_badge() ) . '">' . esc_html( $inv->status_label() ) . '</span></td>';
			echo '<td class="bespari-actions">';

			if ( $can_manage ) {
				if ( 'settling' === $inv->status ) {
					echo $this->settle_inline_form( 'bespari_settle_invoice_cash', $inv->id, (int) $channel->id, __( 'کد پیگیری تسویه نقدی', 'bespari-core' ) ) . ' ';
				} elseif ( 'partial_settled' === $inv->status ) {
					echo $this->settle_inline_form( 'bespari_settle_invoice_credit', $inv->id, (int) $channel->id, __( 'کد پیگیری تسویه اعتباری', 'bespari-core' ) ) . ' ';
				}
			}

			echo '<a href="' . esc_url( $tree_url ) . '" class="button button-small">' . esc_html__( 'نمای درختوار', 'bespari-core' ) . '</a>';
			echo '</td>';
			echo '</tr>';
		}

		echo '</tbody></table>';
	}

	/**
	 * نمای درختوار صورت‌حساب: صورت‌حساب → محموله‌ها → سفارشات.
	 */
	private function render_invoice_tree( int $invoice_id, $channel ): void {
		$service = new \Bespari\Modules\ChannelInvoice\ChannelInvoiceService();
		$tree    = $service->get_tree( $invoice_id );

		$invoice = $tree['invoice'];
		if ( ! $invoice ) {
			echo '<div class="bespari-notice bespari-notice--error"><span>' . esc_html__( 'صورت‌حساب یافت نشد.', 'bespari-core' ) . '</span></div>';
			return;
		}

		$back_url = add_query_arg( array( 'page' => 'bespari-orders', 'channel_id' => (int) $channel->id, 'subtab' => 'invoices' ), admin_url( 'admin.php' ) );
		echo '<a href="' . esc_url( $back_url ) . '" class="button" style="margin-bottom:10px;">&laquo; ' . esc_html__( 'بازگشت به صورت‌حساب‌ها', 'bespari-core' ) . '</a>';

		// هدر صورت‌حساب.
		echo '<h2 style="margin-top:0;"><code>' . esc_html( $invoice->invoice_number ) . '</code> <span class="bespari-badge ' . esc_attr( $invoice->status_badge() ) . '">' . esc_html( $invoice->status_label() ) . '</span></h2>';
		echo '<p>' . esc_html__( 'کانال:', 'bespari-core' ) . ' <strong>' . esc_html( $channel->name ) . '</strong> | ' . esc_html__( 'دوره:', 'bespari-core' ) . ' ' . (int) $invoice->period_days . ' ' . esc_html__( 'روزه', 'bespari-core' ) . ' | ' . esc_html__( 'جمع نقدی:', 'bespari-core' ) . ' <strong>' . esc_html( Helpers::format_money( $invoice->cash_total ) ) . '</strong> | ' . esc_html__( 'جمع اعتباری:', 'bespari-core' ) . ' <strong>' . esc_html( Helpers::format_money( $invoice->credit_total ) ) . '</strong></p>';
		echo '<p class="description">' . esc_html__( 'تاریخ تسویه نقدی:', 'bespari-core' ) . ' ' . esc_html( $invoice->cash_due_date ?: '—' ) . ( $invoice->cash_tracking_code ? ' — ' . esc_html__( 'کد پیگیری:', 'bespari-core' ) . ' <code>' . esc_html( $invoice->cash_tracking_code ) . '</code>' : '' ) . ' | ' . esc_html__( 'تاریخ تسویه اعتباری:', 'bespari-core' ) . ' ' . esc_html( $invoice->credit_due_date ?: '—' ) . ( $invoice->credit_tracking_code ? ' — ' . esc_html__( 'کد پیگیری:', 'bespari-core' ) . ' <code>' . esc_html( $invoice->credit_tracking_code ) . '</code>' : '' ) . '</p>';

		// لیست محموله‌ها.
		foreach ( $tree['batches'] as $batch ) {
			echo '<h3 style="margin-top:16px;"><code>' . esc_html( $batch->batch_code ) . '</code> <span class="bespari-badge ' . esc_attr( $batch->status_badge() ) . '">' . esc_html( $batch->status_label() ) . '</span></h3>';

			// سفارشات این محموله.
			$orders = array_filter( $tree['orders'], fn( $o ) => $o['batch_id'] === (int) $batch->id );
			if ( empty( $orders ) ) {
				echo '<p class="description">' . esc_html__( 'سفارشی در این محموله نیست.', 'bespari-core' ) . '</p>';
				continue;
			}

			echo '<table class="bespari-table widefat striped" style="max-width:900px;">';
			echo '<thead><tr><th>' . esc_html__( 'شماره سفارش', 'bespari-core' ) . '</th><th>' . esc_html__( 'مشتری', 'bespari-core' ) . '</th><th>' . esc_html__( 'نوع فروش', 'bespari-core' ) . '</th><th>' . esc_html__( 'مبلغ', 'bespari-core' ) . '</th><th>' . esc_html__( 'تسویه', 'bespari-core' ) . '</th><th>' . esc_html__( 'عملیات', 'bespari-core' ) . '</th></tr></thead><tbody>';

			foreach ( $orders as $o ) {
				$edit_url = add_query_arg( array( 'page' => 'bespari-orders', 'id' => $o['order_id'] ), admin_url( 'admin.php' ) );
				echo '<tr>';
				echo '<td><strong>' . esc_html( $o['order_number'] ) . '</strong></td>';
				echo '<td>' . esc_html( $o['customer_name'] ?: '-' ) . '</td>';
				echo '<td>' . esc_html( 'credit' === $o['sale_type'] ? __( 'اعتباری', 'bespari-core' ) : __( 'نقدی', 'bespari-core' ) ) . '</td>';
				echo '<td>' . esc_html( Helpers::format_money( $o['total_net'] ) ) . '</td>';
				echo '<td>' . esc_html( 'settled' === $o['settlement_status'] ? __( 'تسویه‌شده', 'bespari-core' ) : __( 'در انتظار تسویه', 'bespari-core' ) ) . '</td>';
				echo '<td><a href="' . esc_url( $edit_url ) . '" class="button button-small">' . esc_html__( 'جزئیات سفارش', 'bespari-core' ) . '</a></td>';
				echo '</tr>';
			}

			echo '</tbody></table>';
		}
	}

	/**
	 * ثبت کد رهگیری سفارش (حالت فاکتور به فاکتور) → ارسال شده.
	 */
	private function render_order_tracking_action( int $order_id, int $channel_id = 0 ): string {
		ob_start();
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:inline-block;">';
		wp_nonce_field( 'bespari_order_tracking', 'bespari_nonce' );
		echo '<input type="hidden" name="action" value="bespari_order_tracking" />';
		echo '<input type="hidden" name="id" value="' . esc_attr( $order_id ) . '" />';
		echo '<input type="hidden" name="channel_id" value="' . esc_attr( $channel_id ) . '" />';
		echo '<input type="text" name="tracking_code" placeholder="' . esc_attr__( 'کد رهگیری', 'bespari-core' ) . '" class="small-text" required />';
		echo '<button type="submit" class="button button-small">' . esc_html__( 'ثبت کد رهگیری', 'bespari-core' ) . '</button>';
		echo '</form>';
		return (string) ob_get_clean();
	}

	/**
	 * ثبت کد ارجاع تسویه سفارش (حالت فاکتور به فاکتور) → تسویه شده.
	 */
	private function render_order_settle_action( int $order_id, int $channel_id = 0 ): string {
		ob_start();
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:inline-block;">';
		wp_nonce_field( 'bespari_order_settlement_ref', 'bespari_nonce' );
		echo '<input type="hidden" name="action" value="bespari_order_settlement_ref" />';
		echo '<input type="hidden" name="id" value="' . esc_attr( $order_id ) . '" />';
		echo '<input type="hidden" name="channel_id" value="' . esc_attr( $channel_id ) . '" />';
		echo '<input type="text" name="settlement_ref" placeholder="' . esc_attr__( 'کد ارجاع تسویه', 'bespari-core' ) . '" class="small-text" required />';
		echo '<button type="submit" class="button button-small">' . esc_html__( 'ثبت رسید تسویه', 'bespari-core' ) . '</button>';
		echo '</form>';
		return (string) ob_get_clean();
	}

	private function render_filters(): void {
		$channels = ( new ChannelService() )->list( true );
		$brands   = ( new BrandService() )->list( true );

		$search            = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : ''; // phpcs:ignore
		$filter_channel    = isset( $_GET['channel_id'] ) ? (int) $_GET['channel_id'] : 0; // phpcs:ignore
		$filter_brand      = isset( $_GET['brand_id'] ) ? (int) $_GET['brand_id'] : 0; // phpcs:ignore
		$filter_status     = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : ''; // phpcs:ignore
		$filter_payment    = isset( $_GET['payment_status'] ) ? sanitize_key( wp_unslash( $_GET['payment_status'] ) ) : ''; // phpcs:ignore
		$filter_settlement = isset( $_GET['settlement_status'] ) ? sanitize_key( wp_unslash( $_GET['settlement_status'] ) ) : ''; // phpcs:ignore
		$filter_sale_type  = isset( $_GET['sale_type'] ) ? sanitize_key( wp_unslash( $_GET['sale_type'] ) ) : ''; // phpcs:ignore
		$date_from         = isset( $_GET['date_from'] ) ? sanitize_text_field( wp_unslash( $_GET['date_from'] ) ) : ''; // phpcs:ignore
		$date_to           = isset( $_GET['date_to'] ) ? sanitize_text_field( wp_unslash( $_GET['date_to'] ) ) : ''; // phpcs:ignore

		echo '<form method="get" class="bespari-filters">';
		echo '<input type="hidden" name="page" value="bespari-orders" />';
		echo '<div class="bespari-filters__row">';
		echo '<input type="search" name="s" value="' . esc_attr( $search ) . '" placeholder="' . esc_attr__( 'شماره سفارش / نام مشتری', 'bespari-core' ) . '" class="regular-text" />';

		echo '<select name="channel_id"><option value="0">' . esc_html__( 'همه کانال‌ها', 'bespari-core' ) . '</option>';
		foreach ( $channels as $ch ) {
			echo '<option value="' . esc_attr( $ch->id ) . '"' . selected( $filter_channel, $ch->id, false ) . '>' . esc_html( $ch->name ) . '</option>';
		}
		echo '</select>';

		echo '<select name="brand_id"><option value="0">' . esc_html__( 'همه برندها', 'bespari-core' ) . '</option>';
		foreach ( $brands as $b ) {
			echo '<option value="' . esc_attr( $b->id ) . '"' . selected( $filter_brand, $b->id, false ) . '>' . esc_html( $b->name ) . '</option>';
		}
		echo '</select>';

		echo '<select name="status"><option value="">' . esc_html__( 'همه وضعیت‌ها', 'bespari-core' ) . '</option>';
		foreach ( array( 'pending' => __( 'در انتظار', 'bespari-core' ), 'confirmed' => __( 'تاییدشده', 'bespari-core' ), 'shipped' => __( 'ارسال‌شده', 'bespari-core' ), 'delivered' => __( 'تحویل‌شده', 'bespari-core' ), 'cancelled' => __( 'لغوشده', 'bespari-core' ), 'paid' => __( 'پرداخت‌شده', 'bespari-core' ) ) as $k => $label ) {
			echo '<option value="' . esc_attr( $k ) . '"' . selected( $filter_status, $k, false ) . '>' . esc_html( $label ) . '</option>';
		}
		echo '</select>';

		echo '<select name="sale_type"><option value="">' . esc_html__( 'نقدی/اعتباری', 'bespari-core' ) . '</option>';
		echo '<option value="cash"' . selected( $filter_sale_type, 'cash', false ) . '>' . esc_html__( 'نقدی', 'bespari-core' ) . '</option>';
		echo '<option value="credit"' . selected( $filter_sale_type, 'credit', false ) . '>' . esc_html__( 'اعتباری', 'bespari-core' ) . '</option>';
		echo '</select>';

		echo '<input type="date" name="date_from" value="' . esc_attr( $date_from ) . '" placeholder="' . esc_attr__( 'از تاریخ', 'bespari-core' ) . '" />';
		echo '<input type="date" name="date_to" value="' . esc_attr( $date_to ) . '" placeholder="' . esc_attr__( 'تا تاریخ', 'bespari-core' ) . '" />';

		echo '<button type="submit" class="button">' . esc_html__( 'فیلتر', 'bespari-core' ) . '</button>';
		$clear_url = add_query_arg( array( 'page' => 'bespari-orders' ), admin_url( 'admin.php' ) );
		echo ' <a href="' . esc_url( $clear_url ) . '" class="button">' . esc_html__( 'پاک کردن', 'bespari-core' ) . '</a>';
		echo '</div>';

		// ردیف دوم فیلترهای تکمیلی به صورت جمع‌شونده ساده.
		echo '<div class="bespari-filters__row bespari-filters__row--secondary">';
		echo '<select name="payment_status"><option value="">' . esc_html__( 'وضعیت پرداخت', 'bespari-core' ) . '</option>';
		foreach ( array( 'unpaid' => __( 'پرداخت‌نشده', 'bespari-core' ), 'partial' => __( 'جزئی', 'bespari-core' ), 'paid' => __( 'پرداخت‌شده', 'bespari-core' ) ) as $k => $label ) {
			echo '<option value="' . esc_attr( $k ) . '"' . selected( $filter_payment, $k, false ) . '>' . esc_html( $label ) . '</option>';
		}
		echo '</select>';
		echo '<select name="settlement_status"><option value="">' . esc_html__( 'وضعیت تسویه', 'bespari-core' ) . '</option>';
		foreach ( array( 'pending' => __( 'در انتظار تسویه', 'bespari-core' ), 'settled' => __( 'تسویه‌شده', 'bespari-core' ), 'paid' => __( 'پرداخت‌شده', 'bespari-core' ) ) as $k => $label ) {
			echo '<option value="' . esc_attr( $k ) . '"' . selected( $filter_settlement, $k, false ) . '>' . esc_html( $label ) . '</option>';
		}
		echo '</select>';
		echo '</div>';
		echo '</form>';
	}

	private function render_list(): void {
		$args = array(
			'page'              => isset( $_GET['paged'] ) ? (int) $_GET['paged'] : 1, // phpcs:ignore
			'search'            => isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '', // phpcs:ignore
			'channel_id'        => isset( $_GET['channel_id'] ) ? (int) $_GET['channel_id'] : 0, // phpcs:ignore
			'brand_id'          => isset( $_GET['brand_id'] ) ? (int) $_GET['brand_id'] : 0, // phpcs:ignore
			'status'            => isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : '', // phpcs:ignore
			'payment_status'    => isset( $_GET['payment_status'] ) ? sanitize_key( wp_unslash( $_GET['payment_status'] ) ) : '', // phpcs:ignore
			'settlement_status' => isset( $_GET['settlement_status'] ) ? sanitize_key( wp_unslash( $_GET['settlement_status'] ) ) : '', // phpcs:ignore
			'sale_type'         => isset( $_GET['sale_type'] ) ? sanitize_key( wp_unslash( $_GET['sale_type'] ) ) : '', // phpcs:ignore
			'date_from'         => isset( $_GET['date_from'] ) ? sanitize_text_field( wp_unslash( $_GET['date_from'] ) ) : '', // phpcs:ignore
			'date_to'           => isset( $_GET['date_to'] ) ? sanitize_text_field( wp_unslash( $_GET['date_to'] ) ) : '', // phpcs:ignore
			'per_page'          => 20,
		);
		$args = array_filter( $args, function( $v ) { return '' !== $v && null !== $v && 0 !== $v || is_int( $v ); } );
		// حفظ فیلترهای رشته‌ای خالی‌نشده.
		foreach ( array( 'search', 'status', 'payment_status', 'settlement_status', 'sale_type', 'date_from', 'date_to' ) as $k ) {
			if ( ! isset( $args[ $k ] ) && isset( $_GET[ $k ] ) && '' !== $_GET[ $k ] ) { // phpcs:ignore
				$args[ $k ] = is_string( $_GET[ $k ] ) ? sanitize_text_field( wp_unslash( $_GET[ $k ] ) ) : $_GET[ $k ]; // phpcs:ignore
			}
		}
		if ( isset( $_GET['channel_id'] ) && (int) $_GET['channel_id'] ) { // phpcs:ignore
			$args['channel_id'] = (int) $_GET['channel_id']; // phpcs:ignore
		}
		if ( isset( $_GET['brand_id'] ) && (int) $_GET['brand_id'] ) { // phpcs:ignore
			$args['brand_id'] = (int) $_GET['brand_id']; // phpcs:ignore
		}

		// حالت فاکتور به فاکتور: اکشن‌های کد رهگیری/رسید تسویه روی ردیف‌ها.
		$channel_id   = isset( $_GET['channel_id'] ) ? (int) $_GET['channel_id'] : 0; // phpcs:ignore
		$invoice_mode = false;
		if ( $channel_id > 0 ) {
			$ch = ( new ChannelService() )->get( $channel_id );
			$invoice_mode = $ch && 'invoice' === $ch->settlement_mode;
		}

		$service = new OrderService();
		$res     = $service->list( $args );
		$items   = $res['items'];
		$total   = $res['total'];
		$page    = max( 1, (int) ( $args['page'] ?? 1 ) );
		$pages   = max( 1, (int) ceil( $total / 20 ) );

		if ( empty( $items ) ) {
			echo '<div class="bespari-empty"><p>' . esc_html__( 'سفارشی یافت نشد.', 'bespari-core' ) . '</p></div>';
			return;
		}

		echo '<table class="bespari-table widefat striped">';
		echo '<thead><tr>';
		echo '<th>' . esc_html__( 'شماره سفارش', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'کانال / برند', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'مشتری', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'نوع فروش', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'وضعیت', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'پرداخت', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'تسویه', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'مبلغ ناخالص', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'سود', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'تاریخ', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'عملیات', 'bespari-core' ) . '</th>';
		echo '</tr></thead><tbody>';

		foreach ( $items as $o ) {
			$edit_url   = add_query_arg( array( 'page' => 'bespari-orders', 'id' => $o->id ), admin_url( 'admin.php' ) );
			$delete_url = $this->admin_action_url( 'delete_order', array( 'id' => $o->id ) );
			$status_badge = $this->status_badge( $o->status, $o->status_label() );

			echo '<tr>';
			echo '<td><a href="' . esc_url( $edit_url ) . '"><strong>' . esc_html( $o->order_number ) . '</strong></a></td>';
			echo '<td>' . esc_html( $o->channel_name ?: (string) $o->channel_id ) . ' <span class="bespari-muted">/ ' . esc_html( $o->brand_name ?: '-' ) . '</span></td>';
			echo '<td>' . esc_html( $o->customer_name ?: '-' ) . '<br><span class="bespari-muted">' . esc_html( $o->customer_phone ) . '</span></td>';
			echo '<td>' . esc_html( $o->sale_type_label() ) . '</td>';
			echo '<td>' . wp_kses_post( $status_badge ) . '</td>';
			echo '<td><span class="bespari-badge bespari-badge--muted">' . esc_html( $o->payment_status_label() ) . '</span></td>';
			echo '<td><span class="bespari-badge bespari-badge--muted">' . esc_html( $o->settlement_status_label() ) . '</span></td>';
			echo '<td>' . esc_html( Helpers::format_money( $o->total_gross ) ) . '</td>';
			echo '<td>' . esc_html( Helpers::format_money( $o->total_profit ) ) . '</td>';
			echo '<td><span class="bespari-muted">' . esc_html( $o->ordered_at ) . '</span></td>';
			echo '<td class="bespari-actions">';
			// حالت فاکتور به فاکتور: اکشن کد رهگیری (→ ارسال شده) و رسید تسویه (→ تسویه شده).
			if ( $invoice_mode && current_user_can( 'bespari_manage_orders' ) && in_array( $o->status, array( 'pending', 'confirmed' ), true ) ) {
				echo $this->render_order_tracking_action( (int) $o->id, $channel_id ) . ' ';
			}
			if ( $invoice_mode && current_user_can( 'bespari_manage_settlement' ) && 'settled' !== $o->settlement_status ) {
				echo $this->render_order_settle_action( (int) $o->id, $channel_id ) . ' ';
			}
			echo '<a href="' . esc_url( $edit_url ) . '" class="button button-small">' . esc_html__( 'ویرایش', 'bespari-core' ) . '</a> ';
			echo '<a href="' . esc_url( $delete_url ) . '" class="button button-small button-link-delete bespari-confirm-delete" data-message="' . esc_attr__( 'آیا از حذف این سفارش اطمینان دارید؟', 'bespari-core' ) . '">' . esc_html__( 'حذف', 'bespari-core' ) . '</a>';
			echo '</td>';
			echo '</tr>';
		}

		echo '</tbody></table>';

		// صفحه‌بندی.
		if ( $pages > 1 ) {
			echo '<div class="tablenav"><div class="tablenav-pages">';
			echo paginate_links( array(
				'base'      => add_query_arg( 'paged', '%#%' ),
				'format'    => '',
				'prev_text' => __( '&laquo; قبلی', 'bespari-core' ),
				'next_text' => __( 'بعدی &raquo;', 'bespari-core' ),
				'total'     => $pages,
				'current'   => $page,
			) );
			echo '</div></div>';
		}
		echo '<p class="description">' . sprintf( esc_html__( 'مجموع %d سفارش', 'bespari-core' ), (int) $total ) . '</p>';
	}

	/**
	 * @param \Bespari\Modules\Order\OrderModel|null $order
	 */
	private function render_form( $order ): void {
		$is_edit = null !== $order;
		$action  = admin_url( 'admin-post.php' );
		$editable = $is_edit ? $order->is_editable() : true;

		$val = function( string $key, $default = '' ) use ( $order ) {
			if ( ! $order ) {
				return $default;
			}
			return $order->$key ?? $default;
		};

		if ( $is_edit && ! $editable ) {
			echo '<div class="bespari-notice bespari-notice--warning"><span>' . esc_html__( 'این سفارش تسویه یا پرداخت شده و قابل ویرایش نیست. فقط مشاهده snapshot.', 'bespari-core' ) . '</span></div>';
		}

		echo '<form method="post" action="' . esc_url( $action ) . '" class="bespari-form" id="bespari-order-form">';
		wp_nonce_field( 'bespari_save_order', 'bespari_nonce' );
		echo '<input type="hidden" name="action" value="bespari_save_order" />';
		if ( $is_edit ) {
			echo '<input type="hidden" name="order_id" value="' . esc_attr( $order->id ) . '" />';
		}

		echo '<table class="form-table">';

		echo '<tr><th scope="row"><label>' . esc_html__( 'شماره سفارش', 'bespari-core' ) . '</label></th>';
		echo '<td><input type="text" name="order[order_number]" value="' . esc_attr( $val( 'order_number' ) ) . '" class="regular-text" placeholder="' . esc_attr__( 'خالی = خودکار ORD-...', 'bespari-core' ) . '"' . ( $editable ? '' : ' readonly' ) . ' /></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'کانال', 'bespari-core' ) . ' <span class="required">*</span></label></th><td><select name="order[channel_id]" id="bespari-order-channel"' . ( $editable ? '' : ' disabled' ) . ' required><option value="">' . esc_html__( '— انتخاب کنید —', 'bespari-core' ) . '</option>';
		foreach ( ( new ChannelService() )->list( true ) as $ch ) {
			echo '<option value="' . esc_attr( $ch->id ) . '"' . selected( (int) $val( 'channel_id', 0 ), $ch->id, false ) . '>' . esc_html( $ch->name ) . '</option>';
		}
		echo '</select></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'برند', 'bespari-core' ) . '</label></th><td><select name="order[brand_id]"' . ( $editable ? '' : ' disabled' ) . '><option value="0">' . esc_html__( '— بدون برند —', 'bespari-core' ) . '</option>';
		foreach ( ( new BrandService() )->list( true ) as $b ) {
			echo '<option value="' . esc_attr( $b->id ) . '"' . selected( (int) $val( 'brand_id', 0 ), $b->id, false ) . '>' . esc_html( $b->name ) . '</option>';
		}
		echo '</select></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'نوع فروش', 'bespari-core' ) . '</label></th><td><select name="order[sale_type]" id="bespari-order-sale-type"' . ( $editable ? '' : ' disabled' ) . '>';
		foreach ( array( 'cash' => __( 'نقدی', 'bespari-core' ), 'credit' => __( 'اعتباری', 'bespari-core' ) ) as $k => $t ) {
			echo '<option value="' . esc_attr( $k ) . '"' . selected( $val( 'sale_type', 'cash' ), $k, false ) . '>' . esc_html( $t ) . '</option>';
		}
		echo '</select></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'تاریخ سفارش', 'bespari-core' ) . '</label></th>';
		$ordered_val = $val( 'ordered_at' ) ? gmdate( 'Y-m-d\TH:i', strtotime( $val( 'ordered_at' ) ) ) : '';
		echo '<td><input type="datetime-local" name="order[ordered_at]" value="' . esc_attr( $ordered_val ) . '"' . ( $editable ? '' : ' readonly' ) . ' /></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'وضعیت', 'bespari-core' ) . '</label></th><td><select name="order[status]">';
		foreach ( array( 'pending' => __( 'در انتظار', 'bespari-core' ), 'confirmed' => __( 'تاییدشده', 'bespari-core' ), 'shipped' => __( 'ارسال‌شده', 'bespari-core' ), 'delivered' => __( 'تحویل‌شده', 'bespari-core' ), 'cancelled' => __( 'لغوشده', 'bespari-core' ), 'paid' => __( 'پرداخت‌شده', 'bespari-core' ) ) as $k => $t ) {
			echo '<option value="' . esc_attr( $k ) . '"' . selected( $val( 'status', 'pending' ), $k, false ) . '>' . esc_html( $t ) . '</option>';
		}
		echo '</select></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'وضعیت پرداخت', 'bespari-core' ) . '</label></th><td><select name="order[payment_status]">';
		foreach ( array( 'unpaid' => __( 'پرداخت‌نشده', 'bespari-core' ), 'partial' => __( 'جزئی', 'bespari-core' ), 'paid' => __( 'پرداخت‌شده', 'bespari-core' ) ) as $k => $t ) {
			echo '<option value="' . esc_attr( $k ) . '"' . selected( $val( 'payment_status', 'unpaid' ), $k, false ) . '>' . esc_html( $t ) . '</option>';
		}
		echo '</select></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'نام مشتری', 'bespari-core' ) . '</label></th>';
		echo '<td><input type="text" name="order[customer_name]" value="' . esc_attr( $val( 'customer_name' ) ) . '" class="regular-text"' . ( $editable ? '' : ' readonly' ) . ' /></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'تلفن مشتری', 'bespari-core' ) . '</label></th>';
		echo '<td><input type="text" name="order[customer_phone]" value="' . esc_attr( $val( 'customer_phone' ) ) . '" class="regular-text" dir="ltr"' . ( $editable ? '' : ' readonly' ) . ' /></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'آدرس', 'bespari-core' ) . '</label></th>';
		echo '<td><textarea name="order[customer_address]" rows="2" class="large-text"' . ( $editable ? '' : ' readonly' ) . '>' . esc_textarea( $val( 'customer_address' ) ) . '</textarea></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'یادداشت', 'bespari-core' ) . '</label></th>';
		echo '<td><textarea name="order[notes]" rows="2" class="large-text">' . esc_textarea( $val( 'notes' ) ) . '</textarea></td></tr>';

		echo '</table>';

		// جدول آیتم‌ها.
		$this->render_items_table( $order, $editable );

		// نمایش snapshot در حالت مشاهده.
		if ( $is_edit && $order->financials_snapshot ) {
			echo '<div class="bespari-box bespari-box--white" style="margin-top:16px;">';
			echo '<h3 class="bespari-box__title">' . esc_html__( 'خلاصه مالی (snapshot)', 'bespari-core' ) . '</h3>';
			$fs = $order->financials_snapshot;
			echo '<table class="bespari-table widefat"><tbody>';
			echo '<tr><th>' . esc_html__( 'ناخالص', 'bespari-core' ) . '</th><td>' . esc_html( Helpers::format_money( $fs['gross'] ?? $order->total_gross ) ) . '</td></tr>';
			echo '<tr><th>' . esc_html__( 'کسورات', 'bespari-core' ) . '</th><td>' . esc_html( Helpers::format_money( $fs['deductions'] ?? 0 ) ) . '</td></tr>';
			echo '<tr><th>' . esc_html__( 'خالص دریافتی', 'bespari-core' ) . '</th><td>' . esc_html( Helpers::format_money( $fs['net'] ?? $order->total_net ) ) . '</td></tr>';
			echo '<tr><th>' . esc_html__( 'سود', 'bespari-core' ) . '</th><td>' . esc_html( Helpers::format_money( $fs['profit'] ?? $order->total_profit ) ) . '</td></tr>';
			echo '<tr><th>' . esc_html__( 'نسخه قوانین', 'bespari-core' ) . '</th><td>v' . esc_html( $order->rule_version ) . '</td></tr>';
			echo '</tbody></table></div>';
		}

		if ( $editable ) {
			submit_button( $is_edit ? __( 'به‌روزرسانی سفارش', 'bespari-core' ) : __( 'ایجاد سفارش', 'bespari-core' ), 'primary', 'submit' );
		}
		echo '</form>';
	}

	private function render_items_table( $order, bool $editable ): void {
		$products_res = ( new ProductService() )->list( array( 'per_page' => 500 ) );
		$products     = $products_res['items'];
		$existing_items = $order ? (array) $order->items : array();

		echo '<div class="bespari-box bespari-box--white" style="margin-top:16px;">';
		echo '<h3 class="bespari-box__title">' . esc_html__( 'اقلام سفارش', 'bespari-core' ) . '</h3>';
		echo '<table class="bespari-table widefat" id="bespari-order-items-table">';
		echo '<thead><tr><th>' . esc_html__( 'محصول', 'bespari-core' ) . '</th><th>' . esc_html__( 'تعداد', 'bespari-core' ) . '</th>';
		if ( $editable ) {
			echo '<th>' . esc_html__( 'حذف', 'bespari-core' ) . '</th>';
		}
		echo '</tr></thead><tbody id="bespari-order-items-body">';

		if ( ! empty( $existing_items ) ) {
			foreach ( $existing_items as $idx => $it ) {
				$pid = is_array( $it ) ? (int) ( $it['product_id'] ?? 0 ) : (int) ( $it->product_id ?? 0 );
				$qty = is_array( $it ) ? (int) ( $it['quantity'] ?? 1 ) : (int) ( $it->quantity ?? 1 );
				echo '<tr class="bespari-order-item-row">';
				echo '<td><select name="items[' . esc_attr( $idx ) . '][product_id]"' . ( $editable ? '' : ' disabled' ) . '><option value="">' . esc_html__( '— انتخاب —', 'bespari-core' ) . '</option>';
				foreach ( $products as $p ) {
					echo '<option value="' . esc_attr( $p->id ) . '"' . selected( $pid, $p->id, false ) . '>' . esc_html( $p->name ) . ' (' . esc_html( $p->sku ) . ')</option>';
				}
				echo '</select></td>';
				echo '<td><input type="number" name="items[' . esc_attr( $idx ) . '][quantity]" value="' . esc_attr( $qty ) . '" min="1" class="small-text"' . ( $editable ? '' : ' readonly' ) . ' /></td>';
				if ( $editable ) {
					echo '<td><button type="button" class="button bespari-remove-item">' . esc_html__( 'حذف', 'bespari-core' ) . '</button></td>';
				}
				echo '</tr>';
			}
		} elseif ( $editable ) {
			echo '<tr class="bespari-order-item-row">';
			echo '<td><select name="items[0][product_id]"><option value="">' . esc_html__( '— انتخاب —', 'bespari-core' ) . '</option>';
			foreach ( $products as $p ) {
				echo '<option value="' . esc_attr( $p->id ) . '">' . esc_html( $p->name ) . ' (' . esc_html( $p->sku ) . ')</option>';
			}
			echo '</select></td>';
			echo '<td><input type="number" name="items[0][quantity]" value="1" min="1" class="small-text" /></td>';
			echo '<td><button type="button" class="button bespari-remove-item">' . esc_html__( 'حذف', 'bespari-core' ) . '</button></td>';
			echo '</tr>';
		}

		echo '</tbody></table>';
		if ( $editable ) {
			echo '<p><button type="button" class="button" id="bespari-add-item">' . esc_html__( 'افزودن ردیف', 'bespari-core' ) . '</button> ';
			echo '<button type="button" class="button button-secondary" id="bespari-preview-order">' . esc_html__( 'پیش‌نمایش محاسبه', 'bespari-core' ) . '</button></p>';
			echo '<div id="bespari-order-preview-result" class="bespari-preview-result" aria-live="polite"></div>';
			// قالب ردیف جدید برای JS.
			echo '<template id="bespari-item-row-template"><tr class="bespari-order-item-row">';
			echo '<td><select name="items[__IDX__][product_id]"><option value="">' . esc_html__( '— انتخاب —', 'bespari-core' ) . '</option>';
			foreach ( $products as $p ) {
				echo '<option value="' . esc_attr( $p->id ) . '">' . esc_html( $p->name ) . ' (' . esc_html( $p->sku ) . ')</option>';
			}
			echo '</select></td>';
			echo '<td><input type="number" name="items[__IDX__][quantity]" value="1" min="1" class="small-text" /></td>';
			echo '<td><button type="button" class="button bespari-remove-item">' . esc_html__( 'حذف', 'bespari-core' ) . '</button></td>';
			echo '</tr></template>';
		}
		echo '</div>';
	}

	private function status_badge( string $status, string $label ): string {
		$map = array(
			'pending'   => 'bespari-badge--warning',
			'confirmed' => 'bespari-badge--info',
			'shipped'   => 'bespari-badge--info',
			'delivered' => 'bespari-badge--success',
			'paid'      => 'bespari-badge--success',
			'cancelled' => 'bespari-badge--danger',
		);
		$cls = $map[ $status ] ?? 'bespari-badge--muted';
		return '<span class="bespari-badge ' . esc_attr( $cls ) . '">' . esc_html( $label ) . '</span>';
	}
}
