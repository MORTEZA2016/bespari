<?php
/**
 * داشبورد بازاریاب.
 *
 * @package Bespari\Admin\Pages
 */

namespace Bespari\Admin\Pages;

use Bespari\Modules\Commission\CommissionRepository;
use Bespari\Modules\Payout\PayoutRepository;
use Bespari\Support\Helpers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SellerDashboardPage extends BasePage {

	protected string $slug = 'bespari-seller-dashboard';
	protected string $cap  = 'bespari_seller_view';

	public function render(): void {
		if ( ! $this->can_access() ) {
			wp_die( esc_html__( 'شما دسترسی لازم را ندارید.', 'bespari-core' ) );
		}

		$seller_id = get_current_user_id();
		$comm_repo = new CommissionRepository();
		$bal       = $comm_repo->get_seller_balance( $seller_id );

		echo '<div class="wrap bespari-wrap">';
		$this->page_header( __( 'داشبورد بازاریاب', 'bespari-core' ), __( 'موجودی، پورسانت‌ها و درخواست برداشت.', 'bespari-core' ) );
		$this->render_notice();

		// کارت‌های موجودی.
		echo '<div class="bespari-stats-grid" style="grid-template-columns: repeat(4, 1fr);">';
		foreach ( array(
			array( 'label' => __( 'در انتظار', 'bespari-core' ), 'value' => Helpers::format_money( $bal['pending'] ), 'cls' => 'bespari-avatar--warning' ),
			array( 'label' => __( 'تاییدشده (قابل برداشت)', 'bespari-core' ), 'value' => Helpers::format_money( $bal['approved'] ), 'cls' => 'bespari-avatar--info' ),
			array( 'label' => __( 'پرداخت‌شده', 'bespari-core' ), 'value' => Helpers::format_money( $bal['paid'] ), 'cls' => 'bespari-avatar--success' ),
			array( 'label' => __( 'کل', 'bespari-core' ), 'value' => Helpers::format_money( $bal['total'] ), 'cls' => 'bespari-avatar--primary' ),
		) as $card ) {
			echo '<div class="bespari-card"><div class="bespari-avatar ' . esc_attr( $card['cls'] ) . '"><span class="dashicons dashicons-money-alt"></span></div>';
			echo '<div class="bespari-card__body"><span class="bespari-card__value">' . esc_html( $card['value'] ) . '</span>';
			echo '<span class="bespari-card__label">' . esc_html( $card['label'] ) . '</span></div></div>';
		}
		echo '</div>';

		// فرم درخواست برداشت.
		echo '<div class="bespari-box bespari-box--white" style="margin-top:16px;">';
		echo '<h3 class="bespari-box__title">' . esc_html__( 'درخواست برداشت', 'bespari-core' ) . '</h3>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="bespari-form bespari-form--inline">';
		wp_nonce_field( 'bespari_save_payout', 'bespari_nonce' );
		echo '<input type="hidden" name="action" value="bespari_save_payout" />';
		echo '<input type="hidden" name="payout[seller_id]" value="' . esc_attr( $seller_id ) . '" />';
		echo '<input type="number" name="payout[amount]" min="0" step="0.01" max="' . esc_attr( $bal['approved'] ) . '" placeholder="' . esc_attr__( 'مبلغ', 'bespari-core' ) . '" class="regular-text" required /> ';
		echo '<select name="payout[method]"><option value="manual">' . esc_html__( 'دستی', 'bespari-core' ) . '</option><option value="bank">' . esc_html__( 'بانکی', 'bespari-core' ) . '</option></select> ';
		echo '<input type="text" name="payout[notes]" placeholder="' . esc_attr__( 'یادداشت (اختیاری)', 'bespari-core' ) . '" class="regular-text" /> ';
		submit_button( __( 'ثبت درخواست', 'bespari-core' ), 'primary', 'submit', false );
		echo '<p class="description" style="margin-top:8px;">' . sprintf( esc_html__( 'سقف قابل برداشت: %s', 'bespari-core' ), esc_html( Helpers::format_money( $bal['approved'] ) ) ) . '</p>';
		echo '</form></div>';

		// لیست پورسانت‌های خودم.
		$comm_res = $comm_repo->paginate( array( 'seller_id' => $seller_id ), 1, 10 );
		echo '<div class="bespari-box bespari-box--white" style="margin-top:16px;">';
		echo '<h3 class="bespari-box__title">' . esc_html__( 'آخرین پورسانت‌ها', 'bespari-core' ) . '</h3>';
		if ( empty( $comm_res['items'] ) ) {
			echo '<p class="description">' . esc_html__( 'پورسانتی ثبت نشده است.', 'bespari-core' ) . '</p>';
		} else {
			echo '<table class="bespari-table widefat striped"><thead><tr><th>#</th><th>' . esc_html__( 'سفارش', 'bespari-core' ) . '</th><th>' . esc_html__( 'مبلغ', 'bespari-core' ) . '</th><th>' . esc_html__( 'وضعیت', 'bespari-core' ) . '</th></tr></thead><tbody>';
			foreach ( $comm_res['items'] as $c ) {
				echo '<tr><td>' . esc_html( $c->id ) . '</td><td>' . esc_html( $c->order_number ?: (string) $c->order_id ) . '</td><td>' . esc_html( Helpers::format_money( $c->amount ) ) . '</td><td>' . esc_html( $c->status_label() ) . '</td></tr>';
			}
			echo '</tbody></table>';
		}
		echo '</div>';

		// لیست پرداخت‌های خودم.
		$payout_repo = new PayoutRepository();
		$pay_res     = $payout_repo->paginate( array( 'seller_id' => $seller_id ), 1, 10 );
		echo '<div class="bespari-box bespari-box--white" style="margin-top:16px;">';
		echo '<h3 class="bespari-box__title">' . esc_html__( 'آخرین پرداخت‌ها', 'bespari-core' ) . '</h3>';
		if ( empty( $pay_res['items'] ) ) {
			echo '<p class="description">' . esc_html__( 'درخواستی ثبت نشده است.', 'bespari-core' ) . '</p>';
		} else {
			echo '<table class="bespari-table widefat striped"><thead><tr><th>#</th><th>' . esc_html__( 'مبلغ', 'bespari-core' ) . '</th><th>' . esc_html__( 'وضعیت', 'bespari-core' ) . '</th><th>' . esc_html__( 'تاریخ', 'bespari-core' ) . '</th></tr></thead><tbody>';
			foreach ( $pay_res['items'] as $p ) {
				echo '<tr><td>' . esc_html( $p->id ) . '</td><td>' . esc_html( Helpers::format_money( $p->amount ) ) . '</td><td>' . esc_html( $p->status_label() ) . '</td><td><span class="bespari-muted">' . esc_html( $p->requested_at ) . '</span></td></tr>';
			}
			echo '</tbody></table>';
		}
		echo '</div>';

		// فرم ثبت درخواست (فاز ۴).
		echo '<div class="bespari-box bespari-box--white" style="margin-top:16px;">';
		echo '<h3 class="bespari-box__title">' . esc_html__( 'ثبت درخواست', 'bespari-core' ) . '</h3>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="bespari-form">';
		wp_nonce_field( 'bespari_save_request', 'bespari_nonce' );
		echo '<input type="hidden" name="action" value="bespari_save_request" />';
		echo '<table class="form-table">';
		echo '<tr><th scope="row"><label>' . esc_html__( 'نوع', 'bespari-core' ) . '</label></th><td><select name="request[type]">';
		foreach ( array( 'stock' => __( 'موجودی', 'bespari-core' ), 'price' => __( 'قیمت', 'bespari-core' ), 'discount' => __( 'تخفیف', 'bespari-core' ), 'other' => __( 'سایر', 'bespari-core' ) ) as $k => $label ) {
			echo '<option value="' . esc_attr( $k ) . '">' . esc_html( $label ) . '</option>';
		}
		echo '</select></td></tr>';
		echo '<tr><th scope="row"><label>' . esc_html__( 'عنوان', 'bespari-core' ) . ' <span class="required">*</span></label></th>';
		echo '<td><input type="text" name="request[title]" class="regular-text" required /></td></tr>';
		echo '<tr><th scope="row"><label>' . esc_html__( 'توضیح', 'bespari-core' ) . '</label></th>';
		echo '<td><textarea name="request[description]" rows="3" class="large-text"></textarea></td></tr>';
		echo '</table>';
		submit_button( __( 'ثبت درخواست', 'bespari-core' ), 'primary', 'submit', false );
		echo '</form></div>';

		// لیست درخواست‌های خودم (فاز ۴).
		$req_service = new \Bespari\Modules\Request\RequestService();
		$req_res     = $req_service->list( array( 'page' => 1, 'per_page' => 10 ) );
		echo '<div class="bespari-box bespari-box--white" style="margin-top:16px;">';
		echo '<h3 class="bespari-box__title">' . esc_html__( 'آخرین درخواست‌های من', 'bespari-core' ) . '</h3>';
		if ( empty( $req_res['items'] ) ) {
			echo '<p class="description">' . esc_html__( 'درخواستی ثبت نشده است.', 'bespari-core' ) . '</p>';
		} else {
			echo '<table class="bespari-table widefat striped"><thead><tr><th>#</th><th>' . esc_html__( 'عنوان', 'bespari-core' ) . '</th><th>' . esc_html__( 'نوع', 'bespari-core' ) . '</th><th>' . esc_html__( 'وضعیت', 'bespari-core' ) . '</th><th>' . esc_html__( 'پاسخ', 'bespari-core' ) . '</th></tr></thead><tbody>';
			foreach ( $req_res['items'] as $r ) {
				$badge = 'approved' === $r->status ? 'bespari-badge--success' : ( 'rejected' === $r->status ? 'bespari-badge--danger' : 'bespari-badge--warning' );
				echo '<tr><td>' . esc_html( $r->id ) . '</td><td>' . esc_html( $r->title ) . '</td><td>' . esc_html( $r->type_label() ) . '</td>';
				echo '<td><span class="bespari-badge ' . esc_attr( $badge ) . '">' . esc_html( $r->status_label() ) . '</span></td>';
				echo '<td><span class="bespari-muted">' . esc_html( $r->resolution_notes ? mb_strimwidth( $r->resolution_notes, 0, 60, '…' ) : '—' ) . '</span></td></tr>';
			}
			echo '</tbody></table>';
		}
		echo '</div>';

		// کیف پول (فاز ۵): مانده + تراکنش‌های خودم.
		$accounting = new \Bespari\Modules\Accounting\AccountingService();
		$wallet     = $accounting->get_balance( $seller_id );
		$txn_res    = $accounting->list_transactions( array( 'seller_id' => $seller_id, 'page' => 1, 'per_page' => 10 ) );

		echo '<div class="bespari-box bespari-box--white" style="margin-top:16px;">';
		echo '<h3 class="bespari-box__title">' . esc_html__( 'کیف پول', 'bespari-core' ) . '</h3>';
		echo '<p style="font-size:20px;font-weight:700;margin:0 0 12px;">' . esc_html( Helpers::format_money( $wallet ) ) . '</p>';
		if ( empty( $txn_res['items'] ) ) {
			echo '<p class="description">' . esc_html__( 'تراکنشی ثبت نشده است.', 'bespari-core' ) . '</p>';
		} else {
			echo '<table class="bespari-table widefat striped"><thead><tr><th>#</th><th>' . esc_html__( 'نوع', 'bespari-core' ) . '</th><th>' . esc_html__( 'مبلغ', 'bespari-core' ) . '</th><th>' . esc_html__( 'توضیح', 'bespari-core' ) . '</th><th>' . esc_html__( 'تاریخ', 'bespari-core' ) . '</th></tr></thead><tbody>';
			foreach ( $txn_res['items'] as $t ) {
				$color = $t->amount >= 0 ? 'var(--bespari-success)' : 'var(--bespari-danger)';
				echo '<tr><td>' . esc_html( $t->id ) . '</td><td>' . esc_html( $t->type_label() ) . '</td>';
				echo '<td style="color:' . esc_attr( $color ) . ';font-weight:700;">' . esc_html( ( $t->amount >= 0 ? '+' : '' ) . Helpers::format_money( $t->amount ) ) . '</td>';
				echo '<td><span class="bespari-muted">' . esc_html( $t->description ?: '—' ) . '</span></td>';
				echo '<td><span class="bespari-muted">' . esc_html( $t->created_at ) . '</span></td></tr>';
			}
			echo '</tbody></table>';
		}
		echo '</div>';

		echo '</div>';
	}
}
