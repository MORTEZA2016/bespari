<?php
/**
 * صفحه اتصال‌های اقماری (Agent Connector).
 *
 * @package Bespari\Admin\Pages
 */

namespace Bespari\Admin\Pages;

use Bespari\Modules\Agent\AgentService;
use Bespari\Support\Helpers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AgentsPage extends BasePage {

	protected string $slug = 'bespari-agents';
	protected string $cap  = 'bespari_manage_settings';

	public function render(): void {
		if ( ! $this->can_access() ) {
			wp_die( esc_html__( 'شما دسترسی لازم را ندارید.', 'bespari-core' ) );
		}

		$view = isset( $_GET['view'] ) ? (int) $_GET['view'] : 0; // phpcs:ignore

		echo '<div class="wrap bespari-wrap">';

		if ( $view > 0 ) {
			$this->render_detail( $view );
			echo '</div>';
			return;
		}

		$tab = $this->current_tab( 'list' );

		$this->page_header( __( 'اتصال‌های اقماری', 'bespari-core' ), __( 'اتصال سایت‌های بازاریاب به این سایت مادر — REST + HMAC با کلید و secret اختصاصی.', 'bespari-core' ) );
		$this->render_notice();
		$this->render_tabs( $tab, array(
			'list' => __( 'اتصال‌ها', 'bespari-core' ),
			'add'  => __( 'اتصال جدید', 'bespari-core' ),
		) );

		if ( 'add' === $tab ) {
			$this->render_form( 0 );
		} else {
			$this->render_list();
		}

		echo '</div>';
	}

	private function render_list(): void {
		$service = new AgentService();
		$agents  = $service->list();

		if ( empty( $agents ) ) {
			echo '<div class="bespari-empty"><p>' . esc_html__( 'اتصالی ثبت نشده است. با «اتصال جدید» اولین سایت اقماری را بسازید.', 'bespari-core' ) . '</p></div>';
			return;
		}

		$badge_map = array( 'active' => 'bespari-badge--success', 'inactive' => 'bespari-badge--muted', 'blocked' => 'bespari-badge--danger' );

		echo '<table class="bespari-table widefat striped"><thead><tr>';
		echo '<th>#</th>';
		echo '<th>' . esc_html__( 'نام', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'سایت', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'کانال', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'بازاریاب', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'وضعیت', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'آخرین سینک', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'عملیات', 'bespari-core' ) . '</th>';
		echo '</tr></thead><tbody>';

		foreach ( $agents as $m ) {
			$cls    = $badge_map[ $m->status ] ?? 'bespari-badge--muted';
			$detail = add_query_arg( array( 'page' => 'bespari-agents', 'view' => $m->id ), admin_url( 'admin.php' ) );
			echo '<tr>';
			echo '<td>' . esc_html( $m->id ) . '</td>';
			echo '<td><strong>' . esc_html( $m->name ) . '</strong></td>';
			echo '<td>' . esc_html( $m->site_url ) . '</td>';
			echo '<td>' . esc_html( $m->channel_name ?: '—' ) . '</td>';
			echo '<td>' . esc_html( $m->seller_name ?: '—' ) . '</td>';
			echo '<td><span class="bespari-badge ' . esc_attr( $cls ) . '">' . esc_html( $m->status_label() ) . '</span></td>';
			echo '<td><span class="bespari-muted">' . esc_html( $m->last_sync_at ?: '—' ) . '</span></td>';
			echo '<td class="bespari-actions">';
			echo '<a href="' . esc_url( $detail ) . '" class="button button-small">' . esc_html__( 'جزئیات', 'bespari-core' ) . '</a> ';
			echo '<a href="' . esc_url( $this->admin_action_url( 'delete_agent', array( 'id' => $m->id ) ) ) . '" class="button button-small bespari-confirm-delete" data-confirm="' . esc_attr__( 'آیا از حذف این اتصال مطمئن هستید؟', 'bespari-core' ) . '">' . esc_html__( 'حذف', 'bespari-core' ) . '</a>';
			echo '</td></tr>';
		}
		echo '</tbody></table>';
	}

	private function render_form( int $id ): void {
		$service = new AgentService();
		$agent   = $id > 0 ? $service->get( $id ) : null;

		global $wpdb;
		$channels = Helpers::table( 'channels' );
		$channels = $wpdb->get_results( "SELECT id, name FROM {$channels} WHERE status = 1 ORDER BY name" ); // phpcs:ignore

		$sellers = get_users( array( 'role' => 'bespari_seller', 'fields' => array( 'ID', 'display_name' ) ) );

		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="bespari-form">';
		wp_nonce_field( 'bespari_save_agent', 'bespari_nonce' );
		echo '<input type="hidden" name="action" value="bespari_save_agent" />';
		if ( $agent ) {
			echo '<input type="hidden" name="agent[id]" value="' . esc_attr( $agent->id ) . '" />';
		}
		echo '<table class="form-table">';

		echo '<tr><th scope="row"><label>' . esc_html__( 'نام', 'bespari-core' ) . ' <span class="required">*</span></label></th>';
		echo '<td><input type="text" name="agent[name]" class="regular-text" value="' . esc_attr( $agent->name ?? '' ) . '" required /></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'آدرس سایت', 'bespari-core' ) . ' <span class="required">*</span></label></th>';
		echo '<td><input type="url" name="agent[site_url]" class="regular-text" dir="ltr" value="' . esc_attr( $agent->site_url ?? '' ) . '" placeholder="https://agent.example.com" required /></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'کانال اختصاصی', 'bespari-core' ) . ' <span class="required">*</span></label></th><td>';
		echo '<select name="agent[channel_id]" required><option value="">' . esc_html__( '— انتخاب کانال —', 'bespari-core' ) . '</option>';
		foreach ( (array) $channels as $c ) {
			echo '<option value="' . esc_attr( $c->id ) . '"' . selected( (int) ( $agent->channel_id ?? 0 ), (int) $c->id, false ) . '>' . esc_html( $c->name ) . '</option>';
		}
		echo '</select></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'بازاریاب مرتبط', 'bespari-core' ) . '</label></th><td>';
		echo '<select name="agent[seller_id]"><option value="0">' . esc_html__( '— بدون بازاریاب —', 'bespari-core' ) . '</option>';
		foreach ( (array) $sellers as $s ) {
			echo '<option value="' . esc_attr( $s->ID ) . '"' . selected( (int) ( $agent->seller_id ?? 0 ), (int) $s->ID, false ) . '>' . esc_html( $s->display_name ) . '</option>';
		}
		echo '</select></td></tr>';

		if ( $agent ) {
			echo '<tr><th scope="row"><label>' . esc_html__( 'وضعیت', 'bespari-core' ) . '</label></th><td>';
			echo '<select name="agent[status]">';
			foreach ( array( 'active' => __( 'فعال', 'bespari-core' ), 'inactive' => __( 'غیرفعال', 'bespari-core' ), 'blocked' => __( 'مسدود', 'bespari-core' ) ) as $k => $label ) {
				echo '<option value="' . esc_attr( $k ) . '"' . selected( $agent->status, $k, false ) . '>' . esc_html( $label ) . '</option>';
			}
			echo '</select></td></tr>';
		}

		echo '</table>';
		submit_button( $agent ? __( 'ذخیره تغییرات', 'bespari-core' ) : __( 'ایجاد اتصال + تولید کلید', 'bespari-core' ), 'primary', 'submit' );
		echo '</form>';
	}

	/**
	 * صفحه جزئیات: کلید + secret یک‌بارمصرف + لاگ + نمونه curl.
	 */
	private function render_detail( int $id ): void {
		$service  = new AgentService();
		$agent    = $service->get( $id );
		$new_secret = isset( $_GET['new_secret'] ) ? sanitize_text_field( wp_unslash( $_GET['new_secret'] ) ) : ''; // phpcs:ignore

		if ( ! $agent ) {
			echo '<div class="bespari-empty"><p>' . esc_html__( 'اتصال یافت نشد.', 'bespari-core' ) . '</p></div>';
			return;
		}

		$back = add_query_arg( array( 'page' => 'bespari-agents' ), admin_url( 'admin.php' ) );
		echo '<a href="' . esc_url( $back ) . '" class="bespari-shortcut-link" style="display:inline-flex;margin-bottom:12px;"><span class="dashicons dashicons-arrow-right-alt"></span> ' . esc_html__( 'بازگشت به لیست', 'bespari-core' ) . '</a>';

		$this->page_header( $agent->name, $agent->site_url );
		$this->render_notice();

		// secret یک‌بارمصرف (پس از create یا rotate).
		if ( '' !== $new_secret ) {
			echo '<div class="bespari-notice bespari-notice--info"><strong>' . esc_html__( 'Secret جدید (فقط همین یک بار نمایش داده می‌شود):', 'bespari-core' ) . '</strong> <code dir="ltr" style="user-select:all;">' . esc_html( $new_secret ) . '</code></div>';
		}

		echo '<div class="bespari-box">';
		echo '<h3 class="bespari-box__title">' . esc_html__( 'اعتبارنامه اتصال', 'bespari-core' ) . '</h3>';
		echo '<table class="form-table">';
		echo '<tr><th>' . esc_html__( 'API Key', 'bespari-core' ) . '</th><td><code dir="ltr" style="user-select:all;">' . esc_html( $agent->api_key ) . '</code></td></tr>';
		echo '<tr><th>' . esc_html__( 'API Secret', 'bespari-core' ) . '</th><td><code dir="ltr">' . esc_html( '••••••••••••••••' ) . '</code> ';
		echo '<a href="' . esc_url( $this->admin_action_url( 'rotate_agent_secret', array( 'id' => $agent->id ) ) ) . '" class="button button-small">' . esc_html__( 'چرخش secret', 'bespari-core' ) . '</a></td></tr>';
		echo '<tr><th>' . esc_html__( 'آخرین سینک', 'bespari-core' ) . '</th><td>' . esc_html( $agent->last_sync_at ?: '—' ) . '</td></tr>';
		echo '</table>';
		echo '</div>';

		// فرم ویرایش.
		echo '<div class="bespari-box" style="margin-top:16px;">';
		echo '<h3 class="bespari-box__title">' . esc_html__( 'ویرایش اتصال', 'bespari-core' ) . '</h3>';
		$this->render_form( $agent->id );
		echo '</div>';

		// نمونه curl تست handshake.
		$curl_body = '{}';
		$curl_hint = sprintf(
			"curl -X POST %s -H 'X-Bespari-Key: %s' -H 'X-Bespari-Timestamp: <unix>' -H 'X-Bespari-Signature: <hmac-sha256 of timestamp.body with secret>' -d '%s'",
			esc_attr( untrailingslashit( home_url() ) . '/wp-json/bespari/v1/agent/handshake' ),
			esc_attr( $agent->api_key ),
			$curl_body
		);
		echo '<div class="bespari-box" style="margin-top:16px;">';
		echo '<h3 class="bespari-box__title">' . esc_html__( 'تست اتصال (نمونه curl)', 'bespari-core' ) . '</h3>';
		echo '<textarea readonly rows="4" class="large-text code" dir="ltr">' . esc_textarea( $curl_hint ) . '</textarea>';
		echo '</div>';

		// لاگ آخرین فعالیت‌ها.
		$logs = $service->get_logs( $agent->id, 20 );
		echo '<div class="bespari-box" style="margin-top:16px;">';
		echo '<h3 class="bespari-box__title">' . esc_html__( 'آخرین فعالیت‌ها', 'bespari-core' ) . '</h3>';
		if ( empty( $logs ) ) {
			echo '<p class="description">' . esc_html__( 'فعالیتی ثبت نشده است.', 'bespari-core' ) . '</p>';
		} else {
			echo '<table class="bespari-table widefat striped"><thead><tr>';
			echo '<th>#</th><th>' . esc_html__( 'Endpoint', 'bespari-core' ) . '</th><th>' . esc_html__( 'جهت', 'bespari-core' ) . '</th><th>' . esc_html__( 'وضعیت', 'bespari-core' ) . '</th><th>' . esc_html__( 'پیام', 'bespari-core' ) . '</th><th>' . esc_html__( 'تاریخ', 'bespari-core' ) . '</th>';
			echo '</tr></thead><tbody>';
			foreach ( $logs as $log ) {
				$cls = 'ok' === $log->status ? 'bespari-badge--success' : 'bespari-badge--danger';
				echo '<tr><td>' . esc_html( $log->id ) . '</td><td>' . esc_html( $log->endpoint ) . '</td><td>' . esc_html( $log->direction ) . '</td>';
				echo '<td><span class="bespari-badge ' . esc_attr( $cls ) . '">' . esc_html( $log->status ) . '</span></td>';
				echo '<td><span class="bespari-muted">' . esc_html( mb_strimwidth( (string) $log->message, 0, 60, '…' ) ?: '—' ) . '</span></td>';
				echo '<td><span class="bespari-muted">' . esc_html( $log->created_at ) . '</span></td></tr>';
			}
			echo '</tbody></table>';
		}
		echo '</div>';
	}
}
