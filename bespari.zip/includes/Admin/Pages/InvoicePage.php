<?php
/**
 * صفحه صورتحساب‌ها — لیست، صدور و برگه چاپی A4.
 *
 * @package Bespari\Admin\Pages
 */

namespace Bespari\Admin\Pages;

use Bespari\Modules\Accounting\AccountingService;
use Bespari\Support\Helpers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class InvoicePage extends BasePage {

	protected string $slug = 'bespari-invoices';
	protected string $cap  = 'bespari_manage_finance';

	public function render(): void {
		if ( ! $this->can_access() ) {
			wp_die( esc_html__( 'شما دسترسی لازم را ندارید.', 'bespari-core' ) );
		}

		$view = isset( $_GET['view'] ) ? (int) $_GET['view'] : 0; // phpcs:ignore

		echo '<div class="wrap bespari-wrap">';

		if ( $view > 0 ) {
			$this->render_print_view( $view );
			echo '</div>';
			return;
		}

		$tab = $this->current_tab( 'list' );

		$this->page_header( __( 'صورتحساب‌ها', 'bespari-core' ), __( 'صدور صورتحساب از سفارش (فریز از snapshot) و برگه چاپی A4.', 'bespari-core' ) );
		$this->render_notice();
		$this->render_tabs( $tab, array(
			'list' => __( 'لیست صورتحساب‌ها', 'bespari-core' ),
			'add'  => __( 'صدور صورتحساب', 'bespari-core' ),
		) );

		if ( 'add' === $tab ) {
			$this->render_add_form();
		} else {
			$this->render_filters();
			$this->render_list();
		}

		echo '</div>';
	}

	private function render_filters(): void {
		$search = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : ''; // phpcs:ignore
		$from   = isset( $_GET['date_from'] ) ? sanitize_text_field( wp_unslash( $_GET['date_from'] ) ) : ''; // phpcs:ignore
		$to     = isset( $_GET['date_to'] ) ? sanitize_text_field( wp_unslash( $_GET['date_to'] ) ) : ''; // phpcs:ignore

		echo '<form method="get" class="bespari-filters">';
		echo '<input type="hidden" name="page" value="bespari-invoices" />';
		echo '<input type="search" name="s" value="' . esc_attr( $search ) . '" placeholder="' . esc_attr__( 'شماره صورتحساب / شماره سفارش', 'bespari-core' ) . '" class="regular-text" />';
		echo '<input type="date" name="date_from" value="' . esc_attr( $from ) . '" />';
		echo '<input type="date" name="date_to" value="' . esc_attr( $to ) . '" />';
		echo '<button type="submit" class="button">' . esc_html__( 'فیلتر', 'bespari-core' ) . '</button> ';
		$clear = add_query_arg( array( 'page' => 'bespari-invoices' ), admin_url( 'admin.php' ) );
		echo '<a href="' . esc_url( $clear ) . '" class="button">' . esc_html__( 'پاک کردن', 'bespari-core' ) . '</a>';
		echo '</form>';
	}

	private function render_list(): void {
		$args = array(
			'page'     => isset( $_GET['paged'] ) ? max( 1, (int) $_GET['paged'] ) : 1, // phpcs:ignore
			'search'   => isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '', // phpcs:ignore
			'date_from' => isset( $_GET['date_from'] ) ? sanitize_text_field( wp_unslash( $_GET['date_from'] ) ) : '', // phpcs:ignore
			'date_to'   => isset( $_GET['date_to'] ) ? sanitize_text_field( wp_unslash( $_GET['date_to'] ) ) : '', // phpcs:ignore
			'per_page' => 20,
		);
		$service = new AccountingService();
		$res     = $service->list_invoices( $args );
		$items   = $res['items'];
		$total   = $res['total'];
		$page    = max( 1, (int) ( $args['page'] ?? 1 ) );
		$pages   = max( 1, (int) ceil( $total / 20 ) );

		if ( empty( $items ) ) {
			echo '<div class="bespari-empty"><p>' . esc_html__( 'صورتحسابی یافت نشد.', 'bespari-core' ) . '</p></div>';
			return;
		}

		echo '<table class="bespari-table widefat striped"><thead><tr>';
		echo '<th>#</th>';
		echo '<th>' . esc_html__( 'شماره صورتحساب', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'سفارش', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'نوع', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'جمع کل', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'تاریخ', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'عملیات', 'bespari-core' ) . '</th>';
		echo '</tr></thead><tbody>';

		foreach ( $items as $m ) {
			$view_url = add_query_arg( array( 'page' => 'bespari-invoices', 'view' => $m->id ), admin_url( 'admin.php' ) );
			echo '<tr>';
			echo '<td>' . esc_html( $m->id ) . '</td>';
			echo '<td><strong>' . esc_html( $m->invoice_number ) . '</strong></td>';
			echo '<td>' . esc_html( $m->order_number ?: (string) $m->order_id ) . '</td>';
			echo '<td>' . esc_html( $m->type_label() ) . '</td>';
			echo '<td>' . esc_html( Helpers::format_money( $m->total ) ) . '</td>';
			echo '<td><span class="bespari-muted">' . esc_html( $m->created_at ) . '</span></td>';
			echo '<td class="bespari-actions">';
			echo '<a href="' . esc_url( $view_url ) . '" class="button button-small">' . esc_html__( 'مشاهده / چاپ', 'bespari-core' ) . '</a>';
			echo '</td></tr>';
		}
		echo '</tbody></table>';

		if ( $pages > 1 ) {
			echo '<div class="tablenav"><div class="tablenav-pages">';
			echo paginate_links( array( 'base' => add_query_arg( 'paged', '%#%' ), 'format' => '', 'prev_text' => __( '&laquo; قبلی', 'bespari-core' ), 'next_text' => __( 'بعدی &raquo;', 'bespari-core' ), 'total' => $pages, 'current' => $page ) );
			echo '</div></div>';
		}
		echo '<p class="description">' . sprintf( esc_html__( 'مجموع %d صورتحساب', 'bespari-core' ), (int) $total ) . '</p>';
	}

	private function render_add_form(): void {
		global $wpdb;
		$orders     = Helpers::table( 'orders' );
		$invoices   = Helpers::table( 'invoices' );

		// سفارش‌های بدون صورتحساب (۱۰۰ سفارش آخر).
		$rows = $wpdb->get_results( "
			SELECT o.id, o.order_number FROM {$orders} o
			WHERE NOT EXISTS (SELECT 1 FROM {$invoices} i WHERE i.order_id = o.id)
			ORDER BY o.id DESC LIMIT 100
		" ); // phpcs:ignore

		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="bespari-form">';
		wp_nonce_field( 'bespari_generate_invoice', 'bespari_nonce' );
		echo '<input type="hidden" name="action" value="bespari_generate_invoice" />';
		echo '<table class="form-table">';
		echo '<tr><th scope="row"><label>' . esc_html__( 'سفارش', 'bespari-core' ) . ' <span class="required">*</span></label></th><td>';
		echo '<select name="order_id" required>';
		echo '<option value="">' . esc_html__( '— انتخاب سفارش —', 'bespari-core' ) . '</option>';
		foreach ( (array) $rows as $row ) {
			echo '<option value="' . esc_attr( $row->id ) . '">' . esc_html( $row->order_number . ' (#' . $row->id . ')' ) . '</option>';
		}
		echo '</select>';
		echo '<p class="description">' . esc_html__( 'فقط سفارش‌های بدون صورتحساب نمایش داده می‌شوند (۱۰۰ سفارش آخر).', 'bespari-core' ) . '</p>';
		echo '</td></tr>';
		echo '</table>';
		submit_button( __( 'صدور صورتحساب', 'bespari-core' ), 'primary', 'submit' );
		echo '</form>';
	}

	/**
	 * برگه چاپی A4.
	 */
	private function render_print_view( int $id ): void {
		$service = new AccountingService();
		$invoice = $service->get_invoice( $id );

		if ( ! $invoice ) {
			echo '<div class="bespari-empty"><p>' . esc_html__( 'صورتحساب یافت نشد.', 'bespari-core' ) . '</p></div>';
			return;
		}

		$lines     = $invoice->lines();
		$meta      = array(
			'order_number' => $invoice->order_number,
			'customer'     => '',
			'ordered_at'   => '',
		);
		$meta_raw  = json_decode( (string) $invoice->meta, true );
		if ( is_array( $meta_raw ) ) {
			$meta = array_merge( $meta, $meta_raw );
		}
		?>
		<style>
			.bespari-invoice { max-width: 800px; margin: 20px auto; background: #fff; border: 1px solid #eee; border-radius: 8px; padding: 32px; font-family: "Vazirmatn", Tahoma, sans-serif; direction: rtl; }
			.bespari-invoice__header { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #5955D1; padding-bottom: 16px; margin-bottom: 20px; }
			.bespari-invoice__title { font-size: 20px; font-weight: 700; color: #0C243C; margin: 0 0 6px; }
			.bespari-invoice__meta { color: #696981; font-size: 13px; line-height: 1.9; }
			.bespari-invoice table { width: 100%; border-collapse: collapse; margin: 16px 0; }
			.bespari-invoice th, .bespari-invoice td { border: 1px solid #EEEEF3; padding: 9px 12px; font-size: 13px; text-align: right; }
			.bespari-invoice th { background: #f9f9f9; font-weight: 700; }
			.bespari-invoice__total { font-size: 15px; font-weight: 700; text-align: left; }
			.bespari-invoice__actions { margin-top: 24px; text-align: center; }
			@media print {
				#adminmenumain, #wpadminbar, .bespari-invoice__actions { display: none !important; }
				.bespari-invoice { border: none; margin: 0; padding: 0; }
			}
		</style>
		<div class="bespari-invoice">
			<div class="bespari-invoice__header">
				<div>
					<h2 class="bespari-invoice__title"><?php esc_html_e( 'صورتحساب فروش', 'bespari-core' ); ?></h2>
					<div class="bespari-invoice__meta">
						<strong>بسپاری ERP</strong><br />
						<?php esc_html_e( 'برندهای Delori / Amiran / Atron', 'bespari-core' ); ?>
					</div>
				</div>
				<div class="bespari-invoice__meta" style="text-align:left;">
					<strong><?php echo esc_html( $invoice->invoice_number ); ?></strong><br />
					<?php esc_html_e( 'تاریخ صدور:', 'bespari-core' ); ?> <?php echo esc_html( $invoice->created_at ); ?><br />
					<?php esc_html_e( 'سفارش:', 'bespari-core' ); ?> <?php echo esc_html( $meta['order_number'] ?: (string) $invoice->order_id ); ?><br />
					<?php esc_html_e( 'مشتری:', 'bespari-core' ); ?> <?php echo esc_html( $meta['customer'] ?: '—' ); ?>
				</div>
			</div>

			<table>
				<thead>
					<tr>
						<th>#</th>
						<th><?php esc_html_e( 'محصول', 'bespari-core' ); ?></th>
						<th><?php esc_html_e( 'SKU', 'bespari-core' ); ?></th>
						<th><?php esc_html_e( 'تعداد', 'bespari-core' ); ?></th>
						<th><?php esc_html_e( 'قیمت واحد', 'bespari-core' ); ?></th>
						<th><?php esc_html_e( 'جمع ردیف', 'bespari-core' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $lines as $i => $line ) : ?>
					<tr>
						<td><?php echo esc_html( $i + 1 ); ?></td>
						<td><?php echo esc_html( $line['product_name'] ?? '—' ); ?></td>
						<td><?php echo esc_html( $line['sku'] ?? '—' ); ?></td>
						<td><?php echo esc_html( $line['quantity'] ?? 1 ); ?></td>
						<td><?php echo esc_html( Helpers::format_money( (float) ( $line['unit_price'] ?? 0 ) ) ); ?></td>
						<td><?php echo esc_html( Helpers::format_money( (float) ( $line['line_total'] ?? 0 ) ) ); ?></td>
					</tr>
					<?php endforeach; ?>
				</tbody>
			</table>

			<p class="bespari-invoice__total">
				<?php esc_html_e( 'جمع کل:', 'bespari-core' ); ?>
				<?php echo esc_html( Helpers::format_money( $invoice->total ) ); ?>
			</p>

			<div class="bespari-invoice__actions">
				<button class="button button-primary" onclick="window.print()"><?php esc_html_e( 'چاپ / ذخیره PDF', 'bespari-core' ); ?></button>
				<a href="<?php echo esc_url( add_query_arg( array( 'page' => 'bespari-invoices' ), admin_url( 'admin.php' ) ) ); ?>" class="button"><?php esc_html_e( 'بازگشت', 'bespari-core' ); ?></a>
			</div>
		</div>
		<?php
	}
}
