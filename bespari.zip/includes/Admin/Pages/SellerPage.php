<?php
/**
 * صفحه بازاریاب‌ها.
 *
 * @package Bespari\Admin\Pages
 */

namespace Bespari\Admin\Pages;

use Bespari\Modules\Seller\SellerService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SellerPage extends BasePage {

	protected string $slug = 'bespari-sellers';
	protected string $cap  = 'bespari_manage_sellers';

	public function render(): void {
		if ( ! $this->can_access() ) {
			wp_die( esc_html__( 'شما دسترسی لازم را ندارید.', 'bespari-core' ) );
		}

		$tab     = $this->current_tab( 'list' );
		$edit_id = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0; // phpcs:ignore
		if ( $edit_id && 'list' === $tab ) {
			$tab = 'edit';
		}

		echo '<div class="wrap bespari-wrap">';
		$this->page_header( __( 'بازاریاب‌ها', 'bespari-core' ), __( 'مدیریت بازاریاب‌ها (wp_users نقش bespari_seller + درصد پورسانت).', 'bespari-core' ) );
		$this->render_notice();
		$this->render_tabs( $tab, array(
			'list' => __( 'لیست بازاریاب‌ها', 'bespari-core' ),
			'add'  => __( 'افزودن بازاریاب', 'bespari-core' ),
		) );

		if ( 'add' === $tab ) {
			$this->render_form( null );
		} elseif ( 'edit' === $tab && $edit_id ) {
			$service = new SellerService();
			$model   = $service->get( $edit_id );
			if ( ! $model ) {
				echo '<div class="bespari-notice bespari-notice--error"><span>' . esc_html__( 'بازاریاب یافت نشد.', 'bespari-core' ) . '</span></div>';
			} else {
				$this->render_form( $model );
			}
		} else {
			$this->render_filters();
			$this->render_list();
		}

		echo '</div>';
	}

	private function render_filters(): void {
		$search = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : ''; // phpcs:ignore
		$status = isset( $_GET['seller_status'] ) ? sanitize_key( wp_unslash( $_GET['seller_status'] ) ) : ''; // phpcs:ignore
		echo '<form method="get" class="bespari-filters">';
		echo '<input type="hidden" name="page" value="bespari-sellers" />';
		echo '<div class="bespari-filters__row">';
		echo '<input type="search" name="s" value="' . esc_attr( $search ) . '" placeholder="' . esc_attr__( 'نام / ایمیل', 'bespari-core' ) . '" class="regular-text" />';
		echo '<select name="seller_status"><option value="">' . esc_html__( 'همه وضعیت‌ها', 'bespari-core' ) . '</option>';
		echo '<option value="active"' . selected( $status, 'active', false ) . '>' . esc_html__( 'فعال', 'bespari-core' ) . '</option>';
		echo '<option value="inactive"' . selected( $status, 'inactive', false ) . '>' . esc_html__( 'غیرفعال', 'bespari-core' ) . '</option>';
		echo '</select>';
		echo '<button type="submit" class="button">' . esc_html__( 'فیلتر', 'bespari-core' ) . '</button> ';
		$clear = add_query_arg( array( 'page' => 'bespari-sellers' ), admin_url( 'admin.php' ) );
		echo '<a href="' . esc_url( $clear ) . '" class="button">' . esc_html__( 'پاک کردن', 'bespari-core' ) . '</a>';
		echo '</div></form>';
	}

	private function render_list(): void {
		$args = array(
			'page'     => isset( $_GET['paged'] ) ? (int) $_GET['paged'] : 1, // phpcs:ignore
			'search'   => isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '', // phpcs:ignore
			'status'   => isset( $_GET['seller_status'] ) ? sanitize_key( wp_unslash( $_GET['seller_status'] ) ) : '', // phpcs:ignore
			'per_page' => 20,
		);
		$service = new SellerService();
		$res     = $service->list( $args );
		$items   = $res['items'];
		$total   = $res['total'];
		$page    = max( 1, (int) ( $args['page'] ?? 1 ) );
		$pages   = max( 1, (int) ceil( $total / 20 ) );

		if ( empty( $items ) ) {
			echo '<div class="bespari-empty"><p>' . esc_html__( 'بازاریابی یافت نشد.', 'bespari-core' ) . '</p></div>';
			return;
		}

		echo '<table class="bespari-table widefat striped"><thead><tr>';
		echo '<th>' . esc_html__( 'نام', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'ایمیل', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'درصد پورسانت', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'وضعیت', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'تاریخ ثبت', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'عملیات', 'bespari-core' ) . '</th>';
		echo '</tr></thead><tbody>';
		foreach ( $items as $m ) {
			$edit_url   = add_query_arg( array( 'page' => 'bespari-sellers', 'id' => $m->id ), admin_url( 'admin.php' ) );
			$delete_url = $this->admin_action_url( 'delete_seller', array( 'id' => $m->id ) );
			$badge_cls  = 'active' === $m->seller_status ? 'bespari-badge--success' : 'bespari-badge--muted';
			echo '<tr>';
			echo '<td><a href="' . esc_url( $edit_url ) . '"><strong>' . esc_html( $m->display_name ) . '</strong></a> <span class="bespari-muted">(' . esc_html( $m->user_login ) . ')</span></td>';
			echo '<td>' . esc_html( $m->email ) . '</td>';
			echo '<td>' . esc_html( \Bespari\Support\Helpers::format_percent( $m->commission_percent ) ) . '</td>';
			echo '<td><span class="bespari-badge ' . esc_attr( $badge_cls ) . '">' . esc_html( $m->status_label() ) . '</span></td>';
			echo '<td><span class="bespari-muted">' . esc_html( $m->registered_at ) . '</span></td>';
			echo '<td class="bespari-actions">';
			echo '<a href="' . esc_url( $edit_url ) . '" class="button button-small">' . esc_html__( 'ویرایش', 'bespari-core' ) . '</a> ';
			echo '<a href="' . esc_url( $delete_url ) . '" class="button button-small button-link-delete bespari-confirm-delete" data-message="' . esc_attr__( 'حذف نقش بازاریاب؟', 'bespari-core' ) . '">' . esc_html__( 'حذف نقش', 'bespari-core' ) . '</a>';
			echo '</td></tr>';
		}
		echo '</tbody></table>';
		if ( $pages > 1 ) {
			echo '<div class="tablenav"><div class="tablenav-pages">';
			echo paginate_links( array( 'base' => add_query_arg( 'paged', '%#%' ), 'format' => '', 'prev_text' => __( '&laquo; قبلی', 'bespari-core' ), 'next_text' => __( 'بعدی &raquo;', 'bespari-core' ), 'total' => $pages, 'current' => $page ) );
			echo '</div></div>';
		}
		echo '<p class="description">' . sprintf( esc_html__( 'مجموع %d بازاریاب', 'bespari-core' ), (int) $total ) . '</p>';
	}

	/**
	 * @param \Bespari\Modules\Seller\SellerModel|null $model
	 */
	private function render_form( $model ): void {
		$is_edit = null !== $model;
		$action  = admin_url( 'admin-post.php' );
		$val     = function( string $key, $default = '' ) use ( $model ) {
			if ( ! $model ) {
				return $default;
			}
			return $model->$key ?? $default;
		};

		echo '<form method="post" action="' . esc_url( $action ) . '" class="bespari-form">';
		wp_nonce_field( 'bespari_save_seller', 'bespari_nonce' );
		echo '<input type="hidden" name="action" value="bespari_save_seller" />';
		if ( $is_edit ) {
			echo '<input type="hidden" name="seller_id" value="' . esc_attr( $model->id ) . '" />';
		}

		echo '<table class="form-table">';
		if ( ! $is_edit ) {
			echo '<tr><th scope="row"><label>' . esc_html__( 'نام کاربری', 'bespari-core' ) . '</label></th>';
			echo '<td><input type="text" name="seller[user_login]" class="regular-text" placeholder="' . esc_attr__( 'خالی = ایمیل', 'bespari-core' ) . '" /></td></tr>';
		}
		echo '<tr><th scope="row"><label>' . esc_html__( 'نام نمایشی', 'bespari-core' ) . ' <span class="required">*</span></label></th>';
		echo '<td><input type="text" name="seller[display_name]" value="' . esc_attr( $val( 'display_name' ) ) . '" class="regular-text" required /></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'ایمیل', 'bespari-core' ) . ' <span class="required">*</span></label></th>';
		echo '<td><input type="email" name="seller[email]" value="' . esc_attr( $val( 'email' ) ) . '" class="regular-text" dir="ltr" required /></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'رمز عبور', 'bespari-core' ) . ( $is_edit ? '' : ' <span class="required">*</span>' ) . '</label></th>';
		echo '<td><input type="password" name="seller[password]" class="regular-text" autocomplete="new-password" placeholder="' . esc_attr( $is_edit ? __( 'خالی = بدون تغییر', 'bespari-core' ) : '' ) . '" /></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'وضعیت', 'bespari-core' ) . '</label></th><td><select name="seller[seller_status]">';
		foreach ( array( 'active' => __( 'فعال', 'bespari-core' ), 'inactive' => __( 'غیرفعال', 'bespari-core' ) ) as $k => $label ) {
			echo '<option value="' . esc_attr( $k ) . '"' . selected( $val( 'seller_status', 'active' ), $k, false ) . '>' . esc_html( $label ) . '</option>';
		}
		echo '</select></td></tr>';
		echo '</table>';

		// درصد پورسانت per-channel — درصد کلی حذف شده است.
		$channels  = ( new \Bespari\Modules\Channel\ChannelService() )->list();
		$seller_id = $is_edit ? (int) $model->id : 0;
		$seller_repo = new \Bespari\Modules\Seller\SellerRepository();

		echo '<h3>' . esc_html__( 'درصد پورسانت کانال‌ها (اختیاری)', 'bespari-core' ) . '</h3>';
		echo '<p class="description">' . esc_html__( 'اگر برای کانالی درصد سفارشی وارد کنید، همین درصد برای این بازاریاب ملاک است؛ در غیر این صورت درصد تعیین‌شده در خود کانال اعمال می‌شود.', 'bespari-core' ) . '</p>';
		if ( empty( $channels ) ) {
			echo '<p>' . esc_html__( 'هنوز کانالی ثبت نشده است.', 'bespari-core' ) . '</p>';
		} else {
			echo '<table class="bespari-table widefat striped" style="max-width:600px;">';
			echo '<thead><tr><th>' . esc_html__( 'کانال', 'bespari-core' ) . '</th><th>' . esc_html__( 'درصد پورسانت کانال', 'bespari-core' ) . '</th><th>' . esc_html__( 'درصد سفارشی این بازاریاب (%)', 'bespari-core' ) . '</th></tr></thead><tbody>';
			foreach ( $channels as $ch ) {
				$custom = $seller_id > 0 ? $seller_repo->get_channel_percent( $seller_id, (int) $ch->id ) : null;
				echo '<tr>';
				echo '<td>' . esc_html( $ch->name ) . '</td>';
				echo '<td>' . esc_html( \Bespari\Support\Helpers::format_percent( $ch->commission_percent ) ) . '</td>';
				echo '<td><input type="number" name="seller[channel_percents][' . esc_attr( $ch->id ) . ']" value="' . esc_attr( null !== $custom ? (string) $custom : '' ) . '" min="0" max="100" step="0.1" class="small-text" placeholder="' . esc_attr__( 'خالی = درصد کانال', 'bespari-core' ) . '" /></td>';
				echo '</tr>';
			}
			echo '</tbody></table>';
		}

		echo '<table class="form-table">';

		echo '<tr><th scope="row"><label>' . esc_html__( 'وضعیت', 'bespari-core' ) . '</label></th><td><select name="seller[seller_status]">';
		foreach ( array( 'active' => __( 'فعال', 'bespari-core' ), 'inactive' => __( 'غیرفعال', 'bespari-core' ) ) as $k => $label ) {
			echo '<option value="' . esc_attr( $k ) . '"' . selected( $val( 'seller_status', 'active' ), $k, false ) . '>' . esc_html( $label ) . '</option>';
		}
		echo '</select></td></tr>';
		echo '</table>';

		submit_button( $is_edit ? __( 'به‌روزرسانی', 'bespari-core' ) : __( 'ایجاد بازاریاب', 'bespari-core' ), 'primary', 'submit' );
		echo '</form>';
	}
}
