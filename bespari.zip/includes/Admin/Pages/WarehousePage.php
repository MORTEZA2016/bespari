<?php
/**
 * صفحه انبار — موجودی محصولات و گردش موجودی.
 *
 * @package Bespari\Admin\Pages
 */

namespace Bespari\Admin\Pages;

use Bespari\Modules\Warehouse\StockService;
use Bespari\Support\Helpers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WarehousePage extends BasePage {

	protected string $slug = 'bespari-warehouse';
	protected string $cap  = 'bespari_manage_warehouse';

	public function render(): void {
		if ( ! $this->can_access() ) {
			wp_die( esc_html__( 'شما دسترسی لازم را ندارید.', 'bespari-core' ) );
		}

		$tab = $this->current_tab( 'list' );

		$stock_service = new StockService();

		echo '<div class="wrap bespari-wrap">';
		$this->page_header( __( 'انبار', 'bespari-core' ), __( 'موجودی مرکزی محصولات و گردش موجودی (ورود/خروج/تعدیل) با کسر خودکار سفارش.', 'bespari-core' ) );
		$this->render_notice();
		$this->render_tabs( $tab, array(
			'list'      => __( 'موجودی محصولات', 'bespari-core' ),
			'movements' => __( 'گردش موجودی', 'bespari-core' ),
		) );

		if ( 'movements' === $tab ) {
			$this->render_movements( $stock_service );
		} else {
			$this->render_products( $stock_service );
		}

		echo '</div>';
	}

	private function render_products( StockService $service ): void {
		$search    = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : ''; // phpcs:ignore
		$low_stock = ! empty( $_GET['low_stock'] ); // phpcs:ignore
		$page      = isset( $_GET['paged'] ) ? max( 1, (int) $_GET['paged'] ) : 1; // phpcs:ignore

		// فرم تعدیل پردازش‌شده با admin_post — اینجا فقط نمایش.
		$res  = $service->list_products( array( 'search' => $search, 'low_stock' => $low_stock, 'page' => $page, 'per_page' => 20 ) );
		$items = $res['items'];
		$total = $res['total'];
		$pages = max( 1, (int) ceil( $total / 20 ) );

		// فیلترها.
		echo '<form method="get" class="bespari-filters">';
		echo '<input type="hidden" name="page" value="bespari-warehouse" />';
		echo '<div class="bespari-filters__row">';
		echo '<input type="search" name="s" value="' . esc_attr( $search ) . '" placeholder="' . esc_attr__( 'نام / SKU', 'bespari-core' ) . '" class="regular-text" />';
		echo '<label style="display:inline-flex;align-items:center;gap:4px;"><input type="checkbox" name="low_stock" value="1"' . checked( $low_stock, true, false ) . ' /> ' . esc_html__( 'فقط کم‌موجودی', 'bespari-core' ) . '</label>';
		echo '<button type="submit" class="button">' . esc_html__( 'فیلتر', 'bespari-core' ) . '</button>';
		$clear = add_query_arg( array( 'page' => 'bespari-warehouse' ), admin_url( 'admin.php' ) );
		echo ' <a href="' . esc_url( $clear ) . '" class="button">' . esc_html__( 'پاک کردن', 'bespari-core' ) . '</a>';
		echo '</div></form>';

		if ( empty( $items ) ) {
			echo '<div class="bespari-empty"><p>' . esc_html__( 'محصولی یافت نشد.', 'bespari-core' ) . '</p></div>';
			return;
		}

		echo '<table class="bespari-table widefat striped"><thead><tr>';
		echo '<th>' . esc_html__( 'محصول', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'SKU', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'برند', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'موجودی', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'آستانه هشدار', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'تعدیل موجودی', 'bespari-core' ) . '</th>';
		echo '</tr></thead><tbody>';

		foreach ( $items as $p ) {
			$low   = (int) $p->stock <= (int) ( $p->low_stock_threshold ?? 5 );
			$badge = $low ? 'bespari-badge--danger' : 'bespari-badge--success';
			echo '<tr>';
			echo '<td><strong>' . esc_html( $p->name ) . '</strong></td>';
			echo '<td><span class="bespari-muted">' . esc_html( $p->sku ?: '—' ) . '</span></td>';
			echo '<td>' . esc_html( $p->brand_name ?? '' ?: '—' ) . '</td>';
			echo '<td><span class="bespari-badge ' . esc_attr( $badge ) . '">' . esc_html( (string) (int) $p->stock ) . '</span></td>';
			echo '<td>' . esc_html( (string) (int) ( $p->low_stock_threshold ?? 5 ) ) . '</td>';
			echo '<td>';
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="bespari-form bespari-form--inline" style="display:flex;gap:6px;align-items:center;">';
			wp_nonce_field( 'bespari_adjust_stock', 'bespari_nonce' );
			echo '<input type="hidden" name="action" value="bespari_adjust_stock" />';
			echo '<input type="hidden" name="product_id" value="' . esc_attr( $p->id ) . '" />';
			echo '<select name="movement_type" style="width:auto;">';
			echo '<option value="in">' . esc_html__( 'ورود', 'bespari-core' ) . '</option>';
			echo '<option value="out">' . esc_html__( 'خروج', 'bespari-core' ) . '</option>';
			echo '<option value="adjust">' . esc_html__( 'تعدیل (مقدار نهایی)', 'bespari-core' ) . '</option>';
			echo '</select> ';
			echo '<input type="number" name="quantity" min="0" step="1" class="small-text" placeholder="' . esc_attr__( 'تعداد', 'bespari-core' ) . '" required /> ';
			echo '<input type="text" name="notes" class="regular-text" placeholder="' . esc_attr__( 'یادداشت (اختیاری)', 'bespari-core' ) . '" /> ';
			echo '<button type="submit" class="button button-small button-primary">' . esc_html__( 'ثبت', 'bespari-core' ) . '</button>';
			echo '</form>';
			echo '</td></tr>';
		}
		echo '</tbody></table>';

		if ( $pages > 1 ) {
			echo '<div class="tablenav"><div class="tablenav-pages">';
			echo paginate_links( array( 'base' => add_query_arg( 'paged', '%#%' ), 'format' => '', 'prev_text' => __( '&laquo; قبلی', 'bespari-core' ), 'next_text' => __( 'بعدی &raquo;', 'bespari-core' ), 'total' => $pages, 'current' => $page ) );
			echo '</div></div>';
		}
		echo '<p class="description">' . sprintf( esc_html__( 'مجموع %d محصول', 'bespari-core' ), (int) $total ) . '</p>';
	}

	private function render_movements( StockService $service ): void {
		$product_id = isset( $_GET['product_id'] ) ? (int) $_GET['product_id'] : 0; // phpcs:ignore
		$type       = isset( $_GET['type'] ) ? sanitize_key( wp_unslash( $_GET['type'] ) ) : ''; // phpcs:ignore
		$date_from  = isset( $_GET['date_from'] ) ? sanitize_text_field( wp_unslash( $_GET['date_from'] ) ) : ''; // phpcs:ignore
		$date_to    = isset( $_GET['date_to'] ) ? sanitize_text_field( wp_unslash( $_GET['date_to'] ) ) : ''; // phpcs:ignore
		$page       = isset( $_GET['paged'] ) ? max( 1, (int) $_GET['paged'] ) : 1; // phpcs:ignore

		// فیلترها.
		echo '<form method="get" class="bespari-filters">';
		echo '<input type="hidden" name="page" value="bespari-warehouse" />';
		echo '<input type="hidden" name="tab" value="movements" />';
		echo '<div class="bespari-filters__row">';
		echo '<input type="number" name="product_id" value="' . esc_attr( (string) $product_id ) . '" min="0" class="small-text" placeholder="' . esc_attr__( 'شناسه محصول', 'bespari-core' ) . '" />';
		echo '<select name="type"><option value="">' . esc_html__( 'همه انواع', 'bespari-core' ) . '</option>';
		foreach ( array( 'in' => __( 'ورود', 'bespari-core' ), 'out' => __( 'خروج', 'bespari-core' ), 'adjust' => __( 'تعدیل', 'bespari-core' ) ) as $k => $label ) {
			echo '<option value="' . esc_attr( $k ) . '"' . selected( $type, $k, false ) . '>' . esc_html( $label ) . '</option>';
		}
		echo '</select>';
		echo '<input type="date" name="date_from" value="' . esc_attr( $date_from ) . '" />';
		echo '<input type="date" name="date_to" value="' . esc_attr( $date_to ) . '" />';
		echo '<button type="submit" class="button">' . esc_html__( 'فیلتر', 'bespari-core' ) . '</button>';
		$clear = add_query_arg( array( 'page' => 'bespari-warehouse', 'tab' => 'movements' ), admin_url( 'admin.php' ) );
		echo ' <a href="' . esc_url( $clear ) . '" class="button">' . esc_html__( 'پاک کردن', 'bespari-core' ) . '</a>';
		echo '</div></form>';

		$res   = $service->list_movements( array( 'product_id' => $product_id, 'type' => $type, 'date_from' => $date_from, 'date_to' => $date_to, 'page' => $page, 'per_page' => 20 ) );
		$items = $res['items'];
		$total = $res['total'];
		$pages = max( 1, (int) ceil( $total / 20 ) );

		if ( empty( $items ) ) {
			echo '<div class="bespari-empty"><p>' . esc_html__( 'گردشی ثبت نشده است.', 'bespari-core' ) . '</p></div>';
			return;
		}

		echo '<table class="bespari-table widefat striped"><thead><tr>';
		echo '<th>#</th>';
		echo '<th>' . esc_html__( 'محصول', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'نوع', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'تغییر', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'موجودی قبلی', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'موجودی جدید', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'مرجع', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'یادداشت', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'تاریخ', 'bespari-core' ) . '</th>';
		echo '</tr></thead><tbody>';

		foreach ( $items as $m ) {
			$badge = 'in' === $m->type ? 'bespari-badge--success' : ( 'out' === $m->type ? 'bespari-badge--danger' : 'bespari-badge--info' );
			echo '<tr>';
			echo '<td>' . esc_html( $m->id ) . '</td>';
			echo '<td>' . esc_html( $m->product_name ?: (string) $m->product_id ) . '</td>';
			echo '<td><span class="bespari-badge ' . esc_attr( $badge ) . '">' . esc_html( $m->type_label() ) . '</span></td>';
			echo '<td>' . esc_html( (string) $m->quantity ) . '</td>';
			echo '<td>' . esc_html( (string) $m->stock_before ) . '</td>';
			echo '<td>' . esc_html( (string) $m->stock_after ) . '</td>';
			echo '<td>' . esc_html( $m->ref_label() ) . ( $m->ref_id ? ' #' . esc_html( $m->ref_id ) : '' ) . '</td>';
			echo '<td><span class="bespari-muted">' . esc_html( $m->notes ? mb_strimwidth( $m->notes, 0, 50, '…' ) : '—' ) . '</span></td>';
			echo '<td><span class="bespari-muted">' . esc_html( $m->created_at ) . '</span></td>';
			echo '</tr>';
		}
		echo '</tbody></table>';

		if ( $pages > 1 ) {
			echo '<div class="tablenav"><div class="tablenav-pages">';
			echo paginate_links( array( 'base' => add_query_arg( 'paged', '%#%' ), 'format' => '', 'prev_text' => __( '&laquo; قبلی', 'bespari-core' ), 'next_text' => __( 'بعدی &raquo;', 'bespari-core' ), 'total' => $pages, 'current' => $page ) );
			echo '</div></div>';
		}
		echo '<p class="description">' . sprintf( esc_html__( 'مجموع %d گردش', 'bespari-core' ), (int) $total ) . '</p>';
	}
}
