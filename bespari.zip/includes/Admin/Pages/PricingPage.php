<?php
/**
 * صفحه قوانین قیمت‌گذاری + پیش‌نمایش قیمت.
 *
 * @package Bespari\Admin\Pages
 */

namespace Bespari\Admin\Pages;

use Bespari\Modules\Pricing\PricingRuleService;
use Bespari\Modules\Pricing\PricingEngine;
use Bespari\Modules\Channel\ChannelService;
use Bespari\Modules\Brand\BrandService;
use Bespari\Modules\Product\ProductService;
use Bespari\Support\Helpers;

// جلوگیری از دسترسی مستقیم.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class PricingPage extends BasePage {

	protected string $slug = 'bespari-pricing';
	protected string $cap  = 'bespari_manage_pricing';

	public function render(): void {
		if ( ! $this->can_access() ) {
			wp_die( esc_html__( 'شما دسترسی لازم را ندارید.', 'bespari-core' ) );
		}

		$tab     = $this->current_tab( 'list' );
		$edit_id = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0; // phpcs:ignore
		if ( $edit_id && 'list' === $tab ) {
			$tab = 'edit';
		}

		echo '<div class="wrap bespari-wrap">';
		$this->page_header( __( 'قوانین قیمت‌گذاری', 'bespari-core' ), __( 'قوانین اولویت‌دار برای تعدیل قیمت پایه. قابل‌تجمع یا جایگزین.', 'bespari-core' ) );
		$this->render_notice();
		$this->render_tabs( $tab, array(
			'list'    => __( 'لیست قوانین', 'bespari-core' ),
			'add'     => __( 'افزودن قانون', 'bespari-core' ),
			'preview' => __( 'پیش‌نمایش قیمت', 'bespari-core' ),
		) );

		if ( 'add' === $tab ) {
			$this->render_form( null );
		} elseif ( 'edit' === $tab && $edit_id ) {
			$service = new PricingRuleService();
			$rule    = $service->get( $edit_id );
			if ( ! $rule ) {
				echo '<div class="bespari-notice bespari-notice--error"><span>' . esc_html__( 'قانون یافت نشد.', 'bespari-core' ) . '</span></div>';
			} else {
				$this->render_form( $rule );
			}
		} elseif ( 'preview' === $tab ) {
			$this->render_preview_tool();
		} else {
			$this->render_list();
		}

		echo '</div>';
	}

	private function render_list(): void {
		$service = new PricingRuleService();
		$rules   = $service->list();

		if ( empty( $rules ) ) {
			echo '<div class="bespari-empty"><p>' . esc_html__( 'هنوز قانونی ثبت نشده است.', 'bespari-core' ) . '</p></div>';
			return;
		}

		echo '<table class="bespari-table widefat striped">';
		echo '<thead><tr>';
		echo '<th>' . esc_html__( 'عنوان', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'سطح', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'تعدیل', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'نوع فروش', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'اولویت', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'تجمع', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'وضعیت', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'عملیات', 'bespari-core' ) . '</th>';
		echo '</tr></thead><tbody>';

		foreach ( $rules as $r ) {
			$edit_url   = add_query_arg( array( 'page' => 'bespari-pricing', 'id' => $r->id ), admin_url( 'admin.php' ) );
			$delete_url = $this->admin_action_url( 'delete_pricing_rule', array( 'id' => $r->id ) );
			$badge_cls  = 1 === $r->is_active ? 'bespari-badge--success' : 'bespari-badge--muted';

			$adj = ( 'percent' === $r->adjustment_type )
				? Helpers::format_percent( $r->adjustment_value )
				: Helpers::format_money( $r->adjustment_value );
			$adj = ( $r->adjustment_value > 0 ? '+' : '' ) . $adj;

			echo '<tr>';
			echo '<td><strong>' . esc_html( $r->title ) . '</strong> <span class="bespari-muted">v' . esc_html( $r->rule_version ) . '</span></td>';
			echo '<td>' . esc_html( $r->scope_label() ) . '</td>';
			echo '<td>' . esc_html( $adj ) . ' <span class="bespari-muted">(' . esc_html( $r->adjustment_type_label() ) . ')</span></td>';
			echo '<td>' . esc_html( $r->sale_type_label() ) . '</td>';
			echo '<td>' . esc_html( $r->priority ) . '</td>';
			echo '<td>' . ( $r->stackable ? '<span class="bespari-badge bespari-badge--info">' . esc_html__( 'تجمعی', 'bespari-core' ) . '</span>' : '<span class="bespari-badge bespari-badge--warning">' . esc_html__( 'جایگزین', 'bespari-core' ) . '</span>' ) . '</td>';
			echo '<td><span class="bespari-badge ' . esc_attr( $badge_cls ) . '">' . ( 1 === $r->is_active ? esc_html__( 'فعال', 'bespari-core' ) : esc_html__( 'غیرفعال', 'bespari-core' ) ) . '</span></td>';
			echo '<td class="bespari-actions">';
			echo '<a href="' . esc_url( $edit_url ) . '" class="button button-small">' . esc_html__( 'ویرایش', 'bespari-core' ) . '</a> ';
			echo '<a href="' . esc_url( $delete_url ) . '" class="button button-small button-link-delete bespari-confirm-delete" data-message="' . esc_attr__( 'آیا از حذف این قانون اطمینان دارید؟', 'bespari-core' ) . '">' . esc_html__( 'حذف', 'bespari-core' ) . '</a>';
			echo '</td>';
			echo '</tr>';
		}

		echo '</tbody></table>';
	}

	/**
	 * @param \Bespari\Modules\Pricing\PricingRuleModel|null $rule
	 */
	private function render_form( $rule ): void {
		$is_edit = null !== $rule;
		$action  = admin_url( 'admin-post.php' );

		$val = function( string $key, $default = '' ) use ( $rule ) {
			if ( ! $rule ) {
				return $default;
			}
			return $rule->$key ?? $default;
		};

		echo '<form method="post" action="' . esc_url( $action ) . '" class="bespari-form">';
		wp_nonce_field( 'bespari_save_pricing_rule', 'bespari_nonce' );
		echo '<input type="hidden" name="action" value="bespari_save_pricing_rule" />';
		if ( $is_edit ) {
			echo '<input type="hidden" name="rule_id" value="' . esc_attr( $rule->id ) . '" />';
		}

		echo '<table class="form-table">';

		echo '<tr><th scope="row"><label>' . esc_html__( 'عنوان قانون', 'bespari-core' ) . ' <span class="required">*</span></label></th>';
		echo '<td><input type="text" name="rule[title]" value="' . esc_attr( $val( 'title' ) ) . '" class="regular-text" required placeholder="' . esc_attr__( 'مثلاً: افزایش دیجی‌کالا', 'bespari-core' ) . '" /></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'سطح قانون', 'bespari-core' ) . '</label></th><td><select name="rule[scope]">';
		foreach ( array( 'channel' => __( 'کانال', 'bespari-core' ), 'brand' => __( 'برند', 'bespari-core' ), 'category' => __( 'دسته‌بندی', 'bespari-core' ), 'product' => __( 'محصول خاص', 'bespari-core' ), 'seller' => __( 'بازاریاب', 'bespari-core' ) ) as $k => $t ) {
			echo '<option value="' . esc_attr( $k ) . '"' . selected( $val( 'scope', 'channel' ), $k, false ) . '>' . esc_html( $t ) . '</option>';
		}
		echo '</select><p class="description">' . esc_html__( 'قوانین سطح محصول بر دسته و کانال اولویت دارند (بر اساس فیلد اولویت).', 'bespari-core' ) . '</p></td></tr>';

		// فیلدهای محدوده (کانال/برند/محصول).
		echo '<tr><th scope="row"><label>' . esc_html__( 'کانال هدف', 'bespari-core' ) . '</label></th><td><select name="rule[channel_id]"><option value="0">' . esc_html__( 'همه کانال‌ها', 'bespari-core' ) . '</option>';
		foreach ( ( new ChannelService() )->list( true ) as $ch ) {
			echo '<option value="' . esc_attr( $ch->id ) . '"' . selected( (int) $val( 'channel_id', 0 ), $ch->id, false ) . '>' . esc_html( $ch->name ) . '</option>';
		}
		echo '</select></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'برند هدف', 'bespari-core' ) . '</label></th><td><select name="rule[brand_id]"><option value="0">' . esc_html__( 'همه برندها', 'bespari-core' ) . '</option>';
		foreach ( ( new BrandService() )->list( true ) as $b ) {
			echo '<option value="' . esc_attr( $b->id ) . '"' . selected( (int) $val( 'brand_id', 0 ), $b->id, false ) . '>' . esc_html( $b->name ) . '</option>';
		}
		echo '</select></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'محصول هدف', 'bespari-core' ) . '</label></th><td><input type="number" name="rule[product_id]" value="' . esc_attr( (int) $val( 'product_id', 0 ) ) . '" class="small-text" /> <span class="description">' . esc_html__( '۰ یعنی همه محصولات', 'bespari-core' ) . '</span></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'نوع تعدیل', 'bespari-core' ) . '</label></th><td><select name="rule[adjustment_type]">';
		echo '<option value="percent"' . selected( $val( 'adjustment_type', 'percent' ), 'percent', false ) . '>' . esc_html__( 'درصدی', 'bespari-core' ) . '</option>';
		echo '<option value="fixed"' . selected( $val( 'adjustment_type', 'percent' ), 'fixed', false ) . '>' . esc_html__( 'مبلغ ثابت', 'bespari-core' ) . '</option>';
		echo '</select></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'مقدار تعدیل', 'bespari-core' ) . '</label></th>';
		echo '<td><input type="number" step="0.01" name="rule[adjustment_value]" value="' . esc_attr( (float) $val( 'adjustment_value', 0 ) ) . '" class="small-text" /> <span class="description">' . esc_html__( 'عدد منفی = تخفیف', 'bespari-core' ) . '</span></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'نوع فروش', 'bespari-core' ) . '</label></th><td><select name="rule[sale_type]">';
		foreach ( array( 'all' => __( 'همه', 'bespari-core' ), 'cash' => __( 'نقدی', 'bespari-core' ), 'credit' => __( 'اعتباری', 'bespari-core' ) ) as $k => $t ) {
			echo '<option value="' . esc_attr( $k ) . '"' . selected( $val( 'sale_type', 'all' ), $k, false ) . '>' . esc_html( $t ) . '</option>';
		}
		echo '</select></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'اولویت', 'bespari-core' ) . '</label></th>';
		echo '<td><input type="number" name="rule[priority]" value="' . esc_attr( (int) $val( 'priority', 10 ) ) . '" class="small-text" /> <span class="description">' . esc_html__( 'عدد کوچکتر = اولویت بالاتر', 'bespari-core' ) . '</span></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'قابل‌تجمع', 'bespari-core' ) . '</label></th><td><select name="rule[stackable]">';
		echo '<option value="1"' . selected( (int) $val( 'stackable', 1 ), 1, false ) . '>' . esc_html__( 'بله — با قوانین قبلی جمع می‌شود', 'bespari-core' ) . '</option>';
		echo '<option value="0"' . selected( (int) $val( 'stackable', 1 ), 0, false ) . '>' . esc_html__( 'خیر — قوانین قبلی را جایگزین می‌کند', 'bespari-core' ) . '</option>';
		echo '</select></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'معتبر از', 'bespari-core' ) . '</label></th>';
		echo '<td><input type="date" name="rule[valid_from]" value="' . esc_attr( $val( 'valid_from' ) ) . '" /> <span class="description">' . esc_html__( 'خالی = بدون محدودیت', 'bespari-core' ) . '</span></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'معتبر تا', 'bespari-core' ) . '</label></th>';
		echo '<td><input type="date" name="rule[valid_to]" value="' . esc_attr( $val( 'valid_to' ) ) . '" /></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'وضعیت', 'bespari-core' ) . '</label></th><td><select name="rule[is_active]">';
		echo '<option value="1"' . selected( (int) $val( 'is_active', 1 ), 1, false ) . '>' . esc_html__( 'فعال', 'bespari-core' ) . '</option>';
		echo '<option value="0"' . selected( (int) $val( 'is_active', 1 ), 0, false ) . '>' . esc_html__( 'غیرفعال', 'bespari-core' ) . '</option>';
		echo '</select></td></tr>';

		echo '</table>';
		submit_button( $is_edit ? __( 'به‌روزرسانی قانون', 'bespari-core' ) : __( 'ایجاد قانون', 'bespari-core' ), 'primary', 'submit' );
		echo '</form>';
	}

	/**
	 * ابزار پیش‌نمایش قیمت (AJAX از admin.js).
	 */
	private function render_preview_tool(): void {
		echo '<div class="bespari-box bespari-box--white">';
		echo '<h3 class="bespari-box__title">' . esc_html__( 'پیش‌نمایش محاسبه قیمت', 'bespari-core' ) . '</h3>';
		echo '<p class="description">' . esc_html__( 'یک محصول و کانال انتخاب کنید تا شکست قیمت و کسورات محاسبه شود.', 'bespari-core' ) . '</p>';

		echo '<table class="form-table">';
		echo '<tr><th scope="row"><label>' . esc_html__( 'محصول', 'bespari-core' ) . '</label></th><td><select id="bespari-preview-product"><option value="0">' . esc_html__( '— انتخاب کنید —', 'bespari-core' ) . '</option>';
		$res = ( new ProductService() )->list( array( 'per_page' => 500 ) );
		foreach ( $res['items'] as $p ) {
			echo '<option value="' . esc_attr( $p->id ) . '">' . esc_html( $p->name ) . '</option>';
		}
		echo '</select></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'کانال', 'bespari-core' ) . '</label></th><td><select id="bespari-preview-channel"><option value="0">' . esc_html__( '— انتخاب کنید —', 'bespari-core' ) . '</option>';
		foreach ( ( new ChannelService() )->list( true ) as $ch ) {
			echo '<option value="' . esc_attr( $ch->id ) . '">' . esc_html( $ch->name ) . '</option>';
		}
		echo '</select></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'نوع فروش', 'bespari-core' ) . '</label></th><td><select id="bespari-preview-saletype">';
		echo '<option value="cash">' . esc_html__( 'نقدی', 'bespari-core' ) . '</option>';
		echo '<option value="credit">' . esc_html__( 'اعتباری', 'bespari-core' ) . '</option>';
		echo '</select></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'تعداد', 'bespari-core' ) . '</label></th><td><input type="number" id="bespari-preview-qty" value="1" min="1" class="small-text" /></td></tr>';
		echo '</table>';

		echo '<p><button type="button" class="button button-primary" id="bespari-preview-run">' . esc_html__( 'محاسبه قیمت', 'bespari-core' ) . '</button></p>';
		echo '<div id="bespari-preview-result" class="bespari-preview-result" aria-live="polite"></div>';
		echo '</div>';
	}
}
