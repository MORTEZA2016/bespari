<?php
/**
 * صفحه گزارشات — نمودار Chart.js + P&L + top محصول + خروجی CSV.
 *
 * @package Bespari\Admin\Pages
 */

namespace Bespari\Admin\Pages;

use Bespari\Modules\Report\ReportService;
use Bespari\Support\Helpers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ReportsPage extends BasePage {

	protected string $slug = 'bespari-reports';
	protected string $cap  = 'bespari_view_reports';

	public function render(): void {
		if ( ! $this->can_access() ) {
			wp_die( esc_html__( 'شما دسترسی لازم را ندارید.', 'bespari-core' ) );
		}

		$from    = isset( $_GET['date_from'] ) ? sanitize_text_field( wp_unslash( $_GET['date_from'] ) ) : gmdate( 'Y-m-01' ); // phpcs:ignore
		$to      = isset( $_GET['date_to'] ) ? sanitize_text_field( wp_unslash( $_GET['date_to'] ) ) : gmdate( 'Y-m-d' ); // phpcs:ignore
		$channel = isset( $_GET['channel_id'] ) ? (int) $_GET['channel_id'] : 0; // phpcs:ignore

		$service = new ReportService();
		$daily   = $service->daily_sales( $from, $to, $channel );
		$by_ch   = $service->by_channel( $from, $to );
		$top     = $service->top_products( $from, $to, 10 );
		$pnl     = $service->pnl( $from, $to, $channel );
		$kpis    = $service->kpis();

		echo '<div class="wrap bespari-wrap">';
		$this->page_header( __( 'گزارشات', 'bespari-core' ), __( 'فروش روزانه، تفکیک کانال، پرفروش‌ترین محصولات و سود و خسارت.', 'bespari-core' ) );
		$this->render_notice();

		// فیلتر بازه.
		echo '<form method="get" class="bespari-filters">';
		echo '<input type="hidden" name="page" value="bespari-reports" />';
		echo '<input type="date" name="date_from" value="' . esc_attr( $from ) . '" />';
		echo '<input type="date" name="date_to" value="' . esc_attr( $to ) . '" />';
		echo '<select name="channel_id"><option value="0">' . esc_html__( 'همه کانال‌ها', 'bespari-core' ) . '</option>';
		global $wpdb;
		$channels = Helpers::table( 'channels' );
		foreach ( (array) $wpdb->get_results( "SELECT id, name FROM {$channels} ORDER BY name" ) as $c ) { // phpcs:ignore
			echo '<option value="' . esc_attr( $c->id ) . '"' . selected( $channel, (int) $c->id, false ) . '>' . esc_html( $c->name ) . '</option>';
		}
		echo '</select>';
		echo '<button type="submit" class="button button-primary">' . esc_html__( 'اعمال', 'bespari-core' ) . '</button> ';

		$export_daily = wp_nonce_url( add_query_arg( array( 'page' => 'bespari-reports', 'action' => 'bespari_export_report', 'bespari_export' => 1, 'report' => 'daily', 'date_from' => $from, 'date_to' => $to, 'channel_id' => $channel ), admin_url( 'admin-post.php' ) ), 'bespari_export_report', 'bespari_nonce' );
		$export_top   = wp_nonce_url( add_query_arg( array( 'page' => 'bespari-reports', 'action' => 'bespari_export_report', 'bespari_export' => 1, 'report' => 'top', 'date_from' => $from, 'date_to' => $to ), admin_url( 'admin-post.php' ) ), 'bespari_export_report', 'bespari_nonce' );
		echo '<a href="' . esc_url( $export_daily ) . '" class="button">' . esc_html__( 'خروجی CSV فروش روزانه', 'bespari-core' ) . '</a> ';
		echo '<a href="' . esc_url( $export_top ) . '" class="button">' . esc_html__( 'خروجی CSV پرفروش‌ها', 'bespari-core' ) . '</a>';
		echo '</form>';

		// کارت‌های KPI.
		echo '<div class="bespari-stats-grid">';
		$cards = array(
			array( 'label' => __( 'فروش ماه جاری', 'bespari-core' ), 'value' => Helpers::format_money( $kpis['month_sales'] ), 'icon' => 'dashicons-chart-line', 'cls' => 'bespari-avatar--primary' ),
			array( 'label' => __( 'سود ماه جاری', 'bespari-core' ), 'value' => Helpers::format_money( $kpis['month_profit'] ), 'icon' => 'dashicons-chart-area', 'cls' => 'bespari-avatar--success' ),
			array( 'label' => __( 'سفارش‌های ماه', 'bespari-core' ), 'value' => (string) $kpis['month_orders'], 'icon' => 'dashicons-cart', 'cls' => 'bespari-avatar--info' ),
			array( 'label' => __( 'مانده کل کیف پول‌ها', 'bespari-core' ), 'value' => Helpers::format_money( $kpis['wallet_total'] ), 'icon' => 'dashicons-money-alt', 'cls' => 'bespari-avatar--warning' ),
		);
		foreach ( $cards as $card ) {
			echo '<div class="bespari-card"><div class="bespari-avatar ' . esc_attr( $card['cls'] ) . '"><span class="dashicons ' . esc_attr( $card['icon'] ) . '"></span></div>';
			echo '<div class="bespari-card__body"><span class="bespari-card__value">' . esc_html( $card['value'] ) . '</span>';
			echo '<span class="bespari-card__label">' . esc_html( $card['label'] ) . '</span></div></div>';
		}
		echo '</div>';

		// نمودارها.
		echo '<div class="bespari-row">';
		echo '<div class="bespari-col bespari-col--8"><div class="bespari-box">';
		echo '<h3 class="bespari-box__title">' . esc_html__( 'فروش روزانه', 'bespari-core' ) . '</h3>';
		echo '<canvas id="bespari-chart-daily" height="110"></canvas>';
		echo '</div></div>';
		echo '<div class="bespari-col bespari-col--4"><div class="bespari-box">';
		echo '<h3 class="bespari-box__title">' . esc_html__( 'فروش per کانال', 'bespari-core' ) . '</h3>';
		echo '<canvas id="bespari-chart-channel" height="140"></canvas>';
		echo '</div></div>';
		echo '</div>';

		// داده نمودارها.
		$daily_labels = array();
		$daily_net    = array();
		$daily_profit = array();
		foreach ( $daily as $row ) {
			$daily_labels[] = (string) $row->day;
			$daily_net[]    = (float) $row->net;
			$daily_profit[] = (float) $row->profit;
		}

		$ch_labels = array();
		$ch_net    = array();
		foreach ( $by_ch as $row ) {
			$ch_labels[] = (string) $row->channel_name;
			$ch_net[]    = (float) $row->net;
		}
		?>
		<script>
			(function () {
				function boot() {
					if (typeof Chart === 'undefined') { return; }
					var el = document.getElementById('bespari-chart-daily');
					var el2 = document.getElementById('bespari-chart-channel');
					if (!el || !el2) { return; }
					var fontFamily = 'Vazirmatn, Tahoma, sans-serif';
					Chart.defaults.font.family = fontFamily;

					new Chart(el, {
						type: 'line',
						data: {
							labels: <?php echo wp_json_encode( $daily_labels ); ?>,
							datasets: [
								{ label: <?php echo wp_json_encode( __( 'خالص فروش', 'bespari-core' ) ); ?>, data: <?php echo wp_json_encode( $daily_net ); ?>, borderColor: '#5955D1', backgroundColor: 'rgba(89,85,209,.08)', fill: true, tension: .3 },
								{ label: <?php echo wp_json_encode( __( 'سود', 'bespari-core' ) ); ?>, data: <?php echo wp_json_encode( $daily_profit ); ?>, borderColor: '#009966', backgroundColor: 'transparent', tension: .3 }
							]
						},
						options: { responsive: true, plugins: { legend: { position: 'bottom' } } }
					});

					new Chart(el2, {
						type: 'doughnut',
						data: {
							labels: <?php echo wp_json_encode( $ch_labels ); ?>,
							datasets: [{ data: <?php echo wp_json_encode( $ch_net ); ?>, backgroundColor: ['#5955D1', '#009966', '#7008E7', '#F5A70D', '#F83636', '#97A1C0', '#29294B', '#bfe6d9', '#dbc1f9', '#fde9c3'] }]
						},
						options: { responsive: true, plugins: { legend: { position: 'bottom' } } }
					});
				}
				if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', boot); } else { boot(); }
			})();
		</script>
		<?php

		// Top محصولات.
		echo '<div class="bespari-box" style="margin-top:16px;">';
		echo '<h3 class="bespari-box__title">' . esc_html__( 'پرفروش‌ترین محصولات', 'bespari-core' ) . '</h3>';
		if ( empty( $top ) ) {
			echo '<p class="description">' . esc_html__( 'داده‌ای در این بازه یافت نشد.', 'bespari-core' ) . '</p>';
		} else {
			echo '<table class="bespari-table widefat striped"><thead><tr>';
			echo '<th>#</th><th>' . esc_html__( 'محصول', 'bespari-core' ) . '</th><th>' . esc_html__( 'تعداد فروش', 'bespari-core' ) . '</th><th>' . esc_html__( 'جمع فروش', 'bespari-core' ) . '</th>';
			echo '</tr></thead><tbody>';
			$i = 1;
			foreach ( $top as $row ) {
				echo '<tr><td>' . esc_html( $i++ ) . '</td><td>' . esc_html( $row->product_name ?: (string) $row->product_id ) . '</td>';
				echo '<td>' . esc_html( (int) $row->qty ) . '</td><td>' . esc_html( Helpers::format_money( (float) $row->total ) ) . '</td></tr>';
			}
			echo '</tbody></table>';
		}
		echo '</div>';

		// P&L.
		echo '<div class="bespari-box" style="margin-top:16px;">';
		echo '<h3 class="bespari-box__title">' . esc_html__( 'سود و خسارت (P&L)', 'bespari-core' ) . '</h3>';
		echo '<table class="bespari-table widefat striped"><tbody>';
		$last = count( $pnl ) - 1;
		foreach ( $pnl as $idx => $row ) {
			$color = $row['value'] >= 0 ? 'var(--bespari-dark)' : 'var(--bespari-danger)';
			$bold  = $idx === $last ? 'font-weight:700;' : '';
			echo '<tr><td>' . esc_html( $row['label'] ) . '</td>';
			echo '<td style="color:' . esc_attr( $color ) . ';' . esc_attr( $bold ) . '">' . esc_html( Helpers::format_money( $row['value'] ) ) . '</td></tr>';
		}
		echo '</tbody></table>';
		echo '</div>';

		echo '</div>';
	}
}
