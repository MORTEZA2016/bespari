<?php
/**
 * صفحه ارسال‌ها — برگه‌های ارسال با QR و برگه چاپی.
 *
 * @package Bespari\Admin\Pages
 */

namespace Bespari\Admin\Pages;

use Bespari\Modules\Shipping\ShipmentService;
use Bespari\Modules\Order\OrderRepository;
use Bespari\Support\Helpers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ShipmentPage extends BasePage {

	protected string $slug = 'bespari-shipments';
	protected string $cap  = 'bespari_manage_shipping';

	public function render(): void {
		if ( ! $this->can_access() ) {
			wp_die( esc_html__( 'شما دسترسی لازم را ندارید.', 'bespari-core' ) );
		}

		$tab = $this->current_tab( 'list' );
		$view_id = isset( $_GET['view'] ) ? (int) $_GET['view'] : 0; // phpcs:ignore
		$edit_id = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0; // phpcs:ignore

		echo '<div class="wrap bespari-wrap">';
		$this->page_header( __( 'ارسال‌ها', 'bespari-core' ), __( 'برگه‌های ارسال سفارش با کد رهگیری، QR و برگه چاپی.', 'bespari-core' ) );
		$this->render_notice();

		if ( $view_id ) {
			$this->render_view( $view_id );
			echo '</div>';
			return;
		}

		$this->render_tabs( $tab, array(
			'list' => __( 'لیست ارسال‌ها', 'bespari-core' ),
			'add'  => __( 'ثبت برگه ارسال', 'bespari-core' ),
		) );

		if ( 'add' === $tab ) {
			$this->render_form( $edit_id );
		} else {
			$this->render_filters();
			$this->render_list();
		}

		echo '</div>';
	}

	private function render_filters(): void {
		$search   = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : ''; // phpcs:ignore
		$status   = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : ''; // phpcs:ignore
		$date_from = isset( $_GET['date_from'] ) ? sanitize_text_field( wp_unslash( $_GET['date_from'] ) ) : ''; // phpcs:ignore
		$date_to  = isset( $_GET['date_to'] ) ? sanitize_text_field( wp_unslash( $_GET['date_to'] ) ) : ''; // phpcs:ignore

		echo '<form method="get" class="bespari-filters">';
		echo '<input type="hidden" name="page" value="bespari-shipments" />';
		echo '<div class="bespari-filters__row">';
		echo '<input type="search" name="s" value="' . esc_attr( $search ) . '" placeholder="' . esc_attr__( 'کد رهگیری / سفارش / مشتری', 'bespari-core' ) . '" class="regular-text" />';
		echo '<select name="status"><option value="">' . esc_html__( 'همه وضعیت‌ها', 'bespari-core' ) . '</option>';
		foreach ( array( 'pending' => __( 'در انتظار آماده‌سازی', 'bespari-core' ), 'prepared' => __( 'آماده ارسال', 'bespari-core' ), 'shipped' => __( 'ارسال‌شده', 'bespari-core' ), 'delivered' => __( 'تحویل‌شده', 'bespari-core' ), 'failed' => __( 'ناموفق', 'bespari-core' ), 'cancelled' => __( 'لغوشده', 'bespari-core' ) ) as $k => $label ) {
			echo '<option value="' . esc_attr( $k ) . '"' . selected( $status, $k, false ) . '>' . esc_html( $label ) . '</option>';
		}
		echo '</select>';
		echo '<input type="date" name="date_from" value="' . esc_attr( $date_from ) . '" />';
		echo '<input type="date" name="date_to" value="' . esc_attr( $date_to ) . '" />';
		echo '<button type="submit" class="button">' . esc_html__( 'فیلتر', 'bespari-core' ) . '</button> ';
		$clear = add_query_arg( array( 'page' => 'bespari-shipments' ), admin_url( 'admin.php' ) );
		echo '<a href="' . esc_url( $clear ) . '" class="button">' . esc_html__( 'پاک کردن', 'bespari-core' ) . '</a>';
		echo '</div></form>';
	}

	private function render_list(): void {
		$args = array(
			'page'      => isset( $_GET['paged'] ) ? max( 1, (int) $_GET['paged'] ) : 1, // phpcs:ignore
			'search'    => isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '', // phpcs:ignore
			'status'    => isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : '', // phpcs:ignore
			'date_from' => isset( $_GET['date_from'] ) ? sanitize_text_field( wp_unslash( $_GET['date_from'] ) ) : '', // phpcs:ignore
			'date_to'   => isset( $_GET['date_to'] ) ? sanitize_text_field( wp_unslash( $_GET['date_to'] ) ) : '', // phpcs:ignore
			'per_page'  => 20,
		);
		$service = new ShipmentService();
		$res     = $service->list( $args );
		$items   = $res['items'];
		$total   = $res['total'];
		$page    = max( 1, (int) ( $args['page'] ?? 1 ) );
		$pages   = max( 1, (int) ceil( $total / 20 ) );

		if ( empty( $items ) ) {
			echo '<div class="bespari-empty"><p>' . esc_html__( 'برگه‌ای یافت نشد.', 'bespari-core' ) . '</p></div>';
			return;
		}

		echo '<table class="bespari-table widefat striped"><thead><tr>';
		echo '<th>#</th>';
		echo '<th>' . esc_html__( 'سفارش', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'کد رهگیری', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'باربر', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'وضعیت', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'تاریخ ارسال', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'عملیات', 'bespari-core' ) . '</th>';
		echo '</tr></thead><tbody>';

		$badge_map = array( 'pending' => 'bespari-badge--warning', 'prepared' => 'bespari-badge--info', 'shipped' => 'bespari-badge--info', 'delivered' => 'bespari-badge--success', 'failed' => 'bespari-badge--danger', 'cancelled' => 'bespari-badge--muted' );

		foreach ( $items as $m ) {
			$cls   = $badge_map[ $m->status ] ?? 'bespari-badge--muted';
			$edit_url  = add_query_arg( array( 'page' => 'bespari-shipments', 'tab' => 'add', 'id' => $m->id ), admin_url( 'admin.php' ) );
			$view_url  = add_query_arg( array( 'page' => 'bespari-shipments', 'view' => $m->id ), admin_url( 'admin.php' ) );
			echo '<tr>';
			echo '<td>' . esc_html( $m->id ) . '</td>';
			echo '<td>' . esc_html( $m->order_number ?: (string) $m->order_id ) . '</td>';
			echo '<td><code>' . esc_html( $m->tracking_code ?: '—' ) . '</code></td>';
			echo '<td>' . esc_html( $m->carrier ?: '—' ) . '</td>';
			echo '<td><span class="bespari-badge ' . esc_attr( $cls ) . '">' . esc_html( $m->status_label() ) . '</span></td>';
			echo '<td><span class="bespari-muted">' . esc_html( $m->shipped_at ?: '—' ) . '</span></td>';
			echo '<td class="bespari-actions">';
			echo '<a href="' . esc_url( $view_url ) . '" class="button button-small">' . esc_html__( 'برگه', 'bespari-core' ) . '</a> ';
			if ( ! in_array( $m->status, array( 'delivered', 'cancelled' ), true ) ) {
				echo '<a href="' . esc_url( $edit_url ) . '" class="button button-small">' . esc_html__( 'ویرایش', 'bespari-core' ) . '</a> ';
			}
			if ( 'pending' === $m->status || 'prepared' === $m->status ) {
				echo '<a href="' . esc_url( $this->admin_action_url( 'update_shipment_status', array( 'id' => $m->id, 'status' => 'shipped' ) ) ) . '" class="button button-small button-primary">' . esc_html__( 'ارسال شد', 'bespari-core' ) . '</a> ';
			}
			if ( 'shipped' === $m->status ) {
				echo '<a href="' . esc_url( $this->admin_action_url( 'update_shipment_status', array( 'id' => $m->id, 'status' => 'delivered' ) ) ) . '" class="button button-small button-primary">' . esc_html__( 'تحویل شد', 'bespari-core' ) . '</a> ';
			}
			if ( in_array( $m->status, array( 'pending', 'prepared', 'shipped' ), true ) ) {
				echo '<a href="' . esc_url( $this->admin_action_url( 'update_shipment_status', array( 'id' => $m->id, 'status' => 'failed' ) ) ) . '" class="button button-small">' . esc_html__( 'ناموفق', 'bespari-core' ) . '</a> ';
			}
			if ( in_array( $m->status, array( 'pending', 'cancelled', 'failed' ), true ) ) {
				echo '<a href="' . esc_url( $this->admin_action_url( 'delete_shipment', array( 'id' => $m->id ) ) ) . '" class="button button-small button-link-delete bespari-confirm-delete" data-message="' . esc_attr__( 'حذف برگه ارسال؟', 'bespari-core' ) . '">' . esc_html__( 'حذف', 'bespari-core' ) . '</a>';
			}
			echo '</td></tr>';
		}
		echo '</tbody></table>';

		if ( $pages > 1 ) {
			echo '<div class="tablenav"><div class="tablenav-pages">';
			echo paginate_links( array( 'base' => add_query_arg( 'paged', '%#%' ), 'format' => '', 'prev_text' => __( '&laquo; قبلی', 'bespari-core' ), 'next_text' => __( 'بعدی &raquo;', 'bespari-core' ), 'total' => $pages, 'current' => $page ) );
			echo '</div></div>';
		}
		echo '<p class="description">' . sprintf( esc_html__( 'مجموع %d برگه', 'bespari-core' ), (int) $total ) . '</p>';
	}

	private function render_form( int $edit_id ): void {
		$service = new ShipmentService();
		$model   = $edit_id ? $service->get( $edit_id ) : null;
		$is_edit = null !== $model;

		// سفارش‌ها برای select (اخرین ۱۰۰ سفارش).
		$order_repo = new OrderRepository();
		$orders_res = $order_repo->paginate( array(), 1, 100 );

		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="bespari-form">';
		wp_nonce_field( 'bespari_save_shipment', 'bespari_nonce' );
		echo '<input type="hidden" name="action" value="bespari_save_shipment" />';
		if ( $is_edit ) {
			echo '<input type="hidden" name="shipment_id" value="' . esc_attr( $model->id ) . '" />';
		}
		echo '<table class="form-table">';

		if ( ! $is_edit ) {
			echo '<tr><th scope="row"><label>' . esc_html__( 'سفارش', 'bespari-core' ) . ' <span class="required">*</span></label></th><td>';
			echo '<select name="shipment[order_id]" required><option value="">' . esc_html__( '— انتخاب سفارش —', 'bespari-core' ) . '</option>';
			foreach ( $orders_res['items'] as $o ) {
				echo '<option value="' . esc_attr( $o->id ) . '">' . esc_html( $o->order_number . ' — ' . $o->customer_name ) . '</option>';
			}
			echo '</select></td></tr>';
		} else {
			echo '<tr><th scope="row"><label>' . esc_html__( 'سفارش', 'bespari-core' ) . '</label></th><td><strong>' . esc_html( $model->order_number ?: (string) $model->order_id ) . '</strong></td></tr>';
		}

		echo '<tr><th scope="row"><label>' . esc_html__( 'کد رهگیری', 'bespari-core' ) . '</label></th>';
		echo '<td><input type="text" name="shipment[tracking_code]" value="' . esc_attr( $model->tracking_code ?? '' ) . '" class="regular-text" dir="ltr" /></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'باربر / سرویس ارسال', 'bespari-core' ) . '</label></th>';
		echo '<td><input type="text" name="shipment[carrier]" value="' . esc_attr( $model->carrier ?? '' ) . '" class="regular-text" placeholder="' . esc_attr__( 'مثلاً: پست، تیپاکس، پیک موتوری', 'bespari-core' ) . '" /></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'یادداشت', 'bespari-core' ) . '</label></th>';
		echo '<td><textarea name="shipment[notes]" rows="3" class="large-text">' . esc_textarea( $model->notes ?? '' ) . '</textarea></td></tr>';

		echo '</table>';
		submit_button( $is_edit ? __( 'به‌روزرسانی', 'bespari-core' ) : __( 'ثبت برگه', 'bespari-core' ), 'primary', 'submit' );
		echo '</form>';
	}

	/**
	 * برگه چاپی ارسال با QR کد رهگیری.
	 */
	private function render_view( int $id ): void {
		$service = new ShipmentService();
		$m       = $service->get( $id );
		if ( ! $m ) {
			echo '<div class="bespari-notice bespari-notice--error"><span>' . esc_html__( 'برگه ارسال یافت نشد.', 'bespari-core' ) . '</span></div>';
			return;
		}

		$order_repo = new OrderRepository();
		$order      = $order_repo->get_full( $m->order_id );

		// برگه چاپی.
		echo '<div class="bespari-box bespari-box--white" id="bespari-shipment-sheet" style="max-width:640px;">';
		echo '<div style="display:flex;justify-content:space-between;align-items:flex-start;gap:16px;">';
		echo '<div>';
		echo '<h2 style="margin:0 0 4px;">' . esc_html__( 'برگه ارسال', 'bespari-core' ) . '</h2>';
		echo '<p class="description" style="margin:0;">' . esc_html__( 'بسپاری ERP', 'bespari-core' ) . '</p>';
		echo '</div>';
		echo '<div style="text-align:center;"><div id="bespari-shipment-qr" data-qr="' . esc_attr( $m->tracking_code ) . '"></div>';
		echo '<code style="display:block;margin-top:4px;">' . esc_html( $m->tracking_code ?: '—' ) . '</code></div>';
		echo '</div>';

		echo '<hr />';
		echo '<table class="form-table" style="margin-top:8px;">';
		echo '<tr><th>' . esc_html__( 'شماره سفارش', 'bespari-core' ) . '</th><td><strong>' . esc_html( $m->order_number ?: (string) $m->order_id ) . '</strong></td></tr>';
		echo '<tr><th>' . esc_html__( 'مشتری', 'bespari-core' ) . '</th><td>' . esc_html( $m->customer_name ) . ' — ' . esc_html( $m->customer_phone ) . '</td></tr>';
		echo '<tr><th>' . esc_html__( 'آدرس', 'bespari-core' ) . '</th><td>' . esc_html( $m->customer_address ?: '—' ) . '</td></tr>';
		echo '<tr><th>' . esc_html__( 'باربر', 'bespari-core' ) . '</th><td>' . esc_html( $m->carrier ?: '—' ) . '</td></tr>';
		echo '<tr><th>' . esc_html__( 'وضعیت', 'bespari-core' ) . '</th><td>' . esc_html( $m->status_label() ) . '</td></tr>';
		echo '</table>';

		if ( $order && ! empty( $order->items ) ) {
			echo '<h3>' . esc_html__( 'آیتم‌ها', 'bespari-core' ) . '</h3>';
			echo '<table class="bespari-table widefat striped"><thead><tr><th>' . esc_html__( 'محصول', 'bespari-core' ) . '</th><th>' . esc_html__( 'SKU', 'bespari-core' ) . '</th><th>' . esc_html__( 'تعداد', 'bespari-core' ) . '</th></tr></thead><tbody>';
			foreach ( $order->items as $it ) {
				echo '<tr><td>' . esc_html( $it->product_name ) . '</td><td>' . esc_html( $it->sku ?: '—' ) . '</td><td>' . esc_html( (string) $it->quantity ) . '</td></tr>';
			}
			echo '</tbody></table>';
		}

		if ( $m->notes ) {
			echo '<p><strong>' . esc_html__( 'یادداشت:', 'bespari-core' ) . '</strong> ' . esc_html( $m->notes ) . '</p>';
		}
		echo '</div>';

		echo '<p style="margin-top:12px;">';
		echo '<a href="' . esc_url( add_query_arg( array( 'page' => 'bespari-shipments' ), admin_url( 'admin.php' ) ) ) . '" class="button">' . esc_html__( 'بازگشت', 'bespari-core' ) . '</a> ';
		echo '<button type="button" class="button button-primary" onclick="window.print();">' . esc_html__( 'چاپ برگه', 'bespari-core' ) . '</button>';
		echo '</p>';

		// اسکریپت QR سمت کلاینت.
		?>
		<script>
		( function() {
			var el = document.getElementById( 'bespari-shipment-qr' );
			if ( ! el ) { return; }
			var text = el.getAttribute( 'data-qr' ) || '';
			if ( ! text || typeof window.QRCode === 'undefined' ) {
				el.textContent = text || '—';
				return;
			}
			try {
				el.innerHTML = '';
				new window.QRCode( el, { text: text, width: 128, height: 128, correctLevel: window.QRCode.CorrectLevel.M } );
			} catch ( e ) {
				el.textContent = text;
			}
		} )();
		</script>
		<?php
	}
}
