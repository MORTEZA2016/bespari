<?php
/**
 * صفحه پرداخت‌ها (درخواست‌های برداشت).
 *
 * @package Bespari\Admin\Pages
 */

namespace Bespari\Admin\Pages;

use Bespari\Modules\Payout\PayoutService;
use Bespari\Modules\Seller\SellerRepository;
use Bespari\Modules\Commission\CommissionRepository;
use Bespari\Support\Helpers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class PayoutPage extends BasePage {

	protected string $slug = 'bespari-payouts';
	protected string $cap  = 'bespari_manage_commission';

	public function render(): void {
		if ( ! $this->can_access() ) {
			wp_die( esc_html__( 'شما دسترسی لازم را ندارید.', 'bespari-core' ) );
		}

		$tab = $this->current_tab( 'list' );

		echo '<div class="wrap bespari-wrap">';
		$this->page_header( __( 'پرداخت‌ها', 'bespari-core' ), __( 'درخواست برداشت بازاریاب‌ها — تایید، رد و پرداخت با FIFO روی پورسانت‌های تاییدشده.', 'bespari-core' ) );
		$this->render_notice();
		$this->render_tabs( $tab, array(
			'list' => __( 'لیست پرداخت‌ها', 'bespari-core' ),
			'add'  => __( 'ثبت پرداخت', 'bespari-core' ),
		) );

		if ( 'add' === $tab ) {
			$this->render_form();
		} else {
			$this->render_filters();
			$this->render_list();
		}

		echo '</div>';
	}

	private function render_filters(): void {
		$seller_id = isset( $_GET['seller_id'] ) ? (int) $_GET['seller_id'] : 0; // phpcs:ignore
		$status    = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : ''; // phpcs:ignore
		$sellers   = ( new SellerRepository() )->all();

		echo '<form method="get" class="bespari-filters">';
		echo '<input type="hidden" name="page" value="bespari-payouts" />';
		echo '<div class="bespari-filters__row">';
		echo '<select name="seller_id"><option value="0">' . esc_html__( 'همه بازاریاب‌ها', 'bespari-core' ) . '</option>';
		foreach ( $sellers as $u ) {
			echo '<option value="' . esc_attr( $u->id ) . '"' . selected( $seller_id, $u->id, false ) . '>' . esc_html( $u->display_name ) . '</option>';
		}
		echo '</select>';
		echo '<select name="status"><option value="">' . esc_html__( 'همه وضعیت‌ها', 'bespari-core' ) . '</option>';
		foreach ( array( 'pending' => __( 'در انتظار', 'bespari-core' ), 'approved' => __( 'تاییدشده', 'bespari-core' ), 'paid' => __( 'پرداخت‌شده', 'bespari-core' ), 'rejected' => __( 'ردشده', 'bespari-core' ) ) as $k => $label ) {
			echo '<option value="' . esc_attr( $k ) . '"' . selected( $status, $k, false ) . '>' . esc_html( $label ) . '</option>';
		}
		echo '</select>';
		echo '<button type="submit" class="button">' . esc_html__( 'فیلتر', 'bespari-core' ) . '</button> ';
		$clear = add_query_arg( array( 'page' => 'bespari-payouts' ), admin_url( 'admin.php' ) );
		echo '<a href="' . esc_url( $clear ) . '" class="button">' . esc_html__( 'پاک کردن', 'bespari-core' ) . '</a>';
		echo '</div></form>';
	}

	private function render_list(): void {
		$args = array(
			'page'      => isset( $_GET['paged'] ) ? (int) $_GET['paged'] : 1, // phpcs:ignore
			'seller_id' => isset( $_GET['seller_id'] ) ? (int) $_GET['seller_id'] : 0, // phpcs:ignore
			'status'    => isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : '', // phpcs:ignore
			'per_page'  => 20,
		);
		$service = new PayoutService();
		$res     = $service->list( $args );
		$items   = $res['items'];
		$total   = $res['total'];
		$page    = max( 1, (int) ( $args['page'] ?? 1 ) );
		$pages   = max( 1, (int) ceil( $total / 20 ) );

		if ( empty( $items ) ) {
			echo '<div class="bespari-empty"><p>' . esc_html__( 'درخواستی یافت نشد.', 'bespari-core' ) . '</p></div>';
			return;
		}

		echo '<table class="bespari-table widefat striped"><thead><tr>';
		echo '<th>#</th>';
		echo '<th>' . esc_html__( 'بازاریاب', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'مبلغ', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'روش', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'وضعیت', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'تاریخ درخواست', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'یادداشت', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'عملیات', 'bespari-core' ) . '</th>';
		echo '</tr></thead><tbody>';

		foreach ( $items as $m ) {
			$map = array( 'pending' => 'bespari-badge--warning', 'approved' => 'bespari-badge--info', 'paid' => 'bespari-badge--success', 'rejected' => 'bespari-badge--danger' );
			$cls = $map[ $m->status ] ?? 'bespari-badge--muted';
			echo '<tr>';
			echo '<td>' . esc_html( $m->id ) . '</td>';
			echo '<td>' . esc_html( $m->seller_name ?: (string) $m->seller_id ) . '</td>';
			echo '<td><strong>' . esc_html( Helpers::format_money( $m->amount ) ) . '</strong></td>';
			echo '<td>' . esc_html( $m->method ) . '</td>';
			echo '<td><span class="bespari-badge ' . esc_attr( $cls ) . '">' . esc_html( $m->status_label() ) . '</span></td>';
			echo '<td><span class="bespari-muted">' . esc_html( $m->requested_at ) . '</span></td>';
			echo '<td><span class="bespari-muted">' . esc_html( $m->notes ? mb_strimwidth( $m->notes, 0, 60, '…' ) : '—' ) . '</span></td>';
			echo '<td class="bespari-actions">';
			if ( 'pending' === $m->status ) {
				echo '<a href="' . esc_url( $this->admin_action_url( 'approve_payout', array( 'id' => $m->id ) ) ) . '" class="button button-small button-primary">' . esc_html__( 'تایید', 'bespari-core' ) . '</a> ';
				echo '<a href="' . esc_url( $this->admin_action_url( 'reject_payout', array( 'id' => $m->id ) ) ) . '" class="button button-small">' . esc_html__( 'رد', 'bespari-core' ) . '</a>';
			} elseif ( 'approved' === $m->status ) {
				echo '<a href="' . esc_url( $this->admin_action_url( 'mark_payout_paid', array( 'id' => $m->id ) ) ) . '" class="button button-small button-primary">' . esc_html__( 'پرداخت شد', 'bespari-core' ) . '</a> ';
				echo '<a href="' . esc_url( $this->admin_action_url( 'reject_payout', array( 'id' => $m->id ) ) ) . '" class="button button-small">' . esc_html__( 'رد', 'bespari-core' ) . '</a>';
			} else {
				echo '<span class="bespari-muted">—</span>';
			}
			echo '</td></tr>';

			// ردیف نمایش کمیسیون‌های مرتبط اگر پرداخت شده.
			if ( 'paid' === $m->status ) {
				$comms = ( new CommissionRepository() )->get_by_payout( $m->id );
				if ( ! empty( $comms ) ) {
					echo '<tr><td colspan="8" class="bespari-subrow"><span class="bespari-muted">' . esc_html__( 'کمیسیون‌های پرداخت‌شده:', 'bespari-core' ) . ' </span>';
					$parts = array();
					foreach ( $comms as $c ) {
						$parts[] = '#' . $c->id . ' (' . Helpers::format_money( $c->amount ) . ')';
					}
					echo esc_html( implode( '، ', $parts ) ) . '</td></tr>';
				}
			}
		}
		echo '</tbody></table>';
		if ( $pages > 1 ) {
			echo '<div class="tablenav"><div class="tablenav-pages">';
			echo paginate_links( array( 'base' => add_query_arg( 'paged', '%#%' ), 'format' => '', 'prev_text' => __( '&laquo; قبلی', 'bespari-core' ), 'next_text' => __( 'بعدی &raquo;', 'bespari-core' ), 'total' => $pages, 'current' => $page ) );
			echo '</div></div>';
		}
		echo '<p class="description">' . sprintf( esc_html__( 'مجموع %d درخواست', 'bespari-core' ), (int) $total ) . '</p>';
	}

	private function render_form(): void {
		$sellers = ( new SellerRepository() )->all();
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="bespari-form">';
		wp_nonce_field( 'bespari_save_payout', 'bespari_nonce' );
		echo '<input type="hidden" name="action" value="bespari_save_payout" />';
		echo '<table class="form-table">';
		echo '<tr><th scope="row"><label>' . esc_html__( 'بازاریاب', 'bespari-core' ) . ' <span class="required">*</span></label></th><td><select name="payout[seller_id]" required><option value="">' . esc_html__( '— انتخاب کنید —', 'bespari-core' ) . '</option>';
		foreach ( $sellers as $u ) {
			echo '<option value="' . esc_attr( $u->id ) . '">' . esc_html( $u->display_name ) . ' (' . esc_html( $u->user_login ) . ')</option>';
		}
		echo '</select></td></tr>';
		echo '<tr><th scope="row"><label>' . esc_html__( 'مبلغ', 'bespari-core' ) . ' <span class="required">*</span></label></th>';
		echo '<td><input type="number" name="payout[amount]" min="0" step="0.01" class="regular-text" required /></td></tr>';
		echo '<tr><th scope="row"><label>' . esc_html__( 'روش', 'bespari-core' ) . '</label></th><td><select name="payout[method]">';
		foreach ( array( 'manual' => __( 'دستی', 'bespari-core' ), 'bank' => __( 'بانکی', 'bespari-core' ) ) as $k => $label ) {
			echo '<option value="' . esc_attr( $k ) . '">' . esc_html( $label ) . '</option>';
		}
		echo '</select></td></tr>';
		echo '<tr><th scope="row"><label>' . esc_html__( 'یادداشت', 'bespari-core' ) . '</label></th>';
		echo '<td><textarea name="payout[notes]" rows="3" class="large-text"></textarea></td></tr>';
		echo '</table>';
		submit_button( __( 'ثبت درخواست', 'bespari-core' ), 'primary', 'submit' );
		echo '</form>';
	}
}
