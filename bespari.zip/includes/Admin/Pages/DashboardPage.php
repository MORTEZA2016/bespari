<?php
/**
 * صفحه داشبورد.
 *
 * @package Bespari\Admin\Pages
 */

namespace Bespari\Admin\Pages;

// جلوگیری از دسترسی مستقیم.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DashboardPage extends BasePage {

	protected string $cap = 'bespari_read_dashboard';

	public function render(): void {
		if ( ! $this->can_access() ) {
			wp_die( esc_html__( 'شما دسترسی لازم را ندارید.', 'bespari-core' ) );
		}

		$this->render_stats();
	}

	/**
	 * کارت‌های آماری.
	 */
	private function render_stats(): void {
		global $wpdb;

		$counts = array(
			'channels'    => (int) $wpdb->get_var( "SELECT COUNT(*) FROM " . \Bespari\Support\Helpers::table( 'channels' ) ), // phpcs:ignore
			'brands'      => (int) $wpdb->get_var( "SELECT COUNT(*) FROM " . \Bespari\Support\Helpers::table( 'brands' ) ), // phpcs:ignore
			'products'    => (int) $wpdb->get_var( "SELECT COUNT(*) FROM " . \Bespari\Support\Helpers::table( 'products' ) ), // phpcs:ignore
			'rules'       => (int) $wpdb->get_var( "SELECT COUNT(*) FROM " . \Bespari\Support\Helpers::table( 'pricing_rules' ) ), // phpcs:ignore
			'orders'      => (int) $wpdb->get_var( "SELECT COUNT(*) FROM " . \Bespari\Support\Helpers::table( 'orders' ) ), // phpcs:ignore
			'settlements' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM " . \Bespari\Support\Helpers::table( 'settlements' ) ), // phpcs:ignore
			'commissions' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM " . \Bespari\Support\Helpers::table( 'commissions' ) ), // phpcs:ignore
			'payouts'     => (int) $wpdb->get_var( "SELECT COUNT(*) FROM " . \Bespari\Support\Helpers::table( 'payouts' ) ), // phpcs:ignore
		);
		// تعداد بازاریاب‌ها via WP_User_Query count (سبک).
		$counts['sellers'] = count( ( new \Bespari\Modules\Seller\SellerRepository() )->all() );
		// کم‌موجودی (فاز ۴).
		$counts['low_stock'] = ( new \Bespari\Modules\Warehouse\StockService() )->count_low_stock();

		?>
		<div class="wrap bespari-wrap bespari-dashboard">
			<div class="bespari-header">
				<h1 class="bespari-header__title">
					<span class="dashicons dashicons-dashboard"></span>
					<?php esc_html_e( 'داشبورد بسپاری ERP', 'bespari-core' ); ?>
				</h1>
				<p class="bespari-header__subtitle"><?php esc_html_e( 'خلاصه وضعیت سیستم — فاز ۶ (اتصال‌های اقماری آماده)', 'bespari-core' ); ?></p>
			</div>

			<?php $this->render_notice(); ?>

			<div class="bespari-stats-grid">
				<div class="bespari-card">
					<div class="bespari-avatar bespari-avatar--primary"><span class="dashicons dashicons-store"></span></div>
					<div class="bespari-card__body">
						<span class="bespari-card__value"><?php echo esc_html( $counts['channels'] ); ?></span>
						<span class="bespari-card__label"><?php esc_html_e( 'کانال‌های فروش', 'bespari-core' ); ?></span>
					</div>
				</div>

				<div class="bespari-card">
					<div class="bespari-avatar bespari-avatar--info"><span class="dashicons dashicons-awards"></span></div>
					<div class="bespari-card__body">
						<span class="bespari-card__value"><?php echo esc_html( $counts['brands'] ); ?></span>
						<span class="bespari-card__label"><?php esc_html_e( 'برندها', 'bespari-core' ); ?></span>
					</div>
				</div>

				<div class="bespari-card">
					<div class="bespari-avatar bespari-avatar--success"><span class="dashicons dashicons-products"></span></div>
					<div class="bespari-card__body">
						<span class="bespari-card__value"><?php echo esc_html( $counts['products'] ); ?></span>
						<span class="bespari-card__label"><?php esc_html_e( 'محصولات', 'bespari-core' ); ?></span>
					</div>
				</div>

				<div class="bespari-card">
					<div class="bespari-avatar bespari-avatar--warning"><span class="dashicons dashicons-calculator"></span></div>
					<div class="bespari-card__body">
						<span class="bespari-card__value"><?php echo esc_html( $counts['rules'] ); ?></span>
						<span class="bespari-card__label"><?php esc_html_e( 'قوانین قیمت‌گذاری', 'bespari-core' ); ?></span>
					</div>
				</div>

				<div class="bespari-card">
					<div class="bespari-avatar bespari-avatar--primary"><span class="dashicons dashicons-cart"></span></div>
					<div class="bespari-card__body">
						<span class="bespari-card__value"><?php echo esc_html( $counts['orders'] ); ?></span>
						<span class="bespari-card__label"><?php esc_html_e( 'سفارشات', 'bespari-core' ); ?></span>
					</div>
				</div>

				<div class="bespari-card">
					<div class="bespari-avatar bespari-avatar--success"><span class="dashicons dashicons-money-alt"></span></div>
					<div class="bespari-card__body">
						<span class="bespari-card__value"><?php echo esc_html( $counts['settlements'] ); ?></span>
						<span class="bespari-card__label"><?php esc_html_e( 'تسویه‌ها', 'bespari-core' ); ?></span>
					</div>
				</div>

				<div class="bespari-card">
					<div class="bespari-avatar bespari-avatar--primary"><span class="dashicons dashicons-groups"></span></div>
					<div class="bespari-card__body">
						<span class="bespari-card__value"><?php echo esc_html( $counts['sellers'] ); ?></span>
						<span class="bespari-card__label"><?php esc_html_e( 'بازاریاب‌ها', 'bespari-core' ); ?></span>
					</div>
				</div>

				<div class="bespari-card">
					<div class="bespari-avatar bespari-avatar--info"><span class="dashicons dashicons-tickets-alt"></span></div>
					<div class="bespari-card__body">
						<span class="bespari-card__value"><?php echo esc_html( $counts['commissions'] ); ?></span>
						<span class="bespari-card__label"><?php esc_html_e( 'پورسانت‌ها', 'bespari-core' ); ?></span>
					</div>
				</div>

				<div class="bespari-card">
					<div class="bespari-avatar bespari-avatar--warning"><span class="dashicons dashicons-bank"></span></div>
					<div class="bespari-card__body">
						<span class="bespari-card__value"><?php echo esc_html( $counts['payouts'] ); ?></span>
						<span class="bespari-card__label"><?php esc_html_e( 'پرداخت‌ها', 'bespari-core' ); ?></span>
					</div>
				</div>

				<div class="bespari-card">
					<div class="bespari-avatar bespari-avatar--danger"><span class="dashicons dashicons-warning"></span></div>
					<div class="bespari-card__body">
						<span class="bespari-card__value"><?php echo esc_html( $counts['low_stock'] ); ?></span>
						<span class="bespari-card__label"><?php esc_html_e( 'کم‌موجودی', 'bespari-core' ); ?></span>
					</div>
				</div>

				<?php
				// فروش ماه جاری (فاز ۵).
				$kpi_row = $wpdb->get_row( $wpdb->prepare(
					'SELECT COALESCE(SUM(total_net), 0) AS net FROM ' . \Bespari\Support\Helpers::table( 'orders' ) . " WHERE status != 'cancelled' AND ordered_at >= %s AND ordered_at <= %s", // phpcs:ignore
					gmdate( 'Y-m-01' ) . ' 00:00:00',
					\Bespari\Support\Helpers::now()
				) );
				?>
				<div class="bespari-card">
					<div class="bespari-avatar bespari-avatar--info"><span class="dashicons dashicons-chart-line"></span></div>
					<div class="bespari-card__body">
						<span class="bespari-card__value"><?php echo esc_html( \Bespari\Support\Helpers::format_money( (float) ( $kpi_row->net ?? 0 ) ) ); ?></span>
						<span class="bespari-card__label"><?php esc_html_e( 'فروش ماه جاری', 'bespari-core' ); ?></span>
					</div>
				</div>
			</div>

			<div class="bespari-row">
				<div class="bespari-col bespari-col--8">
					<div class="bespari-box bespari-box--white">
						<h3 class="bespari-box__title"><?php esc_html_e( 'وضعیت فازها', 'bespari-core' ); ?></h3>
						<table class="bespari-phase-table">
							<thead>
								<tr><th><?php esc_html_e( 'بخش', 'bespari-core' ); ?></th><th><?php esc_html_e( 'وضعیت', 'bespari-core' ); ?></th></tr>
							</thead>
							<tbody>
								<tr><td><?php esc_html_e( 'هسته، دیتابیس و نقش‌ها', 'bespari-core' ); ?></td><td><span class="bespari-badge bespari-badge--success"><?php esc_html_e( 'آماده', 'bespari-core' ); ?></span></td></tr>
								<tr><td><?php esc_html_e( 'کانال‌های فروش', 'bespari-core' ); ?></td><td><span class="bespari-badge bespari-badge--success"><?php esc_html_e( 'آماده', 'bespari-core' ); ?></span></td></tr>
								<tr><td><?php esc_html_e( 'برندهای فروش', 'bespari-core' ); ?></td><td><span class="bespari-badge bespari-badge--success"><?php esc_html_e( 'آماده', 'bespari-core' ); ?></span></td></tr>
								<tr><td><?php esc_html_e( 'محصولات + نگاشت کانال + ووکامرس', 'bespari-core' ); ?></td><td><span class="bespari-badge bespari-badge--success"><?php esc_html_e( 'آماده', 'bespari-core' ); ?></span></td></tr>
								<tr><td><?php esc_html_e( 'قوانین قیمت‌گذاری + PricingEngine', 'bespari-core' ); ?></td><td><span class="bespari-badge bespari-badge--success"><?php esc_html_e( 'آماده', 'bespari-core' ); ?></span></td></tr>
								<tr><td><?php esc_html_e( 'لاگ تغییرات (Audit Log)', 'bespari-core' ); ?></td><td><span class="bespari-badge bespari-badge--success"><?php esc_html_e( 'آماده', 'bespari-core' ); ?></span></td></tr>
								<tr><td><?php esc_html_e( 'سفارشات، تسویه و موتور مالی', 'bespari-core' ); ?></td><td><span class="bespari-badge bespari-badge--success"><?php esc_html_e( 'آماده', 'bespari-core' ); ?></span></td></tr>
								<tr><td><?php esc_html_e( 'بازاریاب‌ها، پورسانت و پرداخت', 'bespari-core' ); ?></td><td><span class="bespari-badge bespari-badge--success"><?php esc_html_e( 'آماده', 'bespari-core' ); ?></span></td></tr>
								<tr><td><?php esc_html_e( 'انبار، ارسال، مرجوعی و درخواست‌ها', 'bespari-core' ); ?></td><td><span class="bespari-badge bespari-badge--success"><?php esc_html_e( 'آماده', 'bespari-core' ); ?></span></td></tr>
								<tr><td><?php esc_html_e( 'حسابداری، صورتحساب و گزارشات', 'bespari-core' ); ?></td><td><span class="bespari-badge bespari-badge--success"><?php esc_html_e( 'آماده', 'bespari-core' ); ?></span></td></tr>
								<tr><td><?php esc_html_e( 'اتصال‌های اقماری (Agent Connector)', 'bespari-core' ); ?></td><td><span class="bespari-badge bespari-badge--success"><?php esc_html_e( 'آماده', 'bespari-core' ); ?></span></td></tr>
							</tbody>
						</table>
					</div>
				</div>

				<div class="bespari-col bespari-col--4">
					<div class="bespari-box bespari-box--accent">
						<h3 class="bespari-box__title"><?php esc_html_e( 'میانبرها', 'bespari-core' ); ?></h3>
						<ul class="bespari-shortcuts">
							<?php foreach ( $this->shortcuts() as $s ) : ?>
								<li><a href="<?php echo esc_url( $s['url'] ); ?>" class="bespari-shortcut-link"><span class="dashicons <?php echo esc_attr( $s['icon'] ); ?>"></span> <?php echo esc_html( $s['label'] ); ?></a></li>
							<?php endforeach; ?>
						</ul>
					</div>

					<div class="bespari-box" style="margin-top: 16px;">
						<h3 class="bespari-box__title"><?php esc_html_e( 'پیشرفت پروژه', 'bespari-core' ); ?></h3>
						<div class="bespari-progress">
							<div class="bespari-progress__bar" style="width: 93%;"></div>
						</div>
						<p class="bespari-progress__label"><?php esc_html_e( '۶ از ۸ فاز — اتصال‌های اقماری آماده', 'bespari-core' ); ?></p>
					</div>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * میانبرها.
	 *
	 * @return array
	 */
	private function shortcuts(): array {
		$shortcuts = array();

		if ( current_user_can( 'bespari_manage_orders' ) || current_user_can( 'bespari_seller_view' ) ) {
			$shortcuts[] = array(
				'label' => __( 'ثبت سفارش جدید (POS)', 'bespari-core' ),
				'url'   => admin_url( 'admin-post.php?action=bespari_pos' ),
				'icon'  => 'dashicons-cart',
			);
		}

		$shortcuts[] = array(
			'label' => __( 'افزودن کانال جدید', 'bespari-core' ),
			'url'   => add_query_arg( array( 'page' => 'bespari-channels', 'tab' => 'add' ), admin_url( 'admin.php' ) ),
			'icon'  => 'dashicons-plus-alt',
		);
		$shortcuts[] = array(
			'label' => __( 'افزودن برند جدید', 'bespari-core' ),
			'url'   => add_query_arg( array( 'page' => 'bespari-brands', 'tab' => 'add' ), admin_url( 'admin.php' ) ),
			'icon'  => 'dashicons-awards',
		);
		$shortcuts[] = array(
			'label' => __( 'افزودن محصول جدید', 'bespari-core' ),
			'url'   => add_query_arg( array( 'page' => 'bespari-products', 'tab' => 'add' ), admin_url( 'admin.php' ) ),
			'icon'  => 'dashicons-cart',
		);
		$shortcuts[] = array(
			'label' => __( 'افزودن قانون قیمت', 'bespari-core' ),
			'url'   => add_query_arg( array( 'page' => 'bespari-pricing', 'tab' => 'add' ), admin_url( 'admin.php' ) ),
			'icon'  => 'dashicons-calculator',
		);

		return $shortcuts;
	}
}
