<?php
/**
 * صفحه محصولات.
 *
 * @package Bespari\Admin\Pages
 */

namespace Bespari\Admin\Pages;

use Bespari\Modules\Product\ProductService;
use Bespari\Modules\Brand\BrandService;
use Bespari\Modules\Channel\ChannelService;
use Bespari\Support\Helpers;

// جلوگیری از دسترسی مستقیم.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ProductPage extends BasePage {

	protected string $slug = 'bespari-products';
	protected string $cap  = 'bespari_manage_products';

	public function render(): void {
		if ( ! $this->can_access() ) {
			wp_die( esc_html__( 'شما دسترسی لازم را ندارید.', 'bespari-core' ) );
		}

		$tab     = $this->current_tab( 'list' );
		$edit_id = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0; // phpcs:ignore
		if ( $edit_id && 'list' === $tab ) {
			$tab = 'edit';
		}

		echo '<div class="wrap bespari-wrap">';
		$this->page_header( __( 'محصولات', 'bespari-core' ), __( 'ثبت محصولات، قیمت پایه و نگاشت کانال‌ها. سینک اختیاری با ووکامرس.', 'bespari-core' ) );
		$this->render_notice();
		$this->render_tabs( $tab, array(
			'list' => __( 'لیست محصولات', 'bespari-core' ),
			'add'  => __( 'افزودن محصول', 'bespari-core' ),
		) );

		// دکمه سینک ووکامرس فقط در لیست.
		if ( 'list' === $tab ) {
			$this->render_wc_sync_button();
		}

		if ( 'add' === $tab ) {
			$this->render_form( null );
		} elseif ( 'edit' === $tab && $edit_id ) {
			$service = new ProductService();
			$product = $service->get( $edit_id );
			if ( ! $product ) {
				echo '<div class="bespari-notice bespari-notice--error"><span>' . esc_html__( 'محصول یافت نشد.', 'bespari-core' ) . '</span></div>';
			} else {
				$this->render_form( $product );
			}
		} else {
			$this->render_list();
		}

		echo '</div>';
	}

	private function render_wc_sync_button(): void {
		if ( ! Helpers::woocommerce_is_active() ) {
			echo '<div class="bespari-empty"><p>' . esc_html__( 'ووکامرس فعال نیست. سینک اختیاری است و بدون آن افزونه به‌صورت مستقل کار می‌کند.', 'bespari-core' ) . '</p></div>';
			return;
		}

		$sync_url = wp_nonce_url(
			add_query_arg( array( 'action' => 'bespari_sync_wc_products' ), admin_url( 'admin-post.php' ) ),
			'bespari_sync_wc',
			'bespari_nonce'
		);

		echo '<p class="bespari-toolbar"><a href="' . esc_url( $sync_url ) . '" class="button button-secondary">' . esc_html__( 'سینک محصولات از ووکامرس', 'bespari-core' ) . '</a></p>';
	}

	private function render_list(): void {
		$search   = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : ''; // phpcs:ignore
		$brand_id = isset( $_GET['brand_id'] ) ? (int) $_GET['brand_id'] : 0; // phpcs:ignore
		$page     = isset( $_GET['paged'] ) ? max( 1, (int) $_GET['paged'] ) : 1; // phpcs:ignore
		$per_page = 20;

		$service = new ProductService();
		$result  = $service->list( array(
			'search'   => $search,
			'brand_id' => $brand_id,
			'per_page' => $per_page,
			'page'     => $page,
		) );

		// فرم فیلتر.
		echo '<form method="get" class="bespari-filters">';
		echo '<input type="hidden" name="page" value="bespari-products" />';
		echo '<input type="search" name="s" value="' . esc_attr( $search ) . '" placeholder="' . esc_attr__( 'جستجو (نام/SKU/کد)', 'bespari-core' ) . '" />';
		echo '<select name="brand_id"><option value="0">' . esc_html__( 'همه برندها', 'bespari-core' ) . '</option>';
		foreach ( ( new BrandService() )->list( true ) as $b ) {
			echo '<option value="' . esc_attr( $b->id ) . '"' . selected( $brand_id, $b->id, false ) . '>' . esc_html( $b->name ) . '</option>';
		}
		echo '</select>';
		echo '<button type="submit" class="button">' . esc_html__( 'فیلتر', 'bespari-core' ) . '</button>';
		echo '</form>';

		if ( empty( $result['items'] ) ) {
			echo '<div class="bespari-empty"><p>' . esc_html__( 'محصولی یافت نشد.', 'bespari-core' ) . '</p></div>';
			return;
		}

		echo '<table class="bespari-table widefat striped">';
		echo '<thead><tr>';
		echo '<th>' . esc_html__( 'نام', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'SKU', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'برند', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'قیمت پایه', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'موجودی', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'وضعیت', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'عملیات', 'bespari-core' ) . '</th>';
		echo '</tr></thead><tbody>';

		foreach ( $result['items'] as $p ) {
			$edit_url   = add_query_arg( array( 'page' => 'bespari-products', 'id' => $p->id ), admin_url( 'admin.php' ) );
			$delete_url = $this->admin_action_url( 'delete_product', array( 'id' => $p->id ) );
			$badge_cls  = 1 === $p->status ? 'bespari-badge--success' : 'bespari-badge--muted';

			echo '<tr>';
			echo '<td><strong>' . esc_html( $p->name ) . '</strong>' . ( $p->wc_product_id ? ' <span class="bespari-badge bespari-badge--info">WC#' . esc_html( $p->wc_product_id ) . '</span>' : '' ) . '</td>';
			echo '<td><code>' . esc_html( $p->sku ) . '</code></td>';
			echo '<td>' . esc_html( $p->brand_name ?: '—' ) . '</td>';
			echo '<td>' . esc_html( Helpers::format_money( $p->base_price ) ) . '</td>';
			echo '<td>' . esc_html( $p->stock ) . '</td>';
			echo '<td><span class="bespari-badge ' . esc_attr( $badge_cls ) . '">' . esc_html( $p->status_label() ) . '</span></td>';
			echo '<td class="bespari-actions">';
			echo '<a href="' . esc_url( $edit_url ) . '" class="button button-small">' . esc_html__( 'ویرایش', 'bespari-core' ) . '</a> ';
			echo '<a href="' . esc_url( $delete_url ) . '" class="button button-small button-link-delete bespari-confirm-delete" data-message="' . esc_attr__( 'آیا از حذف این محصول اطمینان دارید؟', 'bespari-core' ) . '">' . esc_html__( 'حذف', 'bespari-core' ) . '</a>';
			echo '</td>';
			echo '</tr>';
		}

		echo '</tbody></table>';
		$this->render_pagination( $result['total'], $page, $per_page );
	}

	private function render_pagination( int $total, int $page, int $per_page ): void {
		$pages = (int) ceil( $total / $per_page );
		if ( $pages < 2 ) {
			return;
		}

		echo '<div class="tablenav"><div class="tablenav-pages">';
		echo '<span class="displaying-num">' . esc_html( number_format_i18n( $total ) ) . ' ' . esc_html__( 'مورد', 'bespari-core' ) . '</span>';

		if ( $page > 1 ) {
			echo '<a class="prev-page button" href="' . esc_url( add_query_arg( array( 'page' => 'bespari-products', 'paged' => $page - 1 ), admin_url( 'admin.php' ) ) ) . '">&rsaquo;</a> ';
		}
		echo '<span class="paging-input">' . esc_html( $page ) . ' / ' . esc_html( $pages ) . '</span>';
		if ( $page < $pages ) {
			echo ' <a class="next-page button" href="' . esc_url( add_query_arg( array( 'page' => 'bespari-products', 'paged' => $page + 1 ), admin_url( 'admin.php' ) ) ) . '">&rsaquo;</a>';
		}
		echo '</div></div>';
	}

	/**
	 * @param \Bespari\Modules\Product\ProductModel|null $product
	 */
	private function render_form( $product ): void {
		$is_edit = null !== $product;
		$action  = admin_url( 'admin-post.php' );

		$val = function( string $key, $default = '' ) use ( $product ) {
			if ( ! $product ) {
				return $default;
			}
			return $product->$key ?? $default;
		};

		$brands   = ( new BrandService() )->list( true );
		$channels = ( new ChannelService() )->list( true );

		// نگاشت‌های فعلی کانال‌ها بر اساس channel_id.
		$mapped = array();
		if ( $product ) {
			foreach ( $product->channels as $m ) {
				$mapped[ (int) $m->channel_id ] = (array) $m;
			}
		}

		echo '<form method="post" action="' . esc_url( $action ) . '" class="bespari-form">';
		wp_nonce_field( 'bespari_save_product', 'bespari_nonce' );
		echo '<input type="hidden" name="action" value="bespari_save_product" />';
		if ( $is_edit ) {
			echo '<input type="hidden" name="product_id" value="' . esc_attr( $product->id ) . '" />';
		}

		echo '<table class="form-table">';

		echo '<tr><th scope="row"><label>' . esc_html__( 'نام محصول', 'bespari-core' ) . ' <span class="required">*</span></label></th>';
		echo '<td><input type="text" name="product[name]" value="' . esc_attr( $val( 'name' ) ) . '" class="regular-text" required /></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'SKU', 'bespari-core' ) . '</label></th>';
		echo '<td><input type="text" name="product[sku]" value="' . esc_attr( $val( 'sku' ) ) . '" class="regular-text" /></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'کد محصول', 'bespari-core' ) . '</label></th>';
		echo '<td><input type="text" name="product[product_code]" value="' . esc_attr( $val( 'product_code' ) ) . '" class="regular-text" /></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'برند', 'bespari-core' ) . '</label></th><td><select name="product[brand_id]">';
		echo '<option value="0">' . esc_html__( '— انتخاب کنید —', 'bespari-core' ) . '</option>';
		foreach ( $brands as $b ) {
			echo '<option value="' . esc_attr( $b->id ) . '"' . selected( (int) $val( 'brand_id', 0 ), $b->id, false ) . '>' . esc_html( $b->name ) . '</option>';
		}
		echo '</select></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'آی‌دی محصول ووکامرس', 'bespari-core' ) . '</label></th>';
		echo '<td><input type="number" name="product[wc_product_id]" value="' . esc_attr( (int) $val( 'wc_product_id', 0 ) ) . '" class="small-text" /></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'قیمت پایه', 'bespari-core' ) . '</label></th>';
		echo '<td><input type="number" step="0.01" name="product[base_price]" value="' . esc_attr( (float) $val( 'base_price', 0 ) ) . '" class="small-text" /></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'قیمت خرید', 'bespari-core' ) . '</label></th>';
		echo '<td><input type="number" step="0.01" name="product[purchase_price]" value="' . esc_attr( (float) $val( 'purchase_price', 0 ) ) . '" class="small-text" /></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'قیمت تمام‌شده', 'bespari-core' ) . '</label></th>';
		echo '<td><input type="number" step="0.01" name="product[finished_cost]" value="' . esc_attr( (float) $val( 'finished_cost', 0 ) ) . '" class="small-text" /></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'موجودی', 'bespari-core' ) . '</label></th>';
		echo '<td><input type="number" name="product[stock]" value="' . esc_attr( (int) $val( 'stock', 0 ) ) . '" class="small-text" /></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'وضعیت', 'bespari-core' ) . '</label></th><td><select name="product[status]">';
		echo '<option value="1"' . selected( (int) $val( 'status', 1 ), 1, false ) . '>' . esc_html__( 'فعال', 'bespari-core' ) . '</option>';
		echo '<option value="0"' . selected( (int) $val( 'status', 1 ), 0, false ) . '>' . esc_html__( 'غیرفعال', 'bespari-core' ) . '</option>';
		echo '</select></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'توضیحات', 'bespari-core' ) . '</label></th>';
		echo '<td><textarea name="product[description]" rows="3" class="large-text">' . esc_textarea( $val( 'description' ) ) . '</textarea></td></tr>';

		echo '</table>';

		// نگاشت کانال‌ها.
		echo '<h3 class="bespari-section-title">' . esc_html__( 'نگاشت کانال‌ها', 'bespari-core' ) . '</h3>';
		if ( empty( $channels ) ) {
			echo '<p class="description">' . esc_html__( 'ابتدا یک کانال فعال ثبت کنید.', 'bespari-core' ) . '</p>';
		} else {
			echo '<table class="bespari-table widefat striped bespari-channel-map"><thead><tr>';
			echo '<th>' . esc_html__( 'کانال', 'bespari-core' ) . '</th>';
			echo '<th>' . esc_html__( 'فعال', 'bespari-core' ) . '</th>';
			echo '<th>' . esc_html__( 'قیمت در کانال', 'bespari-core' ) . '</th>';
			echo '<th>' . esc_html__( 'موجودی کانال', 'bespari-core' ) . '</th>';
			echo '<th>' . esc_html__( 'کد تنوع', 'bespari-core' ) . '</th>';
			echo '<th>' . esc_html__( 'آی‌دی خارجی', 'bespari-core' ) . '</th>';
			echo '<th>' . esc_html__( 'آدرس محصول', 'bespari-core' ) . '</th>';
			echo '</tr></thead><tbody>';

			foreach ( $channels as $ch ) {
				$cid = $ch->id;
				$m   = $mapped[ $cid ] ?? array();
				$active = isset( $m['is_active'] ) ? (int) $m['is_active'] : 1;
				echo '<tr>';
				echo '<td><strong>' . esc_html( $ch->name ) . '</strong></td>';
				echo '<td><input type="checkbox" name="product[channels][' . $cid . '][is_active]" value="1"' . ( $active ? ' checked' : '' ) . ' /></td>';
				echo '<td><input type="number" step="0.01" name="product[channels][' . $cid . '][channel_price]" value="' . esc_attr( $m['channel_price'] ?? 0 ) . '" class="small-text" /></td>';
				echo '<td><input type="number" name="product[channels][' . $cid . '][channel_stock]" value="' . esc_attr( $m['channel_stock'] ?? 0 ) . '" class="small-text" /></td>';
				echo '<td><input type="text" name="product[channels][' . $cid . '][variation_code]" value="' . esc_attr( $m['variation_code'] ?? '' ) . '" class="small-text" /></td>';
				echo '<td><input type="text" name="product[channels][' . $cid . '][external_product_id]" value="' . esc_attr( $m['external_product_id'] ?? '' ) . '" class="small-text" /></td>';
				echo '<td><input type="url" name="product[channels][' . $cid . '][product_url]" value="' . esc_attr( $m['product_url'] ?? '' ) . '" class="regular-text" /></td>';
				echo '</tr>';
			}

			echo '</tbody></table>';
		}

		submit_button( $is_edit ? __( 'به‌روزرسانی محصول', 'bespari-core' ) : __( 'ایجاد محصول', 'bespari-core' ), 'primary', 'submit' );
		echo '</form>';
	}
}
