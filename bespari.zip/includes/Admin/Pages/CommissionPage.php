<?php
/**
 * صفحه پورسانت‌ها.
 *
 * @package Bespari\Admin\Pages
 */

namespace Bespari\Admin\Pages;

use Bespari\Modules\Commission\CommissionService;
use Bespari\Modules\Seller\SellerRepository;
use Bespari\Support\Helpers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CommissionPage extends BasePage {

	protected string $slug = 'bespari-commissions';
	protected string $cap  = 'bespari_manage_commission';

	public function render(): void {
		if ( ! $this->can_access() ) {
			// بازاریاب با seller_view هم اجازه مشاهده لیست خودش را ندارد اینجا — فقط ادمین.
			wp_die( esc_html__( 'شما دسترسی لازم را ندارید.', 'bespari-core' ) );
		}

		echo '<div class="wrap bespari-wrap">';
		$this->page_header( __( 'پورسانت‌ها', 'bespari-core' ), __( 'هر سفارش حداکثر یک پورسانت — مبنا از financials_snapshot (خالص یا سود).', 'bespari-core' ) );
		$this->render_notice();
		$this->render_filters();
		$this->render_list();
		echo '</div>';
	}

	private function render_filters(): void {
		$search    = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : ''; // phpcs:ignore
		$seller_id = isset( $_GET['seller_id'] ) ? (int) $_GET['seller_id'] : 0; // phpcs:ignore
		$status    = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : ''; // phpcs:ignore
		$date_from = isset( $_GET['date_from'] ) ? sanitize_text_field( wp_unslash( $_GET['date_from'] ) ) : ''; // phpcs:ignore
		$date_to   = isset( $_GET['date_to'] ) ? sanitize_text_field( wp_unslash( $_GET['date_to'] ) ) : ''; // phpcs:ignore

		$sellers = ( new SellerRepository() )->all();

		echo '<form method="get" class="bespari-filters">';
		echo '<input type="hidden" name="page" value="bespari-commissions" />';
		echo '<div class="bespari-filters__row">';
		echo '<input type="search" name="s" value="' . esc_attr( $search ) . '" placeholder="' . esc_attr__( 'شماره سفارش', 'bespari-core' ) . '" class="regular-text" />';

		echo '<select name="seller_id"><option value="0">' . esc_html__( 'همه بازاریاب‌ها', 'bespari-core' ) . '</option>';
		foreach ( $sellers as $u ) {
			echo '<option value="' . esc_attr( $u->id ) . '"' . selected( $seller_id, $u->id, false ) . '>' . esc_html( $u->display_name ) . '</option>';
		}
		echo '</select>';

		echo '<select name="status"><option value="">' . esc_html__( 'همه وضعیت‌ها', 'bespari-core' ) . '</option>';
		foreach ( array( 'pending' => __( 'در انتظار', 'bespari-core' ), 'approved' => __( 'تاییدشده', 'bespari-core' ), 'paid' => __( 'پرداخت‌شده', 'bespari-core' ), 'cancelled' => __( 'لغوشده', 'bespari-core' ) ) as $k => $label ) {
			echo '<option value="' . esc_attr( $k ) . '"' . selected( $status, $k, false ) . '>' . esc_html( $label ) . '</option>';
		}
		echo '</select>';

		echo '<input type="date" name="date_from" value="' . esc_attr( $date_from ) . '" />';
		echo '<input type="date" name="date_to" value="' . esc_attr( $date_to ) . '" />';
		echo '<button type="submit" class="button">' . esc_html__( 'فیلتر', 'bespari-core' ) . '</button> ';
		$clear = add_query_arg( array( 'page' => 'bespari-commissions' ), admin_url( 'admin.php' ) );
		echo '<a href="' . esc_url( $clear ) . '" class="button">' . esc_html__( 'پاک کردن', 'bespari-core' ) . '</a>';
		echo '</div></form>';
	}

	private function render_list(): void {
		$args = array(
			'page'      => isset( $_GET['paged'] ) ? (int) $_GET['paged'] : 1, // phpcs:ignore
			'search'    => isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '', // phpcs:ignore
			'seller_id' => isset( $_GET['seller_id'] ) ? (int) $_GET['seller_id'] : 0, // phpcs:ignore
			'status'    => isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : '', // phpcs:ignore
			'date_from' => isset( $_GET['date_from'] ) ? sanitize_text_field( wp_unslash( $_GET['date_from'] ) ) : '', // phpcs:ignore
			'date_to'   => isset( $_GET['date_to'] ) ? sanitize_text_field( wp_unslash( $_GET['date_to'] ) ) : '', // phpcs:ignore
			'per_page'  => 20,
		);
		$service = new CommissionService();
		$res     = $service->list( $args );
		$items   = $res['items'];
		$total   = $res['total'];
		$page    = max( 1, (int) ( $args['page'] ?? 1 ) );
		$pages   = max( 1, (int) ceil( $total / 20 ) );

		if ( empty( $items ) ) {
			echo '<div class="bespari-empty"><p>' . esc_html__( 'پورسانتی یافت نشد.', 'bespari-core' ) . '</p></div>';
			return;
		}

		echo '<table class="bespari-table widefat striped"><thead><tr>';
		echo '<th>#</th>';
		echo '<th>' . esc_html__( 'سفارش', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'بازاریاب', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'مبنا', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'درصد', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'مبلغ', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'وضعیت', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'تاریخ', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'عملیات', 'bespari-core' ) . '</th>';
		echo '</tr></thead><tbody>';

		foreach ( $items as $m ) {
			$badge_map = array( 'pending' => 'bespari-badge--warning', 'approved' => 'bespari-badge--info', 'paid' => 'bespari-badge--success', 'cancelled' => 'bespari-badge--danger' );
			$cls       = $badge_map[ $m->status ] ?? 'bespari-badge--muted';
			echo '<tr>';
			echo '<td>' . esc_html( $m->id ) . '</td>';
			echo '<td>' . esc_html( $m->order_number ?: (string) $m->order_id ) . '</td>';
			echo '<td>' . esc_html( $m->seller_name ?: (string) $m->seller_id ) . '</td>';
			echo '<td>' . esc_html( $m->base_type_label() ) . ' ' . esc_html( Helpers::format_money( $m->base_amount ) ) . '</td>';
			echo '<td>' . esc_html( Helpers::format_percent( $m->percent ) ) . '</td>';
			echo '<td><strong>' . esc_html( Helpers::format_money( $m->amount ) ) . '</strong></td>';
			echo '<td><span class="bespari-badge ' . esc_attr( $cls ) . '">' . esc_html( $m->status_label() ) . '</span></td>';
			echo '<td><span class="bespari-muted">' . esc_html( $m->created_at ) . '</span></td>';
			echo '<td class="bespari-actions">';
			if ( 'pending' === $m->status ) {
				$approve = $this->admin_action_url( 'approve_commission', array( 'id' => $m->id ) );
				$cancel  = $this->admin_action_url( 'cancel_commission', array( 'id' => $m->id ) );
				echo '<a href="' . esc_url( $approve ) . '" class="button button-small button-primary">' . esc_html__( 'تایید', 'bespari-core' ) . '</a> ';
				echo '<a href="' . esc_url( $cancel ) . '" class="button button-small">' . esc_html__( 'لغو', 'bespari-core' ) . '</a>';
			} elseif ( in_array( $m->status, array( 'pending', 'approved' ), true ) ) {
				$cancel = $this->admin_action_url( 'cancel_commission', array( 'id' => $m->id ) );
				echo '<a href="' . esc_url( $cancel ) . '" class="button button-small">' . esc_html__( 'لغو', 'bespari-core' ) . '</a>';
			} else {
				echo '<span class="bespari-muted">—</span>';
			}
			echo '</td></tr>';
		}
		echo '</tbody></table>';
		if ( $pages > 1 ) {
			echo '<div class="tablenav"><div class="tablenav-pages">';
			echo paginate_links( array( 'base' => add_query_arg( 'paged', '%#%' ), 'format' => '', 'prev_text' => __( '&laquo; قبلی', 'bespari-core' ), 'next_text' => __( 'بعدی &raquo;', 'bespari-core' ), 'total' => $pages, 'current' => $page ) );
			echo '</div></div>';
		}
		echo '<p class="description">' . sprintf( esc_html__( 'مجموع %d پورسانت', 'bespari-core' ), (int) $total ) . '</p>';
	}
}
