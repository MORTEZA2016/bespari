<?php
/**
 * صفحه مرجوعی‌ها.
 *
 * @package Bespari\Admin\Pages
 */

namespace Bespari\Admin\Pages;

use Bespari\Modules\Returns\ReturnService;
use Bespari\Modules\Order\OrderRepository;
use Bespari\Support\Helpers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ReturnPage extends BasePage {

	protected string $slug = 'bespari-returns';
	protected string $cap  = 'bespari_manage_returns';

	public function render(): void {
		if ( ! $this->can_access() ) {
			wp_die( esc_html__( 'شما دسترسی لازم را ندارید.', 'bespari-core' ) );
		}

		$tab = $this->current_tab( 'list' );

		echo '<div class="wrap bespari-wrap">';
		$this->page_header( __( 'مرجوعی‌ها', 'bespari-core' ), __( 'ثبت، تایید و بازگشت مرجوعی به انبار — مبلغ بازگشت از snapshot سفارش فریز می‌شود.', 'bespari-core' ) );
		$this->render_notice();
		$this->render_tabs( $tab, array(
			'list' => __( 'لیست مرجوعی‌ها', 'bespari-core' ),
			'add'  => __( 'ثبت مرجوعی', 'bespari-core' ),
		) );

		if ( 'add' === $tab ) {
			$this->render_form();
		} else {
			$this->render_filters();
			$this->render_list();
		}

		echo '</div>';
	}

	private function render_filters(): void {
		$search   = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : ''; // phpcs:ignore
		$status   = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : ''; // phpcs:ignore
		$date_from = isset( $_GET['date_from'] ) ? sanitize_text_field( wp_unslash( $_GET['date_from'] ) ) : ''; // phpcs:ignore
		$date_to  = isset( $_GET['date_to'] ) ? sanitize_text_field( wp_unslash( $_GET['date_to'] ) ) : ''; // phpcs:ignore

		echo '<form method="get" class="bespari-filters">';
		echo '<input type="hidden" name="page" value="bespari-returns" />';
		echo '<div class="bespari-filters__row">';
		echo '<input type="search" name="s" value="' . esc_attr( $search ) . '" placeholder="' . esc_attr__( 'سفارش / محصول', 'bespari-core' ) . '" class="regular-text" />';
		echo '<select name="status"><option value="">' . esc_html__( 'همه وضعیت‌ها', 'bespari-core' ) . '</option>';
		foreach ( array( 'pending' => __( 'در انتظار', 'bespari-core' ), 'approved' => __( 'تاییدشده', 'bespari-core' ), 'rejected' => __( 'ردشده', 'bespari-core' ), 'restocked' => __( 'بازگشت به انبار', 'bespari-core' ) ) as $k => $label ) {
			echo '<option value="' . esc_attr( $k ) . '"' . selected( $status, $k, false ) . '>' . esc_html( $label ) . '</option>';
		}
		echo '</select>';
		echo '<input type="date" name="date_from" value="' . esc_attr( $date_from ) . '" />';
		echo '<input type="date" name="date_to" value="' . esc_attr( $date_to ) . '" />';
		echo '<button type="submit" class="button">' . esc_html__( 'فیلتر', 'bespari-core' ) . '</button> ';
		$clear = add_query_arg( array( 'page' => 'bespari-returns' ), admin_url( 'admin.php' ) );
		echo '<a href="' . esc_url( $clear ) . '" class="button">' . esc_html__( 'پاک کردن', 'bespari-core' ) . '</a>';
		echo '</div></form>';
	}

	private function render_list(): void {
		$args = array(
			'page'      => isset( $_GET['paged'] ) ? max( 1, (int) $_GET['paged'] ) : 1, // phpcs:ignore
			'search'    => isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '', // phpcs:ignore
			'status'    => isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : '', // phpcs:ignore
			'date_from' => isset( $_GET['date_from'] ) ? sanitize_text_field( wp_unslash( $_GET['date_from'] ) ) : '', // phpcs:ignore
			'date_to'   => isset( $_GET['date_to'] ) ? sanitize_text_field( wp_unslash( $_GET['date_to'] ) ) : '', // phpcs:ignore
			'per_page'  => 20,
		);
		$service = new ReturnService();
		$res     = $service->list( $args );
		$items   = $res['items'];
		$total   = $res['total'];
		$page    = max( 1, (int) ( $args['page'] ?? 1 ) );
		$pages   = max( 1, (int) ceil( $total / 20 ) );

		if ( empty( $items ) ) {
			echo '<div class="bespari-empty"><p>' . esc_html__( 'مرجوعی‌ای یافت نشد.', 'bespari-core' ) . '</p></div>';
			return;
		}

		echo '<table class="bespari-table widefat striped"><thead><tr>';
		echo '<th>#</th>';
		echo '<th>' . esc_html__( 'سفارش', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'محصول', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'تعداد', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'مبلغ بازگشت', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'دلیل', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'وضعیت', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'تاریخ', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'عملیات', 'bespari-core' ) . '</th>';
		echo '</tr></thead><tbody>';

		$badge_map = array( 'pending' => 'bespari-badge--warning', 'approved' => 'bespari-badge--info', 'rejected' => 'bespari-badge--danger', 'restocked' => 'bespari-badge--success' );

		foreach ( $items as $m ) {
			$cls = $badge_map[ $m->status ] ?? 'bespari-badge--muted';
			echo '<tr>';
			echo '<td>' . esc_html( $m->id ) . '</td>';
			echo '<td>' . esc_html( $m->order_number ?: (string) $m->order_id ) . '</td>';
			echo '<td>' . esc_html( $m->product_name ?: (string) $m->product_id ) . '</td>';
			echo '<td>' . esc_html( (string) $m->quantity ) . '</td>';
			echo '<td>' . ( $m->refund_amount > 0 ? '<strong>' . esc_html( Helpers::format_money( $m->refund_amount ) ) . '</strong>' : '<span class="bespari-muted">—</span>' ) . '</td>';
			echo '<td><span class="bespari-muted">' . esc_html( $m->reason ?: '—' ) . '</span></td>';
			echo '<td><span class="bespari-badge ' . esc_attr( $cls ) . '">' . esc_html( $m->status_label() ) . '</span></td>';
			echo '<td><span class="bespari-muted">' . esc_html( $m->created_at ) . '</span></td>';
			echo '<td class="bespari-actions">';
			if ( 'pending' === $m->status ) {
				echo '<a href="' . esc_url( $this->admin_action_url( 'approve_return', array( 'id' => $m->id ) ) ) . '" class="button button-small button-primary">' . esc_html__( 'تایید', 'bespari-core' ) . '</a> ';
				echo '<a href="' . esc_url( $this->admin_action_url( 'reject_return', array( 'id' => $m->id ) ) ) . '" class="button button-small">' . esc_html__( 'رد', 'bespari-core' ) . '</a>';
			} elseif ( 'approved' === $m->status ) {
				echo '<a href="' . esc_url( $this->admin_action_url( 'restock_return', array( 'id' => $m->id ) ) ) . '" class="button button-small button-primary">' . esc_html__( 'بازگشت به انبار', 'bespari-core' ) . '</a>';
			} else {
				echo '<span class="bespari-muted">—</span>';
			}
			echo '</td></tr>';
		}
		echo '</tbody></table>';

		if ( $pages > 1 ) {
			echo '<div class="tablenav"><div class="tablenav-pages">';
			echo paginate_links( array( 'base' => add_query_arg( 'paged', '%#%' ), 'format' => '', 'prev_text' => __( '&laquo; قبلی', 'bespari-core' ), 'next_text' => __( 'بعدی &raquo;', 'bespari-core' ), 'total' => $pages, 'current' => $page ) );
			echo '</div></div>';
		}
		echo '<p class="description">' . sprintf( esc_html__( 'مجموع %d مرجوعی', 'bespari-core' ), (int) $total ) . '</p>';
	}

	private function render_form(): void {
		$order_repo = new OrderRepository();
		$orders_res = $order_repo->paginate( array(), 1, 100 );

		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="bespari-form">';
		wp_nonce_field( 'bespari_save_return', 'bespari_nonce' );
		echo '<input type="hidden" name="action" value="bespari_save_return" />';
		echo '<table class="form-table">';

		echo '<tr><th scope="row"><label>' . esc_html__( 'سفارش', 'bespari-core' ) . ' <span class="required">*</span></label></th><td>';
		echo '<select name="return[order_id]" id="bespari-return-order" required><option value="">' . esc_html__( '— انتخاب سفارش —', 'bespari-core' ) . '</option>';
		foreach ( $orders_res['items'] as $o ) {
			echo '<option value="' . esc_attr( $o->id ) . '">' . esc_html( $o->order_number . ' — ' . $o->customer_name ) . '</option>';
		}
		echo '</select>';
		echo '<p class="description">' . esc_html__( 'پس از انتخاب سفارش، صفحه بارگذاری می‌شود تا محصولات آن انتخاب شود.', 'bespari-core' ) . '</p>';
		echo '</td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'شناسه محصول', 'bespari-core' ) . ' <span class="required">*</span></label></th>';
		echo '<td><input type="number" name="return[product_id]" min="1" class="small-text" required />';
		echo '<p class="description">' . esc_html__( 'شناسه محصولِ موجود در آیتم‌های سفارش انتخابی (از صفحه سفارش قابل مشاهده است).', 'bespari-core' ) . '</p></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'تعداد', 'bespari-core' ) . '</label></th>';
		echo '<td><input type="number" name="return[quantity]" min="1" value="1" class="small-text" required /></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'دلیل مرجوعی', 'bespari-core' ) . '</label></th>';
		echo '<td><input type="text" name="return[reason]" class="regular-text" /></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'یادداشت', 'bespari-core' ) . '</label></th>';
		echo '<td><textarea name="return[notes]" rows="3" class="large-text"></textarea></td></tr>';

		echo '</table>';
		submit_button( __( 'ثبت مرجوعی', 'bespari-core' ), 'primary', 'submit' );
		echo '</form>';
	}
}
