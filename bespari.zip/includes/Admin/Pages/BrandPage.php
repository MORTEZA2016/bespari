<?php
/**
 * صفحه برندها.
 *
 * @package Bespari\Admin\Pages
 */

namespace Bespari\Admin\Pages;

use Bespari\Modules\Brand\BrandService;
use Bespari\Modules\Channel\ChannelService;

// جلوگیری از دسترسی مستقیم.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BrandPage extends BasePage {

	protected string $slug = 'bespari-brands';
	protected string $cap  = 'bespari_manage_brands';

	public function render(): void {
		if ( ! $this->can_access() ) {
			wp_die( esc_html__( 'شما دسترسی لازم را ندارید.', 'bespari-core' ) );
		}

		$tab     = $this->current_tab( 'list' );
		$edit_id = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0; // phpcs:ignore
		if ( $edit_id && 'list' === $tab ) {
			$tab = 'edit';
		}

		echo '<div class="wrap bespari-wrap">';
		$this->page_header( __( 'برندهای فروش', 'bespari-core' ), __( 'هر برند می‌تواند به یک یا چند کانال فروش متصل باشد.', 'bespari-core' ) );
		$this->render_notice();
		$this->render_tabs( $tab, array(
			'list' => __( 'لیست برندها', 'bespari-core' ),
			'add'  => __( 'افزودن برند', 'bespari-core' ),
		) );

		if ( 'add' === $tab ) {
			$this->render_form( null );
		} elseif ( 'edit' === $tab && $edit_id ) {
			$service = new BrandService();
			$brand   = $service->get( $edit_id );
			if ( ! $brand ) {
				echo '<div class="bespari-notice bespari-notice--error"><span>' . esc_html__( 'برند یافت نشد.', 'bespari-core' ) . '</span></div>';
			} else {
				$this->render_form( $brand );
			}
		} else {
			$this->render_list();
		}

		echo '</div>';
	}

	private function render_list(): void {
		$service = new BrandService();
		$brands  = $service->list();

		// نگاشت نام کانال‌ها برای نمایش.
		$channel_names = array();
		foreach ( ( new ChannelService() )->list() as $ch ) {
			$channel_names[ $ch->id ] = $ch->name;
		}

		if ( empty( $brands ) ) {
			echo '<div class="bespari-empty"><p>' . esc_html__( 'هنوز برندی ثبت نشده است.', 'bespari-core' ) . '</p></div>';
			return;
		}

		echo '<table class="bespari-table widefat striped">';
		echo '<thead><tr>';
		echo '<th>' . esc_html__( 'نام', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'اسلاگ', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'وضعیت', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'کانال‌ها', 'bespari-core' ) . '</th>';
		echo '<th>' . esc_html__( 'عملیات', 'bespari-core' ) . '</th>';
		echo '</tr></thead><tbody>';

		foreach ( $brands as $brand ) {
			$edit_url   = add_query_arg( array( 'page' => 'bespari-brands', 'id' => $brand->id ), admin_url( 'admin.php' ) );
			$delete_url = $this->admin_action_url( 'delete_brand', array( 'id' => $brand->id ) );
			$badge_cls  = 1 === $brand->status ? 'bespari-badge--success' : 'bespari-badge--muted';

			$ch_labels = array();
			foreach ( $brand->channel_ids as $cid ) {
				$ch_labels[] = $channel_names[ $cid ] ?? '#' . $cid;
			}
			$ch_text = $ch_labels ? implode( '، ', array_map( 'esc_html', $ch_labels ) ) : '—';

			echo '<tr>';
			echo '<td><strong>' . esc_html( $brand->name ) . '</strong></td>';
			echo '<td><code>' . esc_html( $brand->slug ) . '</code></td>';
			echo '<td><span class="bespari-badge ' . esc_attr( $badge_cls ) . '">' . esc_html( $brand->status_label() ) . '</span></td>';
			echo '<td>' . esc_html( $ch_text ) . '</td>';
			echo '<td class="bespari-actions">';
			echo '<a href="' . esc_url( $edit_url ) . '" class="button button-small">' . esc_html__( 'ویرایش', 'bespari-core' ) . '</a> ';
			echo '<a href="' . esc_url( $delete_url ) . '" class="button button-small button-link-delete bespari-confirm-delete" data-message="' . esc_attr__( 'آیا از حذف این برند اطمینان دارید؟', 'bespari-core' ) . '">' . esc_html__( 'حذف', 'bespari-core' ) . '</a>';
			echo '</td>';
			echo '</tr>';
		}

		echo '</tbody></table>';
	}

	/**
	 * @param \Bespari\Modules\Brand\BrandModel|null $brand
	 */
	private function render_form( $brand ): void {
		$is_edit = null !== $brand;
		$action  = admin_url( 'admin-post.php' );

		$val = function( string $key, $default = '' ) use ( $brand ) {
			if ( ! $brand ) {
				return $default;
			}
			return $brand->$key ?? $default;
		};

		// لیست کانال‌ها برای چک‌باکس.
		$all_channels = ( new ChannelService() )->list();
		$selected_cids = $brand ? $brand->channel_ids : array();

		echo '<form method="post" action="' . esc_url( $action ) . '" class="bespari-form">';
		wp_nonce_field( 'bespari_save_brand', 'bespari_nonce' );
		echo '<input type="hidden" name="action" value="bespari_save_brand" />';
		if ( $is_edit ) {
			echo '<input type="hidden" name="brand_id" value="' . esc_attr( $brand->id ) . '" />';
		}

		echo '<table class="form-table">';
		echo '<tr><th scope="row"><label>' . esc_html__( 'نام برند', 'bespari-core' ) . ' <span class="required">*</span></label></th>';
		echo '<td><input type="text" name="brand[name]" value="' . esc_attr( $val( 'name' ) ) . '" class="regular-text" required placeholder="' . esc_attr__( 'مثلاً: Delori', 'bespari-core' ) . '" /></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'وضعیت', 'bespari-core' ) . '</label></th><td><select name="brand[status]">';
		echo '<option value="1"' . selected( (int) $val( 'status', 1 ), 1, false ) . '>' . esc_html__( 'فعال', 'bespari-core' ) . '</option>';
		echo '<option value="0"' . selected( (int) $val( 'status', 1 ), 0, false ) . '>' . esc_html__( 'غیرفعال', 'bespari-core' ) . '</option>';
		echo '</select></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'آدرس لوگو', 'bespari-core' ) . '</label></th>';
		echo '<td><input type="url" name="brand[logo]" value="' . esc_attr( $val( 'logo' ) ) . '" class="regular-text" placeholder="https://" /></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'توضیحات', 'bespari-core' ) . '</label></th>';
		echo '<td><textarea name="brand[description]" rows="3" class="large-text">' . esc_textarea( $val( 'description' ) ) . '</textarea></td></tr>';

		// چک‌باکس کانال‌ها.
		echo '<tr><th scope="row"><label>' . esc_html__( 'کانال‌های فعال', 'bespari-core' ) . '</label></th><td>';
		if ( empty( $all_channels ) ) {
			echo '<p class="description">' . esc_html__( 'هنوز کانالی ثبت نشده است.', 'bespari-core' ) . '</p>';
		} else {
			foreach ( $all_channels as $ch ) {
				$checked = in_array( $ch->id, $selected_cids, true ) ? ' checked' : '';
				echo '<label style="display:inline-block;margin:4px 12px 4px 0;"><input type="checkbox" name="brand[channel_ids][]" value="' . esc_attr( $ch->id ) . '"' . $checked . ' /> ' . esc_html( $ch->name ) . '</label>';
			}
		}
		echo '<p class="description">' . esc_html__( 'برند در کدام کانال‌ها عرضه می‌شود؟', 'bespari-core' ) . '</p>';
		echo '</td></tr>';

		echo '</table>';
		submit_button( $is_edit ? __( 'به‌روزرسانی برند', 'bespari-core' ) : __( 'ایجاد برند', 'bespari-core' ), 'primary', 'submit' );
		echo '</form>';
	}
}
