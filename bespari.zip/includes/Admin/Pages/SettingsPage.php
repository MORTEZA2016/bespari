<?php
/**
 * صفحه تنظیمات افزونه.
 *
 * @package Bespari\Admin\Pages
 */

namespace Bespari\Admin\Pages;

use Bespari\Support\Helpers;

// جلوگیری از دسترسی مستقیم.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SettingsPage extends BasePage {

	protected string $slug = 'bespari-settings';
	protected string $cap  = 'bespari_manage_settings';

	public function render(): void {
		if ( ! $this->can_access() ) {
			wp_die( esc_html__( 'شما دسترسی لازم را ندارید.', 'bespari-core' ) );
		}

		// ذخیره تنظیمات.
		if ( isset( $_POST['bespari_save_settings'] ) ) {
			$this->handle_save();
		}

		echo '<div class="wrap bespari-wrap">';
		$this->page_header( __( 'تنظیمات بسپاری ERP', 'bespari-core' ), __( 'تنظیمات عمومی، واحد پول، مالیات و لاگ.', 'bespari-core' ) );
		$this->render_notice();
		$this->render_form();
		echo '</div>';
	}

	private function handle_save(): void {
		if ( ! current_user_can( $this->cap ) ) {
			wp_die( esc_html__( 'شما دسترسی لازم را ندارید.', 'bespari-core' ) );
		}

		check_admin_referer( 'bespari_save_settings', 'bespari_nonce' );

		$settings = get_option( 'bespari_settings', array() );

		$settings['currency']         = sanitize_key( $_POST['currency'] ?? 'IRT' );
		$settings['tax_rate']         = (float) str_replace( array( ',', ' ' ), '', (string) ( $_POST['tax_rate'] ?? 9 ) );
		$settings['audit_log_active'] = isset( $_POST['audit_log_active'] ) ? 1 : 0;

		update_option( 'bespari_settings', $settings );

		// ریدایرکت برای جلوگیری از ارسال مجدد.
		wp_safe_redirect( add_query_arg( array( 'page' => 'bespari-settings', 'bespari_msg' => 'saved' ), admin_url( 'admin.php' ) ) );
		exit;
	}

	private function render_form(): void {
		$settings = get_option( 'bespari_settings', array() );
		$currency = $settings['currency'] ?? 'IRT';
		$tax_rate = $settings['tax_rate'] ?? 9;
		$audit    = (int) ( $settings['audit_log_active'] ?? 1 );

		echo '<form method="post" action="" class="bespari-form">';
		wp_nonce_field( 'bespari_save_settings', 'bespari_nonce' );

		echo '<table class="form-table">';

		echo '<tr><th scope="row"><label>' . esc_html__( 'واحد پول', 'bespari-core' ) . '</label></th><td><select name="currency">';
		echo '<option value="IRT"' . selected( $currency, 'IRT', false ) . '>' . esc_html__( 'تومان (IRT)', 'bespari-core' ) . '</option>';
		echo '<option value="IRR"' . selected( $currency, 'IRR', false ) . '>' . esc_html__( 'ریال (IRR)', 'bespari-core' ) . '</option>';
		echo '</select></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'نرخ مالیات پیش‌فرض (%)', 'bespari-core' ) . '</label></th>';
		echo '<td><input type="number" step="0.01" name="tax_rate" value="' . esc_attr( $tax_rate ) . '" class="small-text" /></td></tr>';

		echo '<tr><th scope="row"><label>' . esc_html__( 'لاگ تغییرات', 'bespari-core' ) . '</label></th>';
		echo '<td><label><input type="checkbox" name="audit_log_active" value="1"' . checked( $audit, 1, false ) . ' /> ' . esc_html__( 'فعال باشد', 'bespari-core' ) . '</label></td></tr>';

		echo '</table>';

		echo '<p class="submit"><button type="submit" name="bespari_save_settings" value="1" class="button button-primary">' . esc_html__( 'ذخیره تنظیمات', 'bespari-core' ) . '</button></p>';
		echo '</form>';

		// اطلاعات سیستم (فقط نمایش).
		echo '<div class="bespari-box bespari-box--white" style="margin-top:24px;">';
		echo '<h3 class="bespari-box__title">' . esc_html__( 'اطلاعات سیستم', 'bespari-core' ) . '</h3>';
		echo '<table class="bespari-phase-table"><tbody>';
		echo '<tr><td>' . esc_html__( 'نسخه افزونه', 'bespari-core' ) . '</td><td><code>' . esc_html( BESPARI_VERSION ) . '</code></td></tr>';
		echo '<tr><td>' . esc_html__( 'نسخه دیتابیس', 'bespari-core' ) . '</td><td><code>' . esc_html( get_option( 'bespari_db_version', '—' ) ) . '</code></td></tr>';
		echo '<tr><td>' . esc_html__( 'نسخه قوانین قیمت', 'bespari-core' ) . '</td><td><code>' . esc_html( get_option( 'bespari_pricing_version', 1 ) ) . '</code></td></tr>';
		echo '<tr><td>' . esc_html__( 'ووکامرس', 'bespari-core' ) . '</td><td>' . ( Helpers::woocommerce_is_active() ? '<span class="bespari-badge bespari-badge--success">' . esc_html__( 'فعال', 'bespari-core' ) . '</span>' : '<span class="bespari-badge bespari-badge--muted">' . esc_html__( 'غیرفعال', 'bespari-core' ) . '</span>' ) . '</td></tr>';
		echo '</tbody></table>';
		echo '</div>';
	}
}
