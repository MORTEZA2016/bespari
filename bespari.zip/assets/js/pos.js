/**
 * پنل POS ثبت سفارش — منطق جستجو/سبد/محاسبه زنده/ثبت نهایی.
 */
(function () {
	'use strict';

	if ( typeof window.bespariPos !== 'object' ) {
		return;
	}

	var cfg = window.bespariPos;
	var $ = function ( id ) { return document.getElementById( id ); };

	var el = {
		search: $( 'pos-search' ),
		searchBtn: $( 'pos-search-btn' ),
		grid: $( 'pos-product-grid' ),
		cartBody: $( 'pos-cart-body' ),
		totals: $( 'pos-totals' ),
		gross: $( 'pos-total-gross' ),
		ded: $( 'pos-total-deductions' ),
		net: $( 'pos-total-net' ),
		checkout: $( 'pos-checkout' ),
		saleType: $( 'pos-sale-type' ),
		channel: $( 'pos-channel' ),
		seller: $( 'pos-seller' ),
		customerFields: $( 'pos-customer-fields' ),
		customerName: $( 'pos-customer-name' ),
		customerPhone: $( 'pos-customer-phone' ),
		customerAddress: $( 'pos-customer-address' ),
		notes: $( 'pos-notes' ),
		submit: $( 'pos-submit' ),
		result: $( 'pos-result' )
	};

	var products = [];      // آخرین لیست محصولات سرچ‌شده.
	var cart = {};          // product_id -> {product, qty, override}
	var channels = {};      // id -> {needs_customer, ...}
	var calcTimer = null;
	var searchTimer = null;

	function fmt( n ) {
		return new Intl.NumberFormat( 'fa-IR' ).format( Math.round( Number( n ) || 0 ) );
	}

	function api( path, options ) {
		options = options || {};
		options.path = path;
		options.headers = Object.assign( {
			'X-WP-Nonce': cfg.nonce,
			'Content-Type': 'application/json'
		}, options.headers || {} );

		var url = cfg.restUrl + path.replace( /^\//, '' );
		if ( 'GET' === ( options.method || 'GET' ) ) {
			url += ( url.indexOf( '?' ) > -1 ? '&' : '?' ) + '_=' + Date.now();
		}

		return window.fetch( url, {
			method: options.method || 'GET',
			headers: options.headers,
			body: options.body ? JSON.stringify( options.body ) : undefined,
			credentials: 'same-origin'
		} ).then( function ( res ) {
			return res.json().then( function ( json ) {
				if ( ! res.ok ) {
					throw new Error( json && json.message ? json.message : 'خطای ارتباط با سرور' );
				}
				return json;
			} );
		} );
	}

	/* ---------- محصولات ---------- */

	function productCard( p ) {
		var card = document.createElement( 'button' );
		card.type = 'button';
		card.className = 'pos-product-card';
		card.dataset.productId = p.id;

		var info = document.createElement( 'div' );
		info.className = 'pos-product-card__info';

		var name = document.createElement( 'div' );
		name.className = 'pos-product-card__name';
		name.textContent = p.name;

		var price = document.createElement( 'div' );
		price.className = 'pos-product-card__price';
		price.textContent = fmt( p.base_price ) + ' تومان';

		var meta = document.createElement( 'span' );
		meta.className = 'pos-product-card__stock';
		meta.textContent = ( p.sku ? 'SKU: ' + p.sku + '  ' : '' ) + 'موجودی: ' + fmt( p.stock );

		info.appendChild( name );
		info.appendChild( price );
		info.appendChild( meta );
		card.appendChild( info );
		card.addEventListener( 'click', function () { addToCart( p ); } );
		return card;
	}

	function renderProducts( list ) {
		el.grid.innerHTML = '';
		if ( ! list.length ) {
			var d = document.createElement( 'div' );
			d.className = 'pos-empty-grid';
			d.textContent = 'محصولی یافت نشد.';
			el.grid.appendChild( d );
			return;
		}
		list.forEach( function ( p ) {
			var card = productCard( p );
			if ( cart[ p.id ] ) {
				card.classList.add( 'is-added' );
			}
			el.grid.appendChild( card );
		} );
	}

	function loadProducts( search ) {
		el.grid.innerHTML = '<div class="pos-loading">در حال بارگذاری...</div>';
		api( 'products?s=' + encodeURIComponent( search || '' ) + '&limit=50' ).then( function ( res ) {
			products = res.products || [];
			renderProducts( products );
		} ).catch( function ( err ) {
			el.grid.innerHTML = '';
			var d = document.createElement( 'div' );
			d.className = 'pos-empty-grid';
			d.textContent = err.message;
			el.grid.appendChild( d );
		} );
	}

	/* ---------- سبد ---------- */

	function addToCart( p ) {
		if ( ! cart[ p.id ] ) {
			cart[ p.id ] = { product: p, qty: 1, override: 0 };
		} else {
			cart[ p.id ].qty += 1;
		}
		renderCart();
		scheduleCalc();
	}

	function setQty( id, qty ) {
		if ( ! cart[ id ] ) {
			return;
		}
		qty = parseInt( qty, 10 );
		if ( isNaN( qty ) || qty < 1 ) {
			qty = 1;
		}
		cart[ id ].qty = qty;
		renderCart();
		scheduleCalc();
	}

	function setOverride( id, value ) {
		if ( ! cart[ id ] ) {
			return;
		}
		var v = parseFloat( String( value ).replace( /[^\d.]/g, '' ) );
		cart[ id ].override = ( isNaN( v ) || v <= 0 ) ? 0 : v;
		renderCart();
		scheduleCalc();
	}

	function removeFromCart( id ) {
		delete cart[ id ];
		renderCart();
		scheduleCalc();
	}

	function cartItems() {
		return Object.keys( cart ).map( function ( id ) {
			var c = cart[ id ];
			return {
				product_id: c.product.id,
				quantity: c.qty,
				unit_price_override: c.override
			};
		} );
	}

	function renderCart() {
		var ids = Object.keys( cart );
		el.cartBody.innerHTML = '';

		if ( ! ids.length ) {
			var tr = document.createElement( 'tr' );
			tr.className = 'pos-cart__empty';
			tr.innerHTML = '<td colspan="4">محصولی اضافه نشده است.</td>';
			el.cartBody.appendChild( tr );
			el.totals.classList.remove( 'is-visible' );
			el.checkout.hidden = true;
		} else {
			ids.forEach( function ( id ) {
				var c = cart[ id ];
				var tr = document.createElement( 'tr' );

				var nameTd = document.createElement( 'td' );
				nameTd.className = 'pos-cart__name';
				nameTd.textContent = c.product.name;
				nameTd.title = c.product.name;

				var qtyTd = document.createElement( 'td' );
				var wrap = document.createElement( 'div' );
				wrap.className = 'pos-qty';
				var minus = document.createElement( 'button' );
				minus.type = 'button';
				minus.textContent = '−';
				minus.addEventListener( 'click', function () { setQty( id, c.qty - 1 ); } );
				var input = document.createElement( 'input' );
				input.type = 'number';
				input.min = '1';
				input.value = c.qty;
				input.addEventListener( 'change', function () { setQty( id, input.value ); } );
				var plus = document.createElement( 'button' );
				plus.type = 'button';
				plus.textContent = '+';
				plus.addEventListener( 'click', function () { setQty( id, c.qty + 1 ); } );
				wrap.appendChild( minus );
				wrap.appendChild( input );
				wrap.appendChild( plus );
				qtyTd.appendChild( wrap );

				var priceTd = document.createElement( 'td' );
				var priceInput = document.createElement( 'input' );
				priceInput.type = 'number';
				priceInput.min = '0';
				priceInput.step = 'any';
				priceInput.className = 'pos-price-input' + ( c.override > 0 ? ' is-edited' : '' );
				priceInput.value = c.override > 0 ? c.override : '';
				priceInput.placeholder = fmt( c.product.base_price );
				priceInput.title = 'قیمت فروش واقعی (خالی = قیمت محاسبه‌شده)';
				priceInput.addEventListener( 'input', function () {
					priceInput.classList.toggle( 'is-edited', priceInput.value !== '' );
					setOverride( id, priceInput.value );
				} );
				priceTd.appendChild( priceInput );

				var delTd = document.createElement( 'td' );
				var del = document.createElement( 'button' );
				del.type = 'button';
				del.className = 'pos-line-remove';
				del.textContent = '✕';
				del.title = 'حذف';
				del.addEventListener( 'click', function () { removeFromCart( id ); } );
				delTd.appendChild( del );

				tr.appendChild( nameTd );
				tr.appendChild( qtyTd );
				tr.appendChild( priceTd );
				tr.appendChild( delTd );
				el.cartBody.appendChild( tr );
			} );

			el.totals.classList.add( 'is-visible' );
			el.checkout.hidden = false;
		}

		// هایلایت کارت‌های موجود در سبد.
		Array.prototype.forEach.call( el.grid.querySelectorAll( '.pos-product-card' ), function ( card ) {
			card.classList.toggle( 'is-added', !! cart[ card.dataset.productId ] );
		} );
	}

	/* ---------- محاسبه زنده ---------- */

	function scheduleCalc() {
		clearTimeout( calcTimer );
		calcTimer = setTimeout( recalc, 350 );
	}

	function recalc() {
		if ( ! Object.keys( cart ).length ) {
			el.gross.textContent = el.ded.textContent = el.net.textContent = '۰';
			return;
		}
		var channelId = parseInt( el.channel.value, 10 ) || 0;
		if ( ! channelId ) {
			return;
		}

		api( 'calculate', {
			method: 'POST',
			body: {
				channel_id: channelId,
				sale_type: el.saleType.value,
				seller_id: el.seller ? ( parseInt( el.seller.value, 10 ) || 0 ) : 0,
				items: cartItems()
			}
		} ).then( function ( res ) {
			el.gross.textContent = fmt( res.gross );
			el.ded.textContent = fmt( res.deductions );
			el.net.textContent = fmt( res.net );
		} ).catch( function () {} );
	}

	/* ---------- کانال‌ها و مشتری ---------- */

	function loadChannels() {
		api( 'channels' ).then( function ( res ) {
			( res.channels || [] ).forEach( function ( ch ) {
				channels[ ch.id ] = ch;
				var opt = document.createElement( 'option' );
				opt.value = ch.id;
				opt.textContent = ch.name;
				el.channel.appendChild( opt );
			} );
		} );
	}

	function onChannelChange() {
		var ch = channels[ parseInt( el.channel.value, 10 ) ];
		var needs = !!( ch && ch.needs_customer );
		el.customerFields.hidden = ! needs;
		recalc();
	}

	/* ---------- ثبت نهایی ---------- */

	function showResult( ok, html ) {
		el.result.className = 'pos-result ' + ( ok ? 'is-ok' : 'is-error' );
		el.result.innerHTML = html;
	}

	function submitOrder() {
		if ( ! Object.keys( cart ).length ) {
			showResult( false, 'ابتدا محصول اضافه کنید.' );
			return;
		}
		var channelId = parseInt( el.channel.value, 10 ) || 0;
		if ( ! channelId ) {
			showResult( false, 'کانال فروش را انتخاب کنید.' );
			return;
		}
		var ch = channels[ channelId ];
		var needsCustomer = !!( ch && ch.needs_customer );

		if ( needsCustomer && ( ! el.customerName.value.trim() || ! el.customerPhone.value.trim() ) ) {
			showResult( false, 'برای کانال «فاکتور به فاکتور» نام و تلفن مشتری الزامی است.' );
			return;
		}

		el.submit.disabled = true;

		var body = {
			channel_id: channelId,
			sale_type: el.saleType.value,
			seller_id: el.seller ? ( parseInt( el.seller.value, 10 ) || 0 ) : 0,
			items: cartItems(),
			notes: el.notes.value
		};
		if ( needsCustomer ) {
			body.customer_name = el.customerName.value.trim();
			body.customer_phone = el.customerPhone.value.trim();
			body.customer_address = el.customerAddress.value.trim();
		}

		api( 'order', { method: 'POST', body: body } ).then( function ( res ) {
			showResult( true, 'سفارش <strong>' + res.order_number + '</strong> با موفقیت ثبت شد.' );
			cart = {};
			el.customerName.value = '';
			el.customerPhone.value = '';
			el.customerAddress.value = '';
			el.notes.value = '';
			renderCart();
			recalc();
		} ).catch( function ( err ) {
			showResult( false, err.message );
		} ).finally( function () {
			el.submit.disabled = false;
		} );
	}

	/* ---------- اتصال رویدادها ---------- */

	el.search.addEventListener( 'input', function () {
		clearTimeout( searchTimer );
		searchTimer = setTimeout( function () {
			loadProducts( el.search.value.trim() );
		}, 300 );
	} );
	el.searchBtn.addEventListener( 'click', function () {
		loadProducts( el.search.value.trim() );
	} );
	el.channel.addEventListener( 'change', onChannelChange );
	el.saleType.addEventListener( 'change', recalc );
	if ( el.seller ) {
		el.seller.addEventListener( 'change', recalc );
	}
	el.submit.addEventListener( 'click', submitOrder );

	loadProducts( '' );
	loadChannels();
} )();
