# Current Task

> این فایل مهم‌ترین فایل برای Resume کردن پروژه است.
> آخرین به‌روزرسانی: 2026-09-25

## Task ID
BSPR-003 — انتقال کامل افزونه به پنل مستقل + حذف منوهای wp-admin

## Status
IN PROGRESS — فاز ۱ (بک‌اند REST + ماژول User).

## Goal
تمام منوهای افزونه فقط در پنل مستقل `/panel/` (SPA) باشد؛ wp-admin فقط یک صفحه‌ی
«معرفی افزونه + مزایا + لینک ورود به پنل» داشته باشد. مدیریت کاربران (تعریف، نقش،
صدور توکن) کاملاً از داخل پنل انجام شود. برنامه‌ی کامل در
`C:/Users/MoRtEzA/.claude/plans/toasty-squishing-puddle.md`.

## Phases
- **فاز ۱** — بک‌اند: `ErpRestController` + ماژول `User` + cap/migration.
- **فاز ۲** — منوها: `AppAuth::menus()` +۱۳ ورودی؛ `Menu.php` → یک منوی معرفی؛
  حذف ثبت PosPage/PanelPage در `Plugin.php`.
- **فاز ۳** — فرانت‌اند: CRUD renderer مبتنی بر schema در `app.js` + استایل‌ها.
- **فاز ۴** — استقرار + تست (CLI + مرورگر).
- **فاز ۵** — پاک‌سازی فایل‌های مرحوم + به‌روزرسانی Memory.

## Next Exact Action
فاز ۱.۳: ساخت `includes/Modules/User/{User,UserService}.php`، سپس ۱.۱ `ErpRestController`.

## Files Changed (BSPR-003)
- (در حال انجام — به plan مراجعه کنید)

## Important Decisions
- CRUD renderer مبتنی بر schema (به‌جای ۱۳ renderer تکراری).
- سرویس‌های ماژول موجود دست نمی‌خورند — فقط خوانده می‌شوند.
- admin_post handlers در ماژول‌ها نگه داشته می‌شوند (cap+nonce guarded).
